﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;


namespace BOOKERP.Business
{
    public class CRMCustomerBC
    {
        public List<GE::CRMCustomers> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.CRMCustomerDA().GetAll(inputdata);
        }

        public string Save(GE::CRMCustomers item, string user, int OrganizationId)
        {
            return new DA.CRMCustomerDA().Save(item, user, OrganizationId);
        }

        public GE::CRMCustomers GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.CRMCustomerDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.CRMCustomerDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CRMCustomerDA().MakeActive(inputdata);
        }
    }
}
