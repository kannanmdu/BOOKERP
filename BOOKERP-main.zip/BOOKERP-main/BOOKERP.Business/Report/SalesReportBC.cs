﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;
using System.Data;

namespace BOOKERP.Business
{
    public class SalesReportBC
    {     
        public IEnumerable GetSoByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetSoByCode(inputdata);
        }
        public IEnumerable GetSQByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetSQByCode(inputdata);
        }
        public IEnumerable GetSalesDoByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetSalesDoByCode(inputdata);
        }
        public IEnumerable GetInvoiceByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetInvoiceByCode(inputdata);
        }
        public IEnumerable GetSRByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetSRByCode(inputdata);
        }
        public DataTable GetCustomerAgeigSubreport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetCustomerAgeigSubreport(reportSearch);
        }
        public IEnumerable GetSalesSummaryReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetSalesSummaryReport(reportSearch);
        }
        public IEnumerable GetSalesDetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetSalesDetailReport(reportSearch);
        }
        public IEnumerable GetSalesInvoiceSummaryByDateReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetSalesInvoiceSummaryByDateReport(reportSearch);
        }
        public IEnumerable GetReceiptHeaderReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetReceiptHeaderReport(reportSearch);
        }
        public IEnumerable GetReceiptDetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetReceiptDetailReport(reportSearch);
        }
        public IEnumerable GetReceiptBankInDetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetReceiptBankInDetailReport(reportSearch);
        }
        public IEnumerable GetCustomerOutStandingReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetCustomerOutStandingReport(reportSearch);
        }
        public IEnumerable GetCustomerStatementReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetCustomerStatementReport(reportSearch);
        }
        public IEnumerable GetCustomerAgingReport(GE::ReportSearch reportSearch)
        {
            return new DA::SalesReportDA().GetCustomerAgingReport(reportSearch);
        }
        public IEnumerable GetReceiptByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesReportDA().GetReceiptByCode(inputdata);
        }
    }
}
