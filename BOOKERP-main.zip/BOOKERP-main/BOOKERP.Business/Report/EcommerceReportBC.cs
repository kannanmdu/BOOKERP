﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;

namespace BOOKERP.Business
{
    public class EcommerceReportBC
    {   
        public IEnumerable GetB2COrderDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::EcommerceReportDA().GetB2COrderDetails(inputdata);
        }       
    }    
}
