﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;

namespace BOOKERP.Business
{
    public class PurchaseReportBC
    {
        //DA::PurchaseReportDA _DA = new DA.PurchaseReportDA();
        public IEnumerable GetPoByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::PurchaseReportDA().GetPoByCode(inputdata);
        }
        public IEnumerable GetStockInByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::PurchaseReportDA().GetStockInByCode(inputdata);
        }
        public IEnumerable GetStockInDoByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::PurchaseReportDA().GetStockInDoByCode(inputdata);
        }
        public IEnumerable GetPaymentByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::PurchaseReportDA().GetPaymentByCode(inputdata);
        }
        public IEnumerable GetSTockInReturnByCode(GE::ERPInputmodel inputdata)
        {
            return new DA::PurchaseReportDA().GetSTockInReturnByCode(inputdata);
        }
        public IEnumerable GetPurchaseSummaryReport(GE::ReportSearch reportSearch)
        {
            return new DA::PurchaseReportDA().GetPurchaseSummaryReport(reportSearch);
        }        
        public IEnumerable GetPaymentSummaryReport(GE::ReportSearch reportSearch)
        {
            return new DA::PurchaseReportDA().GetPurchaseSummaryReport(reportSearch);
        }
        public IEnumerable GetPurchaseOrderDetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::PurchaseReportDA().GetPurchaseDetailReport(reportSearch);
        }
    }
}
