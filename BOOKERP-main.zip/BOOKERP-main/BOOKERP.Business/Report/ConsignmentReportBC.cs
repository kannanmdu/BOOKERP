﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;

namespace BOOKERP.Business
{
    public class ConsignmentReportBC
    {       
        public IEnumerable GetConsignmentDODetails(GE::ERPInputmodel inputdata)
        {
            return new DA::ConsignmentDA().GetConsignmentDODetails(inputdata);
        }
        public IEnumerable GetConsignmentReturnDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::ConsignmentDA().GetConsignmentReturnDetails(inputdata);
        }
        public IEnumerable GetConsignmentDOSummaryReport(GE::ReportSearch reportSearch)
        {
            return new DA::ConsignmentDA().GetConsignmentDOSummaryReport(reportSearch);
        }
        public IEnumerable GetConsignmentReturnSummaryReport(GE::ReportSearch reportSearch)
        {
            return new DA::ConsignmentDA().GetConsignmentReturnSummaryReport(reportSearch);
        }
        public IEnumerable GetConsignmentDODetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::ConsignmentDA().GetConsignmentDODetailReport(reportSearch);
        }
        public IEnumerable GetConsignmentReturnDetailReport(GE::ReportSearch reportSearch)
        {
            return new DA::ConsignmentDA().GetConsignmentReturnDetailReport(reportSearch);
        }
    }
}
