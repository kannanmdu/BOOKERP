﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;

namespace BOOKERP.Business
{ 
    public class ReportBC
    {        
        public IEnumerable GetHeaderByCode(GE::ERPInputmodel inputdata)
        {
           return new DA::ReportDA().GetHeaderByCode(inputdata);
        }
        public List<GE::Report> GetAllMenu(GE::ERPInputmodel inputdata)
        {
            return new DA.ReportDA().GetAllMenu(inputdata);
        }
        public List<GE::Report> GetbySubMenu(GE::ERPInputmodel inputdata)
        {
            return new DA.ReportDA().GetbySubMenu(inputdata);
        }
        public List<GE::GetReportsByModule> GetReportsByModule(string ModuleName, int OrganizationId)
        {
            return new DA.ReportDA().GetReportsByModule(ModuleName, OrganizationId);
        }
        public List<GE::Report> GetAllReportMenu(GE::ERPInputmodel inputdata)
        {
            return new DA.ReportDA().GetAllReportMenu(inputdata);
        }
        public List<GE::POSSettingsList> GetPosSettings(GE::ERPInputmodel inputdata)
        {
            return new DA.ReportDA().GetPosSettings(inputdata);
        }
        public IEnumerable GetMasterReport(string Module, int OrgId)
        {
            return new DA.ReportDA().GetMasterReport(Module, OrgId);
        }        
        public IEnumerable GetCustomerReport(string Module, int OrgId)
        {
            return new DA.ReportDA().GetCustomerReport(Module, OrgId);
        }
        public IEnumerable GetInventoryReport(string Module, int OrgId)
        {
            return new DA.ReportDA().GetInventoryReport(Module, OrgId);
        }
        public IEnumerable GetMagazineReport(string Module, int OrgId)
        {
            return new DA.ReportDA().GetMagazineReport(Module, OrgId);
        }
        //public IEnumerable GetProductReport(string Module, int OrgId)
        //{
        //    return new DA.ReportDA().GetProductReport(Module, OrgId);
        //}
        //public IEnumerable GetProductDetailsReport(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetProductDetailsReport(reportSearch);
        //}
        //public IEnumerable GetHistoryStock(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetHistoryStock(reportSearch);
        //}
        //public IEnumerable GetProductStockMovement(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetProductStockMovement(reportSearch);
        //}
        //public IEnumerable GetProductStockValue(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetProductStockValue(reportSearch);
        //}        
        //public IEnumerable GetPricesettingsreport(GE::ERPInputmodel inputdata)
        //{
        //    return new DA.ReportDA().GetPricesettingsreport(inputdata);
        //}
        //public IEnumerable GetProfitOrLossReport(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetProfitOrLossReport(reportSearch);
        //}
        //public IEnumerable GetProfitOrLossWithIncomeExpenseReport(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetProfitOrLossWithIncomeExpenseReport(reportSearch);
        //}
        //public List<GE::BarcodeDetails> GetIndividualBarcode(GE::ReportSearch reportSearch)
        //{
        //    return new DA.ReportDA().GetIndividualBarcode(reportSearch);
        //}
    }
}