﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.Collections;
using System.Data;

namespace BOOKERP.Business
{
    public class SalesPosReportBC
    {   
        public IEnumerable GetSalesPosPayDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosPayDetails(inputdata);
        }
        public IEnumerable GetSalesPosSettlementDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosSettlementDetails(inputdata);
        }
        public IEnumerable GetSalesPosCashInOutDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosCashInOutDetails(inputdata);
        }
        public IEnumerable GetSettlementPaymode(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesPosReportDA().GetSettlementPaymode(inputdata);
        }
        public IEnumerable GetSalesPosPayPoymodeDetails(GE::ERPInputmodel inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosPayPoymodeDetails(inputdata);
        }
        public IEnumerable GetPOSInvoiceSummaryReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPOSInvoiceSummaryReport(inputdata);
        }
        public IEnumerable GetPOSInvoiceDetailReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPOSInvoiceDetailReport(inputdata);
        }
        public IEnumerable GetPOSCashInOutDetailReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPOSCashInOutDetailReport(inputdata);
        }
        public IEnumerable GetSalesPosSettlementSummaryReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosSettlementSummaryReport(inputdata);
        }
        public IEnumerable GetSalesPosSettlementDetailReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetSalesPosSettlementDetailReport(inputdata);
        }
        public IEnumerable GetPosHourlySalesReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPosHourlySalesReport(inputdata);
        }
        public IEnumerable GetPaymodeDetailsReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPaymodeDetailsReport(inputdata);
        }
        public IEnumerable GetPaymodeWiseSummaryReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPaymodeWiseSummaryReport(inputdata);
        }
        public IEnumerable GetPosInvoiceByProductReport(GE::ReportSearch inputdata)
        {
            return new DA::SalesPosReportDA().GetPosInvoiceByProductReport(inputdata);
        }
    }
}
