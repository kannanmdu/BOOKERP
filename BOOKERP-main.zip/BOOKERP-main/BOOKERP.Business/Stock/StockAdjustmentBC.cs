﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class StockAdjustmentBC
    {
        public List<GE::StockAdjustmentHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.StockAdjustmentDA().GetAll(inputdata);
        }
        public GE::StockAdjustmentHeaders GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.StockAdjustmentDA().GetbyCode(inputdata);
        }
        public string Save(GE::StockAdjustmentHeaders header, List<GE::StockAdjustmentDetails> details, string user, int OrganizationId)
        {
            return new DA.StockAdjustmentDA().Save(header, details, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.StockAdjustmentDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.StockAdjustmentDA().MakeActive(inputdata);
        }        
    }
}
