﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class StockTakeBC
    {
        DA::StockTakeDA _DA = new DA.StockTakeDA();
        public List<GE::StockTakeHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::StockTakeHeaders header, List<GE::StockTakeDetails> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public GE::StockTakeHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string UpdateStockByCode(GE::ERPInputmodel inputdata)
        {
            return _DA.UpdateStockByCode(inputdata);
        }        
    }
}
