﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class TransferBC
    {
        DA::TransferDA _DA = new DA.TransferDA();
        // Get All
        public List<GE::TransferHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public GE::TransferHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Save(GE::TransferHeaders header, List<GE::TransferDetails> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }       
    }
}
