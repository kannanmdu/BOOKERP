﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class BranchBC
    {        
        public List<GE::Branch> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.BranchDA().GetAll(inputdata);
        }

        public string Save(GE::Branch item, string user, int OrganizationId)
        {
            return new DA.BranchDA().Save(item, user, OrganizationId);
        }

        public GE::Branch GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BranchDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.BranchDA().Remove(inputdata);
        }

        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputdata)
        {
            return new DA.BranchDA().GetAllCountries(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.BranchDA().MakeActive(inputdata);
        }
    }
}
