﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SupplierBC
    {
        public List<GE::Supplier> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.SupplierDA().GetAll(inputdata);
        }

        public string Save(GE::Supplier item, string user, int OrganizationId)
        {
            return new DA.SupplierDA().Save(item, user, OrganizationId);
        }

        public GE::Supplier GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.SupplierDA().GetbyCode(inputdata);
        }        

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.SupplierDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.SupplierDA().MakeActive(inputdata);
        }

    }
}
