﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class FrequencyBC
    {
        DA.FrequencyDA _DA = new DA.FrequencyDA();
        public List<GE::Frequency> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::Frequency item, string user, int OrganizationId)
        {
            return _DA.Save(item, user, OrganizationId);
        }
        public GE::Frequency GetbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return _DA.MakeActive(inputdata);
        }
    }
}

