﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
   public class CashRegisterBC
    {   
        public List<GE::CashRegister> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.CashRegisterDA().GetAll(inputdata);
        }
        public GE::CashRegister GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.CashRegisterDA().GetbyCode(inputdata);
        }
        public GE::CashRegister GetMachineNameByName(GE::ERPInputmodel inputdata)
        {
            return new DA.CashRegisterDA().GetMachineNameByName(inputdata);
        }
        public string Save(GE::CashRegister item, string user, int OrganizationId)
        {
            return new DA.CashRegisterDA().Save(item, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.CashRegisterDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CashRegisterDA().MakeActive(inputdata);
        }
    }
}
