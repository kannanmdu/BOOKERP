﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class UserBC
    {        
        public List<GE::User> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.UserDA().GetAll(inputdata);
        }

        public string Save(GE::User item, string user, int OrganizationId)
        {
            return new DA.UserDA().Save(item, user, OrganizationId);
        }

        public GE::User GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.UserDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.UserDA().Remove(inputdata);
        }
        
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.UserDA().MakeActive(inputdata);
        }

        public GE::User GetbyLogin(GE::LoginModel loginModel)
        {
            return new DA.UserDA().GetbyLogin(loginModel);
        }
        public string GetbyDecrypted(string Username, int orgid)
        {
            return new DA.UserDA().GetbyDecrypted(Username, orgid);
        }
        public bool CheckAdministratorlogin(GE::LoginModel loginModel)
        {
            return new DA.UserDA().CheckAdministratorlogin(loginModel);
        }
    }
}
