﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class CategoryBC
    {
        public List<GE::Category> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.CategoryDA().GetAll(inputdata);
        }

        public string Save(GE::Category item, List<GE::CategoryTag> Tags, string user, int OrganizationId)
        {
            return new DA.CategoryDA().Save(item, Tags, user, OrganizationId);
        }

        public GE::Category GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.CategoryDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.CategoryDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CategoryDA().MakeActive(inputdata);
        }
    }
}
