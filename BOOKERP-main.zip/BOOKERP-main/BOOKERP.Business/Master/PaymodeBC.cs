﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class PaymodeBC
    {
        public List<GE::Paymode> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.PaymodeDA().GetAll(inputdata);
        }
        public string Save(GE::Paymode item, string user, int OrganizationId)
        {
            return new DA.PaymodeDA().Save(item, user, OrganizationId);
        }
        public GE::Paymode GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.PaymodeDA().GetbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.PaymodeDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.PaymodeDA().MakeActive(inputdata);
        }
    }
}

