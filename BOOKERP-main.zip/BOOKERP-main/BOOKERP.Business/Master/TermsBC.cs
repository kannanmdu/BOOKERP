﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class TermsBC
    {
        public List<GE::Terms> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.TermsDA().GetAll(inputdata);
        }
        public string Save(GE::Terms item, string user, int OrganizationId)
        {
            return new DA.TermsDA().Save(item, user, OrganizationId);
        }

        public GE::Terms GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.TermsDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.TermsDA().Remove(inputdata);
        }
        
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.TermsDA().MakeActive(inputdata);
        }
    }
}
