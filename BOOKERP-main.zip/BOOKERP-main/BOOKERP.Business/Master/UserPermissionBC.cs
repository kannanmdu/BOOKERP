﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class UserPermissionBC
    {
        public List<GE::UserPermission> GetAll(GE::ERPInputmodel inputData)
        {
            return new DA.UserPermissionDA().GetAll(inputData);
        }
        public string Save(List<GE::UserPermission> details, string user, int organisationId)
        {
            return new DA.UserPermissionDA().Save(details, user, organisationId);
        }
        public List<GE::UserPermission> GetbyCode(GE::ERPInputmodel inputData)
        {
            return new DA.UserPermissionDA().GetbyCode(inputData);
        }
    }
}
