﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class TaxBC
    {
        public List<GE::Tax> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.TaxDA().GetAll(inputdata);
        }
        public string Save(GE::Tax item, string user, int OrganizationId)
        {
            return new DA.TaxDA().Save(item, user, OrganizationId);
        }

        public GE::Tax GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.TaxDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.TaxDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.TaxDA().MakeActive(inputdata);
        }

    }
}
