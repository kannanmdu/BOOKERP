﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
  public  class OrganizationBC
    {
        public List<GE::Organization> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetAll(inputdata);
        }

        public string Save(GE::Organization item, string user, int OrganizationId)
        {
            return new DA.OrganizationDA().Save(item, user, OrganizationId);
        }

        public GE::Organization GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().Remove(inputdata);
        }
        public List<GE::Currency> GetAllCurrency(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetAllCurrency(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().MakeActive(inputdata);
        }

        public List<GE::ERPSetting> GetCommonSettings(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetERPCommonSetting(inputdata);
        }
        public List<GE::Organization> GetListbyCode(int OrganizationId, string user)
        {
            return new DA.OrganizationDA().GetListbyCode(OrganizationId, user);
        }

        public string UploadImg(GE::Organization item, string user, int OrganizationId)
        {
            return new DA.OrganizationDA().ImageSave(item, user, OrganizationId);
        }

        public string SaveShopee(GE::MasterShopee item, string user, int OrganizationId)
        {
            return new DA.OrganizationDA().SaveShopee(item, user, OrganizationId);
        }

        public GE::MasterShopee GetByCodeShopee(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetByCodeShopee(inputdata);
        }

        public List<GE::MasterShopee> GetAllShopee(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetAllShopee(inputdata);
        }

        public string SaveLazada(GE::MasterLazada item, string user, int OrganizationId)
        {
            return new DA.OrganizationDA().SaveLazada(item, user, OrganizationId);
        }

        public GE::MasterLazada GetByCodeLazada(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetByCodeLazada(inputdata);
        }

        public List<GE::MasterLazada> GetAllLazada(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().GetAllLazada(inputdata);
        }

        public bool DeleteByCodeLazada(GE::ERPInputmodel inputdata)
        {
            return new DA.OrganizationDA().DeleteByCodeLazada(inputdata);
        }
    }
}
