﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class GiftVoucherBC
    {
        public List<GE::GiftVoucher> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.GiftVoucherDA().GetAll(inputdata);
        }
        public string Save(GE::GiftVoucher item, string user, int OrganizationId)
        {
            return new DA.GiftVoucherDA().Save(item, user, OrganizationId);
        }
        public GE::GiftVoucher GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.GiftVoucherDA().GetbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.GiftVoucherDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.GiftVoucherDA().MakeActive(inputdata);
        }
    }
}

