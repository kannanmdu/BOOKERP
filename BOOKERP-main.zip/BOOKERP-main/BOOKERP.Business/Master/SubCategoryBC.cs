﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SubCategoryBC
    {
        public List<GE::SubCategory> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.SubCategoryDA().GetAll(inputdata);
        }

        public string Save(GE::SubCategory item, List<GE::SubCategoryTag> Tags, string user, int OrganizationId)
        {
            return new DA.SubCategoryDA().Save(item, Tags, user, OrganizationId);
        }
        public GE::SubCategory GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.SubCategoryDA().GetbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.SubCategoryDA().Remove(inputdata);
        }
        public List<GE::SubCategory> GetbyCategoryCode(GE::ERPInputmodel inputdata)
        {
            return new DA.SubCategoryDA().GetbyCategoryCode(inputdata);
        }
    }
}
