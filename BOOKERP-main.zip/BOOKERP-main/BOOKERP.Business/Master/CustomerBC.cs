﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;


namespace BOOKERP.Business
{
    public class CustomerBC
    {
        public List<GE::Customer> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerDA().GetAll(inputdata);
        }

        public string Save(GE::Customer item, string user, int OrganizationId)
        {
            return new DA.CustomerDA().Save(item, user, OrganizationId);
        }

        public GE::Customer GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerDA().MakeActive(inputdata);
        }
    }
}
