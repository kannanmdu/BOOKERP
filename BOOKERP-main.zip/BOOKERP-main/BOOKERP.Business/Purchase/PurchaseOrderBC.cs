﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class PurchaseOrderBC
    {
        public List<GE::PurchaseOrderHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.PurchaseOrderDA().GetAll(inputdata);
        }
        public string Save(GE::PurchaseOrderHeader header, List<GE::PurchaseOrderDetails> details, string user)
        {
            return new DA.PurchaseOrderDA().Save(header, details, user);
        }
        public GE::PurchaseOrderHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.PurchaseOrderDA().GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.PurchaseOrderDA().Remove(inputdata);
        }
    }
}
