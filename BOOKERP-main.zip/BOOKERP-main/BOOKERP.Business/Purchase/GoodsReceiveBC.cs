﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class GoodsReceive   
    {
        DA::GoodsReceiveDA _DA = new DA.GoodsReceiveDA();

        public List<GE::Coamaster> GetAllAccounts(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAllAccounts(inputdata);
        }
        public List<GE::GRAHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }       
        public string Save(GE::GRAHeader header, List<GE::GRADetails> details, string user, List<GE::ConsignmentOutDODetail> consignmentdetails)
        {
            return _DA.Save(header, details, user, consignmentdetails);
        }
        public GE::GRAHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public GE::SupplierPrices GetsupplierPrice(GE::ERPInputmodel inputdata)
        {
            return _DA.GetsupplierPrice(inputdata);
        }
        public GE::GRAHeader CheckGRAInvoiceDuplicate(GE::ERPInputmodel inputdata)
        {
            return _DA.CheckGRAInvoiceDuplicate(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public List<GE::GRAHeader> GetAllOutStanding(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAllOutStanding(inputdata);
        }
        public List<GE::GRAHeader> GetHeaderbySearch(GE::ERPInputmodel search)
        {
            return _DA.GetHeaderbySearch(search);
        }
    }
}
