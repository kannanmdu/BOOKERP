﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class PurchaseReturnBC
    {
        DA::PurchaseReturnDA _DA = new DA.PurchaseReturnDA();
        // Get All
        public List<GE::PurchaseReturnHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::PurchaseReturnHeader header, List<GE::PurchaseReturnDetails> details, string user)
        {
            return _DA.Save(header, details, user);
        }       
        public GE::PurchaseReturnHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
    }
}
