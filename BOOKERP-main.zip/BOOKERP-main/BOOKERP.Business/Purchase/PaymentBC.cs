﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
namespace BOOKERP.Business
{
    public class PaymentBC
    {
        DA::PaymentDA _DA = new DA.PaymentDA();

        public List<GE::PaymentHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public GE::PaymentHeader GetHeaderbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetHeaderbyCode(inputdata);
        }
        public List<GE::PaymentDetail> GetDetailbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetDetailbyCode(inputdata);
        }
        public string Save(GE::PaymentHeader header, List<GE::PaymentDetail> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public List<GE::TransactionForPayment> GetAllforPayment(string SupplierCode, string TranNo, string User, int OrganisationId)
        {
            return _DA.GetAllforPayment(SupplierCode, TranNo, User, OrganisationId);
        }

    }
}
