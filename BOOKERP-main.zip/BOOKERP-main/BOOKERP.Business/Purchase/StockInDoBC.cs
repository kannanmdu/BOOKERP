﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
     public class StockInDoBC
    {
        DA::StockInDoDA _DA = new DA.StockInDoDA();
        public List<GE::StockInDoHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.StockInDoDA().GetAll(inputdata);
        }
        public string Save(GE::StockInDoHeader header, List<GE::StockInDoDetails> details, string user)
        {
            return new DA.StockInDoDA().Save(header, details, user);
        }

        public GE::StockInDoHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.StockInDoDA().Remove(inputdata);
        }
    }
}
