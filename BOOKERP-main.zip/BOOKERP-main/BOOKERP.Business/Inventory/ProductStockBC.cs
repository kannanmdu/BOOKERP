﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class ProductStockBC
    {
        public List<GE::ProductStock> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.ProductStockDA().GetAll(inputdata);
        }

        public List<GE::ProductStock> GetAllStockInfo(GE::ERPInputmodel inputdata)
        {
            return new DA.ProductStockDA().GetAllStockInfo(inputdata);
        }

        public List<GE::ProductStock> GetAllStockMovement(GE::ERPInputmodel inputdata)
        {
            return new DA.ProductStockDA().GetAllStockMovement(inputdata);
        }
    }
}
