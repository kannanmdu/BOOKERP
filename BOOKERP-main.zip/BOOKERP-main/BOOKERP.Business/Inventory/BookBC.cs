﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;
using System.IO;
namespace BOOKERP.Business
{
  
 public class BookBC
    {
        public List<GE::Book> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetAll(inputdata);
        }
        public async Task<List<GE::Book>> GetAllProduct(GE::ERPInputmodel inputdata)
        {
            return await new DA.BOOKDA().GetAllProduct(inputdata);
        }
        public async Task<List<GE::Book>> GetAllProductAutocomplete(GE::ERPInputmodel inputdata)
        {
            return await new DA.BOOKDA().GetAllProductAutocomplete(inputdata);
        }
        public List<GE::Book> GetAllProductMagazine(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetAllProductMagazine(inputdata);
        }
        public string Save(GE::Book item, string user, int OrganizationId, List<GE.ProductTags> productTags, List<GE::EcommerceMultiTenant> multiTenent, List<GE::SupplierPrices> _SupplierPrice)
        {
            return new DA.BOOKDA().Save(item, user, OrganizationId, productTags, multiTenent, _SupplierPrice);
        }
        public GE::Book GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetbyCode(inputdata);
        }
        public GE::Book GetbyIsbnCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetbyIsbnCode(inputdata);
        }
        public GE::Book GetbyIsbn10Code(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetbyIsbn10Code(inputdata);
        }
        public GE::Book GetByCodePosAdd(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetByCodePosAdd(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().MakeActive(inputdata);
        }
        public List<GE::BookStock> GetAllProductWithStock(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetAllProductWithStock(inputdata);
        }
        public List<GE::Book> GetbyTagCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetbyTagCode(inputdata);
        }
        public List<GE::BookAuthorSearch> GetAllByAuthor(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetAllByAuthor(inputdata);
        }
        public List<GE::CategoryTag> GetByCategoryTagCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetByCategoryTagCode(inputdata);
        }
        public List<GE::SubCategoryTag> GetBySubCategoryTagCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetBySubCategoryTagCode(inputdata);
        }

        public string SaveShopeeToken(GE::ShopeeResponse item, string user, int OrganizationId)
        {
            return new DA.BOOKDA().SaveShopeeToken(item, user, OrganizationId);
        }

        public GE::ShopeeToken GetShopeeAccessToken(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetShopeeAccessToken(inputdata);
        }

        public List<GE.MultiTenant> GetMultiTenant(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetMultiTenant(inputdata);
        }
        public List<GE.EcommerceMultiTenant> GetTenentbyBookId(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetTenentbyBookId(inputdata);
        }
        public string GetbyLazadaShopCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BOOKDA().GetbyLazadaShopCode(inputdata);
        }
        public bool DeleteLazadaProduct(string BookId, string ShopCode, string OAuth)
        {
            return new DA.BOOKDA().DeleteLazadaProduct(BookId, ShopCode, OAuth).GetAwaiter().GetResult();
        }
    }
}
