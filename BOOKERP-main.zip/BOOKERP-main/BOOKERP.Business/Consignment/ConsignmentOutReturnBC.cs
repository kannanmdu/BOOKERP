﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class ConsignmentOutReturnBC
    {
        DA::ConsignmentOutReturnDA _DA = new DA.ConsignmentOutReturnDA();
        public List<GE::ConsignmentOutReturnHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::ConsignmentOutReturnHeader header, List<GE::ConsignmentOutReturnDetail> details, string user, List<GE::ConsignmentOutDODetail> consignmentdetails)
        {
            return _DA.Save(header, details, user, consignmentdetails);
        }
        public GE::ConsignmentOutReturnHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
    }
}
