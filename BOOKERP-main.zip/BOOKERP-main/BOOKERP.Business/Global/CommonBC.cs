﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class CommonBC
    {
        public bool IsMobileExist(string module, string mobile, int orgId)
        {
            return new DA.CommonDA().IsMobileExist(module, mobile, orgId);
        }
        public bool IsEmailExist(string module, string email, int orgId)
        {
            return new DA.CommonDA().IsEmailExist(module, email, orgId);
        }
        public bool IsCodeExist(string module, string code, int orgId)
        {
            return new DA.CommonDA().IsCodeExist(module, code, orgId);
        }       
        public bool IsNameExist(string module, string name, int orgId)
        {
            return new DA.CommonDA().IsNameExist(module, name, orgId);
        }
        public bool GetAddressAPIDetails(string module, string apiAddress, int orgId, string branchCode, string user)
        {
            return new DA.CommonDA().GetAddressAPIDetails(module, apiAddress, orgId, branchCode, user);
        }
        public GE::Roleaccess GetAccessPermissionbyModule(string MenuName, string UserRole, string LoginUser, int OrganisationId)
        {
            return new DA.CommonDA().GetAccessPermissionbyModule(MenuName, UserRole, LoginUser, OrganisationId);
        }
        public GE::EmailTemplate GetbyEmailTemplate(GE::ERPInputmodel inputdata)
        {
            return new DA.CommonDA().GetbyEmailTemplate(inputdata);
        }

        public bool SaveOTP(GE::RegisterOTP header, string Type)
        {
            return new DA.CommonDA().SaveOTP(header, Type);
        }
        public string GetOTP(GE::RegisterOTP header, string Type)
        {
            return new DA.CommonDA().GetOTP(header, Type);
        }
    }
}
