﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class DashboardBC
    {
        public List<GE::DashboardMaster> GetMasterInfo(int OrgId, string User)
        {
            return new DA.DashboardDA().GetMasterInfo(OrgId, User);
        }

        public List<GE::DashboardTransaction> GetTransactionInfo(int OrgId, string User)
        {
            return new DA.DashboardDA().GetTransactionInfo(OrgId, User);
        }
    }
}
