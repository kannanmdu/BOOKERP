﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class MagazinesBC
    {
        public List<GE::Magazines> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.MagazinesDA().GetAll(inputdata);
        }

        public string Save(GE::Magazines item, string user, int OrganizationId)
        {
            return new DA.MagazinesDA().Save(item, user, OrganizationId);
        }

        public GE::Magazines GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.MagazinesDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.MagazinesDA().Remove(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.MagazinesDA().MakeActive(inputdata);
        }

    }
}
