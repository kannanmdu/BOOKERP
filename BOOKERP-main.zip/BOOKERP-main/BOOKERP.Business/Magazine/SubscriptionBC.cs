﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SubscriptionBC
    {
        DA.SubscriptionDA _DA = new DA.SubscriptionDA();
        public List<GE::Subscription> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::Subscription item, string user, int OrganizationId)
        {
            return _DA.Save(item, user, OrganizationId);
        }
        public GE::Subscription GetbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return _DA.MakeActive(inputdata);
        }
    }
}
