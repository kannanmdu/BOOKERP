﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class JournalVoucherBC
    {
        DA::JournalVoucherManagerDA _DA = new DA.JournalVoucherManagerDA();
        // Get All
        public List<GE::JournalVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::JournalVoucherHeader header, List<GE::JournalVoucherDetail> jvdetails, string user)
        {
            return new DA.JournalVoucherManagerDA().Save(header, jvdetails, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.JournalVoucherManagerDA().Remove(inputdata);
        }
        public GE::JournalVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public List<GE::JournalVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSearchData(inputdata);
        }
    }
}
