﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class OpeningBalanceBC
    {
        DA::OpeningBalanceDA _DA = new DA.OpeningBalanceDA();
        // Get All
        public List<GE::OpeningBalance> GetOpeningBalanceDetails(GE::ERPInputmodel inputdata)
        {
            return _DA.GetOpeningBalanceDetails(inputdata);
        }
        public string Save(List<GE::OpeningBalance> _accountdetails, string user, int orgId)
        {
            return _DA.Save(_accountdetails, user, orgId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
    }
}
