﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class ChartOfAccountBC
    {
        // Get All
        public List<GE::Chartofaccount> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.ChartOfAccountDA().GetAll(inputdata);
        }
        public List<GE::GetChildAccount> GetAllAccount(GE::ERPInputmodel inputdata)
        {
            return new DA.ChartOfAccountDA().GetAllAccount(inputdata);
        }
        public GE::Chartofaccount GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.ChartOfAccountDA().GetbyCode(inputdata);
        }
        public string Save(GE::Chartofaccount item, string user, int OrganizationId)
        {
            return new DA.ChartOfAccountDA().Save(item, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.ChartOfAccountDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.ChartOfAccountDA().MakeActive(inputdata);
        }
    }
}
