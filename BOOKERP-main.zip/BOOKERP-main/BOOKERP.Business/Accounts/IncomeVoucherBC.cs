﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class IncomeVoucherBC
    {
        DA::IncomeVoucherManagerDA _DA = new DA.IncomeVoucherManagerDA();
        // Get All
        public List<GE::AccountVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }

        public string Save(GE::AccountVoucherHeader header, List<GE::AccountVoucherDetail> _accountdetails, string user)
        {
            return new DA.IncomeVoucherManagerDA().Save(header, _accountdetails, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.IncomeVoucherManagerDA().Remove(inputdata);
        }
        public GE::AccountVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public List<GE::AccountVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSearchData(inputdata);
        }
    }
}
