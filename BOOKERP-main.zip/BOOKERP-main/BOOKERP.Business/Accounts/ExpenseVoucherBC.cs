﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class ExpenseVoucherBC
    {
        DA::ExpenseVoucherManagerDA _DA = new DA.ExpenseVoucherManagerDA();
        // Get All
        public List<GE::AccountVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::AccountVoucherHeader header, List<GE::AccountVoucherDetail> _accountdetails, string user)
        {
            return new DA.ExpenseVoucherManagerDA().Save(header, _accountdetails, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.ExpenseVoucherManagerDA().Remove(inputdata);
        }
        public GE::AccountVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public List<GE::AccountVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSearchData(inputdata);
        }
    }
}
