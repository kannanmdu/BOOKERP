﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class GetAccountingDetailBC
    {
        public List<GE::GetAccountingDetail> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.GetAccountingDetailDA().GetAll(inputdata);
        }

        public List<GE::GetAccountingDetail> GetAllProfitLoss(GE::ERPInputmodel inputdata)
        {
            return new DA.GetAccountingDetailDA().GetAllProfitLoss(inputdata);
        }

        public List<GE::GetAccountingDetail> GetAllTrialBalance(GE::ERPInputmodel inputdata)
        {
            return new DA.GetAccountingDetailDA().GetAllTrialBalance(inputdata);
        }

        public List<GE::GetAccountingDetail> GetAllBalanceSheet(GE::ERPInputmodel inputdata)
        {
            return new DA.GetAccountingDetailDA().GetAllBalanceSheet(inputdata);
        }

        public GE::FinancialSettings GetFinancialSetting(GE::ERPInputmodel inputdata)
        {
            return new DA.GetAccountingDetailDA().GetFinancialSetting(inputdata);
        }

        //public List<GE::GSTReport> GetGSTDetailReport(GE::ReportSearch reportSearch)
        //{
        //    return new DA::SalesReportDA().GetGSTDetailReport(reportSearch);
        //}

        //public List<GE::GSTReport> GetGSTDetailWithType(GE::ReportSearch reportSearch)
        //{
        //    return new DA::SalesReportDA().GetGSTDetailWithType(reportSearch);
        //}
        public string Save(GE::FinancialSettings item, string user, int OrganizationId)
        {
            return new DA.GetAccountingDetailDA().Save(item, user, OrganizationId);
        }
    }
}
