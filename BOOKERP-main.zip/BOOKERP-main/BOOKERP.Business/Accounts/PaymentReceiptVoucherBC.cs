﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class PaymentReceiptVoucherBC
    {
        DA::PaymentReceiptVoucherDA _DA = new DA.PaymentReceiptVoucherDA();
        // Get All
        public List<GE::PaymentReceiptVoucherHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string Save(GE::PaymentReceiptVoucherHeaders header, List<GE::PaymentReceiptVoucherDetails> _details, string user)
        {
            return _DA.Save(header, _details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public GE::PaymentReceiptVoucherHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public List<GE::PaymentReceiptVoucherHeaders> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSearchData(inputdata);
        }
    }
}
