﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class BankReconciliationBC
    {
        public List<GE::GetAccountingDetail> GetAllReconciliationList(GE::ERPInputmodel inputdata)
        {
            return new DA.BankReconciliationDA().GetAllReconciliationList(inputdata);
        }
        public string Save(GE::BankReconciliation header, List<GE::ERPInputmodel> list)
        {
            return new DA.BankReconciliationDA().Save(header, list);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.BankReconciliationDA().Remove(inputdata);
        }
        public GE::BankReconciliation GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.BankReconciliationDA().GetTransactionbyCode(inputdata);
        }
        public List<GE::BankReconciliation> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.BankReconciliationDA().GetAll(inputdata);
        }
    }
}
