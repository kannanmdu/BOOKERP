﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class AttendanceBC
    {
        public GE::HRMSAttendance GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.AttendanceDA().GetAll(inputdata);
        }

        public string Save(List<GE::HRMSAttendance> item, string user, int OrganizationId)
        {
            return new DA.AttendanceDA().Save(item, user, OrganizationId);
        }

        public GE::HRMSAttendance GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.AttendanceDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.AttendanceDA().Remove(inputdata);
        }

        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputdata)
        {
            return new DA.AttendanceDA().GetAllCountries(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.AttendanceDA().MakeActive(inputdata);
        }
    }
}
