﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class LeaveBC
    {
        public List<GE::HRMSLeave> GetAll(GE::ERPInputmodel inputdata)

        {
            return new DA.LeaveDA().GetAll(inputdata);
        }

        public string Save(GE::HRMSLeave item, string user, int OrganizationId)
        {
            return new DA.LeaveDA().Save(item, user, OrganizationId);
        }

        public GE::HRMSLeave GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.LeaveDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.LeaveDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.LeaveDA().MakeActive(inputdata);
        }
        public List<GE::HRMSLeave> GetAllCountries(GE::ERPInputmodel inputdata)
        {
            return new DA.LeaveDA().GetAllLeave(inputdata);
        }
    }
}
