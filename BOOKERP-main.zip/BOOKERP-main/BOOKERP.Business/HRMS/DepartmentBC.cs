﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class DepartmentBC
    {

        public List<GE::HRMSDepartment> GetAll(GE::ERPInputmodel inputdata)
        
        {
            return new DA.DepartmentDA().GetAll(inputdata);
        }

        public string Save(GE::HRMSDepartment item, string user, int OrganizationId)
        {
            return new DA.DepartmentDA().Save(item, user, OrganizationId);
        }

        public GE::HRMSDepartment GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.DepartmentDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.DepartmentDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.DepartmentDA().MakeActive(inputdata);
        }
    }
}
