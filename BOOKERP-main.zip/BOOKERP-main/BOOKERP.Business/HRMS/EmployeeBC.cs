﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class EmployeeBC
    {
        public List<GE::HRMSEmployee> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.EmployeeDA().GetAll(inputdata);
        }

        public string Save(GE::HRMSEmployee item, string user, int OrganizationId)
        {
            return new DA.EmployeeDA().Save(item, user, OrganizationId);
        }

        public GE::HRMSEmployee GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.EmployeeDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.EmployeeDA().Remove(inputdata);
        }

        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputdata)
        {
            return new DA.EmployeeDA().GetAllCountries(inputdata);
        }

        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.EmployeeDA().MakeActive(inputdata);
        }

        public List<GE::HRMSDepartment> GetAllDepartment(GE::ERPInputmodel inputdata)

        {
            return new DA.EmployeeDA().GetAllDepart(inputdata);
        }

        public List<GE::HRMSDesignation> GetDesignationByDepartmentCode(GE::ERPInputmodel inputdata)

        {
            return new DA.EmployeeDA().GetDesignationByDepartmentCode(inputdata);
        }


    }
}
