﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class DesignationBC
    {

        public List<GE::HRMSDesignation> GetAll(GE::ERPInputmodel inputdata)

        {
            return new DA.DesignationDA().GetAll(inputdata);
        }

        public string Save(GE::HRMSDesignation item, string user, int OrganizationId)
        {
            return new DA.DesignationDA().Save(item, user, OrganizationId);
        }

        public List<GE::HRMSDepartment> GetDepartment(GE::ERPInputmodel inputdata)
        {
            return new DA.DesignationDA().GetDepartment(inputdata);
        }

        public GE::HRMSDesignation GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.DesignationDA().GetbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.DesignationDA().Remove(inputdata);
        }
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            return new DA.DesignationDA().MakeActive(inputdata);
        }
    }
}




