﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class PosHoldInvoiceBC
    {
        DA::PosHoldInvoiceDA _DA = new DA.PosHoldInvoiceDA();
        // Get All
        public string Save(GE::POSInvoiceHeadersHoldInfo header, List<GE::POSInvoiceDetailHoldInfo> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public List<GE::POSInvoiceHeadersHoldInfo> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public string RemovePosHoldbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.RemovePosHoldbyCode(inputdata);
        }
        public GE::POSInvoiceHeadersHoldInfo GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
    }
}
