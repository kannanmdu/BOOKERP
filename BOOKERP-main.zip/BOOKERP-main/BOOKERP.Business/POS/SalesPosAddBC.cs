﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SalesPosAddBC
    {
        DA::SalesPosAddDA _DA = new DA.SalesPosAddDA();
        public List<GE::Paymode> GetAllPaymodes(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAllPaymodes(inputdata);
        }
        public GE::ProductpriceforTransaction GetProductPriceforTransaction(GE::ERPInputmodel inputdata)
        {
            return _DA.GetProductPriceforTransaction(inputdata);
        }
        public GE::CashRegister CheckOpeningBalance(GE::ERPInputmodel inputdata)
        {
            return _DA.CheckOpeningBalance(inputdata);
        }
        public string SaveOpeningBalance(GE::POSCashRegisterOpeningBalance header, string user)
        {
            return _DA.SaveOpeningBalance(header, user);
        }
        public string Save(GE::POSInvoice_Header header, List<GE::POSInvoice_Detail> details, List<GE::PosPayment> _PosPayment, string user)
        {
            return _DA.Save(header, details, _PosPayment, user);
        }
        public string SaveReservation(GE::POSInvoice_Header header, List<GE::POSInvoice_Detail> details, List<GE::PosPayment> _PosPayment, string user)
        {
            return _DA.SaveReservation(header, details, _PosPayment, user);
        }
    }
}
