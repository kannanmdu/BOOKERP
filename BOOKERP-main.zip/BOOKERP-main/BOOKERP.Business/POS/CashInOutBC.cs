﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
  public class CashInOutBC
    {
        DA::CashInOutDA _DA = new DA.CashInOutDA();

        public List<GE::POSCashInOut> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }            
        public GE::POSCashInOut GetbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetbyCode(inputdata);
        }
        public string Save(GE::POSCashInOut header, string user)
        {
            return _DA.Save(header, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
    }
}
