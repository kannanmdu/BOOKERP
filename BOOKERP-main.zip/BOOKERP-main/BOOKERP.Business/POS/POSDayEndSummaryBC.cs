﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class POSDayEndSummaryBC
    {
       DA::POSDayEndSummaryDA _DA = new DA.POSDayEndSummaryDA();
        // Get All
        public List<GE::POSDayEndSummary> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }       
        public string Save(GE::POSDayEndSummary info, string user)
        {
            return _DA.Save(info, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public List<GE::POSDayEndSummaryDetails> GetDayEndSummaryDetails(GE::ERPInputmodel inputdata)
        {
            return _DA.GetDayEndSummaryDetails(inputdata);
        }
    }
}
