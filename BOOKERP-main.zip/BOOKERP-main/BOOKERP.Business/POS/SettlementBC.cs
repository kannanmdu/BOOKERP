﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{    public class POSSettlementBC
    {
        DA::POSSettlementDA _DA = new DA.POSSettlementDA();
        // Get All
        public List<GE::POSSettlementHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public GE::POSSettlementDetails GetSettlementDetails(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSettlementDetails(inputdata);
        }
        public List<GE::POSPaymode> GetTodaySettlementDetails(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTodaySettlementDetails(inputdata);
        }        
        public GE::POSSettlementHeaders GetTodayCashInOutDetails(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTodayCashInOutDetails(inputdata);
        }
        public string Save(GE::POSSettlementHeaders header, List<GE::POSSettlementDetail> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public GE::POSSettlementHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }   
    }
}

