﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SalesDOBC
    {
        DA::SalesDODA _DA = new DA.SalesDODA();
        public List<GE::SalesDOHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesDODA().GetAll(inputdata);
        }
        public string Save(GE::SalesDOHeaders header, List<GE::SalesDODetails> details, string user)
        {
            return new DA.SalesDODA().Save(header, details, user);
        }
        public GE::SalesDOHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesDODA().Remove(inputdata);
        }
    }
}
