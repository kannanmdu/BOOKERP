﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SalesOrderBC
    {
        DA::SalesOrderDA _DA = new DA.SalesOrderDA();
        public GE::Customer GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesOrderDA().GetbyCode(inputdata);
        }

        public List<GE::SalesOrderHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }

        public string Save(GE::SalesOrderHeader header, List<GE::SalesOrderDetails> details, string user)
        {
            return new DA.SalesOrderDA().Save(header, details, user);
        }

        public GE::SalesOrderHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesOrderDA().Remove(inputdata);
        }
    }
}
