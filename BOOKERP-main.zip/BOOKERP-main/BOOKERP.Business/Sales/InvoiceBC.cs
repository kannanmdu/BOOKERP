﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class InvoiceBC
    {
        DA::InvoiceDA _DA = new DA.InvoiceDA();
        public List<GE::InvoiceHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.InvoiceDA().GetAll(inputdata);
        }
        public GE::Customer GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesOrderDA().GetbyCode(inputdata);
        }

        public string Save(GE::InvoiceHeader header, List<GE::InvoiceDetail> details, string user, List<GE::ConsignmentOutDODetail> consignmentdetails)
        {
            return new DA.InvoiceDA().Save(header, details, user, consignmentdetails);
        }

        public GE::InvoiceHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.InvoiceDA().Remove(inputdata);
        }

        public List<GE::InvoiceHeader> GetHeaderbySearch(GE::ERPInputmodel search)
        {
            return _DA.GetHeaderbySearch(search);
        }

    }
}
