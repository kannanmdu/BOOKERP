﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class SalesQuoteBC
    {
        DA::SalesQuoteDA _DA = new DA.SalesQuoteDA();
        public List<GE::SalesQuoteHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesQuoteDA().GetAll(inputdata);
        }
        public string Save(GE::SalesQuoteHeader header, List<GE::SalesQuoteDetails> details, string user)
        {
            return new DA.SalesQuoteDA().Save(header, details, user);
        }
        public GE::SalesQuoteHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.SalesQuoteDA().Remove(inputdata);
        }
    }
}
