﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class ReceiptBC
    {
        DA::ReceiptDA _DA = new DA.ReceiptDA();
        //public List<GE::TransactionForPayment> GetAllforPayment(string CustomerCode, string TranNo, int DeliveryCode, string User, int OrganisationId)
        //{
        //    return new DA.ReceiptDA().GetAllforPayment(CustomerCode, TranNo, DeliveryCode, User, OrganisationId);
        //}

        public List<GE::ReceiptHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public GE::ReceiptHeader GetHeaderbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetHeaderbyCode(inputdata);
        }
        public List<GE::ReceiptDetail> GetDetailbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetDetailbyCode(inputdata);
        }
        public string Save(GE::ReceiptHeader header, List<GE::ReceiptDetail> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public List<GE::TransactionForPayment> GetAllforPayment(string CustomerCode, string TranNo, string User, int OrganisationId)
        {
            return _DA.GetAllforPayment(CustomerCode, TranNo, User, OrganisationId);
        }
    }
}
