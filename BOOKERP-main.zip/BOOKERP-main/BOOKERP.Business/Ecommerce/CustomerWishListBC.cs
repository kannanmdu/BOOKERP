﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class CustomerWishListBC
    {
        // Get All
        public List<GE::CustomerWishList> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().GetAll(inputdata);
        }

        public List<GE::CustomerWishList> GetAllActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().GetAllActive(inputdata);
        }

        public List<GE::CustomerWishList> GetByCustomer(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().GetByCustomer(inputdata);
        }

        public GE::CustomerWishList GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().GetbyCode(inputdata);
        }

        public string Save(GE::CustomerWishList item, string user, int OrganizationId)
        {
            return new DA.CustomerWishListDA().Save(item, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().Remove(inputdata);
        }
        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            return new DA.CustomerWishListDA().ActiveInActive(inputdata);
        }
    }
}
