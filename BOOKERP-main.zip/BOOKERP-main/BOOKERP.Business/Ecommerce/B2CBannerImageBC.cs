﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class B2CBannerImageBC
    {
        // Get All
        public List<GE::B2CBannerImage> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CBannerImageDA().GetAll(inputdata);
        }
        public List<GE::B2CBannerImage> GetAllActive(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CBannerImageDA().GetAllActive(inputdata);
        }
        public GE::B2CBannerImage GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CBannerImageDA().GetbyCode(inputdata);
        }
        public string Save(GE::B2CBannerImage item, string user, int OrganizationId)
        {
            return new DA.B2CBannerImageDA().Save(item, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CBannerImageDA().Remove(inputdata);
        }       
        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CBannerImageDA().ActiveInActive(inputdata);
            
        }
    }
}
