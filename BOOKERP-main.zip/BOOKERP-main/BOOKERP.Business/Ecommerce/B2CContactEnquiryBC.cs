﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class B2CContactEnquiryBC
    {
        // Get All
        public List<GE::B2CContactEnquiry> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CContactEnquiryDA().GetAll(inputdata);
        }

        public GE::B2CContactEnquiry GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CContactEnquiryDA().GetbyCode(inputdata);
        }

        public string Save(GE::B2CContactEnquiry item, string user, int OrganizationId)
        {
            return new DA.B2CContactEnquiryDA().Save(item, user, OrganizationId);
        }
    }
}
