﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class B2CCustomerRegisterBC
    {
        // Get All
        public List<GE::GetB2CCustomerRegister> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CCustomerRegisterDA().GetAll(inputdata);
        }
        public GE::GetB2CCustomerRegister GetbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CCustomerRegisterDA().GetbyCode(inputdata);
        }      
        public GE::B2CCustomerRegister GetbyEmail(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CCustomerRegisterDA().GetbyEmail(inputdata);
        }
        public GE::B2CCustomerRegister GetbyLogin(GE::LoginModel loginModel)
        {
            return new DA.B2CCustomerRegisterDA().GetbyLogin(loginModel);
        }
        public string Save(GE::B2CCustomerRegister item, string user, int OrganizationId)
        {
            return new DA.B2CCustomerRegisterDA().Save(item, user, OrganizationId);
        }
        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CCustomerRegisterDA().ActiveInActive(inputdata);
        }
        public string EditProfile(GE::B2CEditProfile item)
        {
            return new DA.B2CCustomerRegisterDA().EditProfile(item);
        }
        public string EditProfilePassword(GE::B2CChangePassword item)
        {
            return new DA.B2CCustomerRegisterDA().EditProfilePassword(item);
        }
        public string SendOTP(int OrganizationId, string B2CCustomerId, string Email)
        {
            return new DA.B2CCustomerRegisterDA().SendOTP(OrganizationId, B2CCustomerId,Email);
        }
        public string ForgetPassword(int OrganisationId, string Email, string user)
        {
            return new DA.B2CCustomerRegisterDA().ForgetPassword(OrganisationId, Email, user);
        }
    }
}
