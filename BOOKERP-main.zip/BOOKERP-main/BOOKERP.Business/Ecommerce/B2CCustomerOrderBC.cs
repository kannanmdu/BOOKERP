﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class B2CCustomerOrderBC
    {
        DA::B2CCustomerOrderDA _DA = new DA.B2CCustomerOrderDA();
        // Get All
        public List<GE::B2CCustomerOrder> GetAll(GE::ERPInputmodel inputdata)
        {
            return _DA.GetAll(inputdata);
        }
        public List<GE::B2CCustomerOrder> GetHeaderbySearch(GE::ERPInputmodel search)
        {
            return _DA.GetHeaderbySearch(search);
        }       
        public string Save(GE::B2CCustomerOrder header, List<GE::B2CCustomerOrderDetail> details, string user)
        {
            return _DA.Save(header, details, user);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return _DA.Remove(inputdata);
        }
        public GE::B2CCustomerOrder GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return _DA.GetTransactionbyCode(inputdata);
        }
        public string UpdateB2CStatus(GE::ERPInputmodel inputdata)
        {
            return _DA.UpdateB2CStatus(inputdata);
        }
        public List<GE::B2CCustomerOrder> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return _DA.GetSearchData(inputdata);
        }
    }
}
