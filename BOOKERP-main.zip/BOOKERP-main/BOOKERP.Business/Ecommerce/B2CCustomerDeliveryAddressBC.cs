﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Business
{
    public class B2CCustomerDeliveryAddressBC
    {
        // Get All
        public List<GE::B2CCustomerDeliveryAddress> GetAll(string CustomerId, int OrganizationId)
        {
            return new DA.B2CCustomerDeliveryAddressDA().GetAll(CustomerId, OrganizationId);
        }
        public GE::B2CCustomerDeliveryAddress GetbyCode(string user, string CustomerId, int DeliveryId, int OrganizationId)
        {
            return new DA.B2CCustomerDeliveryAddressDA().GetbyCode(user, CustomerId, DeliveryId, OrganizationId);
        }
        public string Save(GE::B2CCustomerDeliveryAddress item, string user, int OrganizationId)
        {
            return new DA.B2CCustomerDeliveryAddressDA().Save(item, user, OrganizationId);
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.B2CCustomerDeliveryAddressDA().Remove(inputdata);
        }
    }
}
