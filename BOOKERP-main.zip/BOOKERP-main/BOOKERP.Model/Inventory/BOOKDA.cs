﻿using BOOKERP.Entities;
using BOOKERP.Services.Lazada;
using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

//using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class BOOKDA : CommonDA
    {
        // Get All
        public static string strFilepath = System.Configuration.ConfigurationSettings.AppSettings["Filepath"].ToString().Trim();
        public static string IP_FilePath = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath"].ToString().Trim();

        public static string strFilepath2 = System.Configuration.ConfigurationSettings.AppSettings["Filepath2"].ToString().Trim();
        public static string IP_FilePath2 = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath2"].ToString().Trim();

        public static string strFileHosted = System.Configuration.ConfigurationSettings.AppSettings["IP_FileHosted"].ToString().Trim();
        public List<GE::Book> GetAll(GE::ERPInputmodel inputdata)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["BOOKMERCHANT_DEVConnectionString"].ConnectionString; ;
            List<GE::Book> _list = new List<GE.Book>();
            if (inputdata.TransNo == 0)
            {
                inputdata.TransNo = 1;
            }
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    //string sqlQuery = @" EXEC SP_GetBookDetail @OrgId,@BookId,@ISBN13,@ISBN10,@PageNumber,@PageSize";
                    string sqlQuery = @" EXEC SP_GetBookDetail @OrgId,@BookId,@ISBN13,@ISBN10,@PageNumber";

                    var parameters = new
                    {
                        OrgId = inputdata.OrganisationId,
                        BookId = inputdata.TranNo,
                        ISBN13 = inputdata.ISBN13,
                        ISBN10 = inputdata.ISBN10,
                        PageNumber = inputdata.TransNo,
                        //PageSize = 100,
                    };

                    var Books = connection.Query<GE.Book>(sqlQuery, parameters).ToList();
                    connection.Close();
                    return Books;
                }
                //var _data = ERPMASTERDatabase().SP_GetBookDetail(inputdata.OrganisationId).Where(x => x.IsActive == inputdata.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                //if (_data != null && _data.Count() > 0)
                //{
                //    //_data.ForEach(item =>
                //    foreach (var item in _data)
                //    {
                //        _list.Add(new GE.Book
                //        {
                //            OrgId = item.OrgId,
                //            BranchCode = item.BranchCode,
                //            BookId = item.BookId,
                //            ISBN13 = item.ISBN13,
                //            ISBN10 = item.ISBN10,
                //            Title = item.Title,
                //            AuthorName = item.AuthorName,
                //            DetailDescription = item.DetailDescription,
                //            SubTitle = item.SubTitle,
                //            CategoryId = item.CategoryId,
                //            Publisher = item.Publisher,
                //            Language = item.Language,
                //            BindingType = item.BindingType,
                //            CostPrice = item.CostPrice,
                //            Margin = item.Margin,
                //            SalesPrice = item.SalesPrice,
                //            Length = item.Length,
                //            Breadth = item.Breadth,
                //            Width = item.Width,
                //            Height = item.Height,

                //            PublishDate = item.PublishDate,
                //            Edition = item.Edition,
                //            TotalPages = item.TotalPages,
                //            SupplierId = item.SupplierId,
                //            UnitCost = item.UnitCost,
                //            SellingPrice = item.SellingPrice,
                //            SellingPriceMargin = item.SellingPriceMargin,
                //            RetailPrice = item.RetailPrice,
                //            RetailPriceMargin = item.RetailPriceMargin,
                //            B2CPrice = item.B2CPrice,
                //            B2CPriceMargin = item.B2CPriceMargin,
                //            IsNetPrice = item.IsNetPrice,
                //            Thickness = item.Thickness,
                //            Uom = item.Uom,
                //            BookImage = item.BookImage,
                //            SlNo = item.SlNo,
                //            ProductImage = item.ProductImage,
                //            ProductImageURL = item.ProductImageURL,
                //            CreatedBy = item.CreatedBy,
                //            CreatedOn = item.CreatedOn,
                //            ChangedBy = item.ChangedBy,
                //            ChangedOn = item.ChangedOn,
                //            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                //            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                //            AvailableStockQty = item.AvailableStockQty
                //        });
                //    }
                //    //});
                //}
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }

        //public IEnumerable<GE::Book> GetAll_New(GE::ERPInputmodel inputdata)
        //{
        //    try
        //    {
        //        var dataEnumerator = ERPMASTERDatabase()
        //            .SP_GetBookDetail(inputdata.OrganisationId)
        //            .Where(x => x.IsActive == inputdata.IsActive)
        //            .OrderByDescending(o => o.CreatedOn)
        //            .ToList();


        //        foreach (var item in dataEnumerator)
        //        {
        //            yield return MapToGEBook(item);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
        //        // Handle exception appropriately
        //    }
        //}

        //private GE::Book MapToGEBook(ERPBookDetail item)
        //{
        //    return new GE.Book
        //    {
        //        OrgId = item.OrgId,
        //        BranchCode = item.BranchCode,
        //        BookId = item.BookId,
        //        ISBN13 = item.ISBN13,
        //        ISBN10 = item.ISBN10,
        //        Title = item.Title,
        //        AuthorName = item.AuthorName,
        //        DetailDescription = item.DetailDescription,
        //        SubTitle = item.SubTitle,
        //        CategoryId = item.CategoryId,
        //        Publisher = item.Publisher,
        //        Language = item.Language,
        //        BindingType = item.BindingType,
        //        CostPrice = item.CostPrice,
        //        Margin = item.Margin,
        //        SalesPrice = item.SalesPrice,
        //        Length = item.Length,
        //        Breadth = item.Breadth,
        //        Width = item.Width,
        //        Height = item.Height,
        //        PublishDate = item.PublishDate,
        //        Edition = item.Edition,
        //        TotalPages = item.TotalPages,
        //        SupplierId = item.SupplierId,
        //        UnitCost = item.UnitCost,
        //        SellingPrice = item.SellingPrice,
        //        SellingPriceMargin = item.SellingPriceMargin,
        //        RetailPrice = item.RetailPrice,
        //        RetailPriceMargin = item.RetailPriceMargin,
        //        B2CPrice = item.B2CPrice,
        //        B2CPriceMargin = item.B2CPriceMargin,
        //        IsNetPrice = item.IsNetPrice,
        //        Thickness = item.Thickness,
        //        Uom = item.Uom,
        //        BookImage = item.BookImage,
        //        SlNo = item.SlNo,
        //        ProductImage = item.ProductImage,
        //        ProductImageURL = item.ProductImageURL,
        //        CreatedBy = item.CreatedBy,
        //        CreatedOn = item.CreatedOn,
        //        ChangedBy = item.ChangedBy,
        //        ChangedOn = item.ChangedOn,
        //        CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
        //        ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
        //        AvailableStockQty = item.AvailableStockQty
        //    };
        //}

        public async Task<List<GE::Book>> GetAllProduct(GE::ERPInputmodel inputdata)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["BOOKMERCHANT_DEVConnectionString"].ConnectionString; ;
            List<GE::Book> _list = new List<GE.Book>();
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    string sqlQuery = @"EXEC SP_GetBookDetail @OrgId";

                    var parameters = new
                    {
                        OrgId = inputdata.OrganisationId,
                    };

                    var books = (await connection.QueryAsync<GE.Book>(sqlQuery, parameters)).ToList();
                    return books;
                }
                //using (var connection = new SqlConnection(connectionString))
                //{
                //    string sqlQuery = @" EXEC SP_GetBookDetail @OrgId";

                //    var parameters = new
                //    {
                //        OrgId = inputdata.OrganisationId,
                //    };

                //    var Books = connection.Query<GE.Book>(sqlQuery, parameters).ToList();
                //    return Books;
                //}
                //var _data = ERPMASTERDatabase().SP_GetBookDetail(inputdata.OrganisationId).Where(x => x.IsActive == inputdata.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                //if (_data != null && _data.Count() > 0)
                //{
                //    _data.ForEach(item =>
                //    {
                //        _list.Add(new GE.Book
                //        {
                //            OrgId = item.OrgId,
                //            BranchCode = item.BranchCode,
                //            BookId = item.BookId,
                //            ISBN13 = item.ISBN13,
                //            ISBN10 = item.ISBN10,
                //            Title = item.Title,
                //            AuthorName = item.AuthorName,
                //            DetailDescription = item.DetailDescription,
                //            SubTitle = item.SubTitle,
                //            CategoryId = item.CategoryId,
                //            Publisher = item.Publisher,
                //            Language = item.Language,
                //            BindingType = item.BindingType,
                //            CostPrice = item.CostPrice,
                //            Margin = item.Margin,
                //            SalesPrice = item.SalesPrice,
                //            Length = item.Length,
                //            Breadth = item.Breadth,
                //            Width = item.Width,
                //            Height = item.Height,
                //            IsNetPrice = item.IsNetPrice,
                //            PublishDate = item.PublishDate,
                //            Edition = item.Edition,
                //            TotalPages = item.TotalPages,
                //            SupplierId = item.SupplierId,
                //            UnitCost = item.UnitCost,
                //            SellingPrice = item.SellingPrice,
                //            SellingPriceMargin = item.SellingPriceMargin,
                //            RetailPrice = item.RetailPrice,
                //            RetailPriceMargin = item.RetailPriceMargin,
                //            B2CPrice = item.B2CPrice,
                //            B2CPriceMargin = item.B2CPriceMargin,
                //            Thickness = item.Thickness,
                //            Uom = item.Uom,
                //            BookImage = item.BookImage,
                //            SlNo = item.SlNo,
                //            ProductImage = item.ProductImage,
                //            ProductImageURL = item.ProductImageURL,
                //            CreatedBy = item.CreatedBy,
                //            CreatedOn = item.CreatedOn,
                //            ChangedBy = item.ChangedBy,
                //            ChangedOn = item.ChangedOn,
                //            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                //            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty
                //        });
                //    });
                //}
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }

        public async Task<List<GE::Book>> GetAllProductAutocomplete(GE::ERPInputmodel inputdata)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["BOOKMERCHANT_DEVConnectionString"].ConnectionString; ;
            List<GE::Book> _list = new List<GE.Book>();
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();

                    string sqlQuery = @"EXEC SP_GetBookDetail_Autocomplete @OrgId,@Value";

                    var parameters = new
                    {
                        OrgId = inputdata.OrganisationId,
                        Value = inputdata.TranNo
                    };

                    var books = (await connection.QueryAsync<GE.Book>(sqlQuery, parameters)).ToList();
                    return books;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::Book item, string user, int organizationId, List<GE.ProductTags> productTags, List<GE::EcommerceMultiTenant> multiTenent, List<GE::SupplierPrices> _SupplierPrice)
        {
            string result = string.Empty;
            string BookImg_path = string.Empty;
            string URL_BookImgPath = string.Empty;
            try
            {
                if (item != null)
                {
                    if (strFileHosted == "IIS")
                    {
                        //Create Physical Image from Byte

                        if (item.BookImg != null && !string.IsNullOrEmpty(item.BookImageFileName))
                        {
                            byte[] byteImg = item.BookImg;
                            BookImg_path = WriteFile(strFilepath + "BOOK", item.BookImageFileName, byteImg);
                            if (!string.IsNullOrEmpty(BookImg_path))
                            {
                                URL_BookImgPath = BookImg_path.Replace("C:\\AppXperts\\", IP_FilePath).Replace(@"\", "//");
                            }
                        }
                    }

                    if (strFileHosted == "P")
                    {
                        //Create Physical Image from Byte
                        if (item.BookImg != null && !string.IsNullOrEmpty(item.BookImg_Base64String))
                        {
                            byte[] byteImg = System.Convert.FromBase64String(item.BookImg_Base64String);
                            BookImg_path = WriteFile(strFilepath2 + "CATEGORY", item.BookImageFileName, byteImg);
                            if (!string.IsNullOrEmpty(BookImg_path))
                            {
                                URL_BookImgPath = BookImg_path.Replace("C:\\Inetpub\\vhosts\\fervent-wilson.154-26-130-251.plesk.page\\httpdocs\\", IP_FilePath2).Replace(@"\", "//");
                            }
                        }

                    }
                    var _data = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == item.BookId && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.BookId = item.BookId;
                        _data.BranchCode = item.BranchCode;
                        _data.ISBN10 = item.ISBN10;
                        _data.ISBN13 = item.ISBN13;
                        _data.Title = item.Title;
                        _data.SubTitle = item.SubTitle;
                        _data.AuthorName = item.AuthorName;
                        _data.CategoryId = item.CategoryId;
                        _data.Publisher = item.Publisher;
                        _data.Language = item.Language;
                        _data.BindingType = item.BindingType;
                        _data.CostPrice = item.CostPrice;
                        _data.Margin = item.Margin;
                        _data.Width = item.Width;
                        _data.SalesPrice = item.SalesPrice;
                        _data.Length = item.Length;
                        _data.Breadth = item.Breadth;
                        _data.Height = item.Height;
                        _data.PublishDate = item.PublishDate;
                        _data.TotalPages = item.TotalPages;
                        _data.Edition = item.Edition;
                        _data.DetailDescription = item.DetailDescription;
                        _data.SupplierId = item.SupplierId;
                        _data.UnitCost = item.UnitCost;
                        _data.SellingPrice = item.SellingPrice;
                        _data.SellingPriceMargin = item.SellingPriceMargin;
                        _data.RetailPrice = item.RetailPrice;
                        _data.RetailPriceMargin = item.RetailPriceMargin;
                        _data.B2CPrice = item.B2CPrice;
                        _data.B2CPriceMargin = item.B2CPriceMargin;
                        _data.Weight = item.Weight;
                        _data.IsActive = item.IsActive;
                        _data.IsB2C = item.IsB2C;
                        _data.IsPos = item.IsPos;
                        _data.Thickness = item.Thickness;
                        _data.IsNetPrice = item.IsNetPrice;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        if (item.BookImg != null && !string.IsNullOrEmpty(item.BookImageFileName))
                        {
                            _data.BookImage = URL_BookImgPath == null ? string.Empty : URL_BookImgPath;
                        }
                        else
                            _data.BookImage = item.BookImage;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.BookId))
                        {
                            var autoCode = GetMasterNextNo(organizationId, BOOK);
                            item.BookId = autoCode;
                        }
                        Master_Book book = new Master_Book()
                        {
                            OrgId = organizationId,
                            BookId = item.BookId,
                            BranchCode = item.BranchCode,
                            ISBN10 = item.ISBN10,
                            ISBN13 = item.ISBN13,
                            Title = item.Title,
                            SubTitle = item.SubTitle,
                            AuthorName = item.AuthorName,
                            CategoryId = item.CategoryId,
                            Publisher = item.Publisher,
                            Language = item.Language,
                            BindingType = item.BindingType,
                            CostPrice = item.CostPrice,
                            Margin = item.Margin,
                            Width = item.Width,
                            SalesPrice = item.SalesPrice,
                            Length = item.Length,
                            Breadth = item.Breadth,
                            Height = item.Height,
                            PublishDate = item.PublishDate,
                            TotalPages = item.TotalPages,
                            Edition = item.Edition,
                            DetailDescription = item.DetailDescription,
                            SupplierId = item.SupplierId,
                            UnitCost = item.UnitCost,
                            SellingPrice = item.SellingPrice,
                            SellingPriceMargin = item.SellingPriceMargin,
                            RetailPrice = item.RetailPrice,
                            RetailPriceMargin = item.RetailPriceMargin,
                            B2CPrice = item.B2CPrice,
                            B2CPriceMargin = item.B2CPriceMargin,
                            Weight = item.Weight,
                            IsActive = item.IsActive,
                            IsB2C = item.IsB2C,
                            IsPos = item.IsPos,
                            Thickness = item.Thickness,
                            IsNetPrice = item.IsNetPrice,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                            BookImage = !string.IsNullOrEmpty(item.BookImage) ? item.BookImage : URL_BookImgPath
                        };
                        ERPMASTERDatabase().Master_Book.Add(book);
                        ERPMASTERDatabase().SaveChanges();

                        Product_ProductStock stock = new Product_ProductStock()
                        {
                            OrgId = organizationId,
                            BranchCode = book.BranchCode,
                            ProductCode = book.BookId,
                            ProductName = book.Title,
                            StockQty = 0,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                            StockBoxQty = 0,
                            StockPcsQty = 0,
                            BoxCount = 1,
                            StockWQty = 0,
                        };
                        ERPMASTERDatabase().Product_ProductStock.Add(stock);
                        ERPMASTERDatabase().SaveChanges();

                        result = PASS;
                    }

                    result = DeleteTag(item.BookId, organizationId);
                    if (productTags != null && productTags.Count > 0)
                    {
                        productTags.ForEach(titems =>
                        {
                            titems.OrgId = organizationId;
                            titems.ProductCode = item.BookId;
                            titems.TagCode = titems.TagCode;
                            result = SaveTag(titems, user);
                        });
                    }
                    result = DeleteSupplierPrice(item.BookId, organizationId);
                    if (_SupplierPrice != null && _SupplierPrice.Count > 0)
                    {
                        _SupplierPrice.ForEach(titems =>
                        {
                            titems.Orgid = organizationId;
                            titems.BookId = item.BookId;
                            result = SaveSupplierPrice(titems, user);
                            ERPMASTERDatabase().SaveChanges();
                        });
                    }
                    if (multiTenent?.Any() == true)
                    {
                        var tenantAllData = ERPMASTERDatabase().Ecommerce_Multitenant.Where(o => o.OrgId == organizationId && o.BookId == item.BookId && o.IsActive == true).ToList();
                        tenantAllData.ForEach(d => {
                            d.IsActive = false;
                            ERPMASTERDatabase().SaveChanges();
                        });
                        multiTenent.ForEach(tenant =>
                        {
                            if (item != null)
                            {
                                var tenantData = ERPMASTERDatabase().Ecommerce_Multitenant.FirstOrDefault(o => o.OrgId == organizationId && o.BookId == item.BookId && o.ShopCode == tenant.ShopCode);
                                if (tenantData != null)
                                {
                                    tenantData.Price = tenant.Price;
                                    tenantData.IsActive = true;
                                    ERPMASTERDatabase().SaveChanges();
                                    result = PASS;
                                }
                                else
                                {
                                    Ecommerce_Multitenant tenent = new Ecommerce_Multitenant()
                                    {
                                        OrgId = organizationId,
                                        BookId = item.BookId,
                                        ShopCode = tenant.ShopCode,
                                        Price = tenant.Price,
                                        CreatedOn = DateTime.Now,
                                        CreatedBy = user,
                                        ChangedOn = DateTime.Now,
                                        ChangedBy = user,
                                        IsActive = true,
                                        LazadaSkuId = string.Empty,
                                        LazadaItemId = string.Empty,
                                        IsLazadaSkuActive = false

                                    };
                                    ERPMASTERDatabase().Ecommerce_Multitenant.Add(tenent);
                                    ERPMASTERDatabase().SaveChanges();
                                }
                            }
                        });
                        multiTenent.ForEach(tenant =>
                        {
                            tenant.BookId = item.BookId;
                        });
                        LazadaClient objLazadaClient = new LazadaClient();
                        objLazadaClient.ProcessorAllTenant(multiTenent, organizationId).GetAwaiter().GetResult();
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, BOOK, organizationId);
            }

            return result;        }
        public string DeleteTag(string ProductCode, int OrganizationId)
        {
            string Result = string.Empty;
            string qString = "Delete From ProductTag WHERE ProductCode = " + ProductCode.ToString().ToERPString();
            qString += " AND OrgId = " + OrganizationId.ToString().ToERPString();
            ERPMASTERDatabase().Database.ExecuteSqlCommand(qString);
            Result = PASS;
            return Result;
        }
        public string DeleteSupplierPrice(string ProductCode, int OrganizationId)
        {
            string Result = string.Empty;
            string qString = "Delete From SupplierPrice WHERE Bookid = " + ProductCode.ToString().ToERPString();
            qString += " AND OrgId = " + OrganizationId.ToString().ToERPString();
            ERPMASTERDatabase().Database.ExecuteSqlCommand(qString);
            Result = PASS;
            return Result;
        }

        
        public string SaveTag(GE::ProductTags bitem, string user)
        {
            string Result = string.Empty;
            ProductTag product = new ProductTag()
            {
                OrgId = bitem.OrgId,
                ProductCode = bitem.ProductCode,
                TagCode = bitem.TagCode,
                CreatedOn = DateTime.Now,
                CreatedBy = user,
                ChangedOn = DateTime.Now,
                ChangedBy = user,
            };
            ERPMASTERDatabase().ProductTags.Add(product);
            ERPMASTERDatabase().SaveChanges();
            Result = PASS;
            return Result;
        }
        public string SaveSupplierPrice(GE::SupplierPrices item, string user)
        {
           
            string result = string.Empty;
            try
            {
                var data = ERPMASTERDatabase().sp_savesupplierprice(item.Orgid, item.slno, item.BookId,  item.Supplierprice, item.SupplierId, item.Suppliername, user).FirstOrDefault();
                if (data != null)
                {
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, INVOICE, item.Orgid);
            }
            return result;



          
        }

        
        //Edit the book details
        public GE::Book GetbyCode(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            GE::Book _data = new GE.Book();
            List<GE::ProductTags> _tdata = new List<GE.ProductTags>();
            List<GE::SupplierPrices> _SupplierPrice = new List<GE.SupplierPrices>();
            List<GE::BookTranscation> _btdata = new List<GE.BookTranscation>();
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                var tagitem = ERPMASTERDatabase().ProductTags.Where(o => o.ProductCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).ToList();
                var Supplierprice = ERPMASTERDatabase().SupplierPrices.Where(o => o.BookId == inputdata.TranNo && o.orgid == inputdata.OrganisationId).ToList();

                var BookTransaction = inputdata.FromDate != null ?
                    ERPMASTERDatabase().TblTranscations.Where(o => o.ProductCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId && o.TranDate >= inputdata.FromDate && o.TranDate <= inputdata.ToDate).ToList() :
                    null;

                if (item != null)
                {
                    if (!string.IsNullOrEmpty(item.BookImage))
                    {
                        URL_BookImgPath = item.BookImage.Replace("C:\\APPEXPERTS\\", IP_FilePath).Replace(@"\", "//");
                    }
                    _data = (new GE.Book
                    {
                        OrgId = item.OrgId,
                        BookId = item.BookId,
                        ISBN10 = item.ISBN10,
                        ISBN13 = item.ISBN13,
                        BranchCode = !string.IsNullOrEmpty(item.BranchCode) ? item.BranchCode : string.Empty,
                        Title = !string.IsNullOrEmpty(item.Title) ? item.Title : string.Empty,
                        SubTitle = !string.IsNullOrEmpty(item.SubTitle) ? item.SubTitle : string.Empty,
                        AuthorName = !string.IsNullOrEmpty(item.AuthorName) ? item.AuthorName : string.Empty,
                        CategoryId = !string.IsNullOrEmpty(item.CategoryId) ? item.CategoryId : string.Empty,
                        Publisher = !string.IsNullOrEmpty(item.Publisher) ? item.Publisher : string.Empty,
                        Language = !string.IsNullOrEmpty(item.Language) ? item.Language : string.Empty,
                        BindingType = !string.IsNullOrEmpty(item.BindingType) ? item.Language : string.Empty,
                        CostPrice = item.CostPrice != null ? item.CostPrice : 0,
                        Margin = item.Margin != null ? item.Margin : 0,
                        Width = item.Width != null ? item.Width : 0,
                        SalesPrice = item.SalesPrice != null ? item.SalesPrice : 0,
                        Length = item.Length != null ? item.Length : 0,
                        Breadth = item.Breadth != null ? item.Breadth : 0,
                        Height = item.Height != null ? item.Height : 0,
                        PublishDate = item.PublishDate,
                        PublishDateString = (item.PublishDate != null) ? item.PublishDate.Value.ToERPdate() : string.Empty,
                        TotalPages = item.TotalPages != null ? item.TotalPages : 0,
                        Edition = item.Edition != null ? item.Edition : 0,
                        DetailDescription = item.DetailDescription,
                        SupplierId = item.SupplierId,
                        UnitCost = item.UnitCost != null ? item.UnitCost : 0,
                        SellingPrice = item.SellingPrice != null ? item.SellingPrice : 0,
                        SellingPriceMargin = item.SellingPriceMargin != null ? item.SellingPriceMargin : 0,
                        RetailPrice = item.RetailPrice != null ? item.RetailPrice : 0,
                        RetailPriceMargin = item.RetailPriceMargin != null ? item.RetailPriceMargin : 0,
                        B2CPrice = item.B2CPrice != null ? item.B2CPrice : 0,
                        B2CPriceMargin = item.B2CPriceMargin != null ? item.B2CPriceMargin : 0,
                        Weight = item.Weight != null ? item.Weight : 0,
                        Thickness = item.Thickness != null ? item.Thickness : 0,
                        IsActive = item.IsActive != null ? item.IsActive : false,
                        IsB2C = item.IsB2C != null ? item.IsB2C : false,
                        IsPos = item.IsPos != null ? item.IsPos : false,
                        IsNetPrice = item.IsNetPrice != null ? item.IsNetPrice : false,
                        BookImage = URL_BookImgPath,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });

                    if (BookTransaction != null && BookTransaction.Count > 0)
                    {
                        BookTransaction.ForEach(btitems =>
                        {
                            _btdata.Add(new GE.BookTranscation
                            {
                                OrgId = btitems.OrgId,
                                ProductCode = btitems.ProductCode,
                                CustomerName = btitems.CustomerName,
                                ProductName = btitems.ProductName,
                                ISIBN13 = btitems.ISIBN13,
                                ISIBN10 = btitems.ISIBN10,
                                Qty = btitems.Qty,
                                TranscationType = btitems.TranscationType,
                                TranDate = btitems.TranDate,
                                Price = btitems.Price,
                                CreatedOn = btitems.CreatedOn,
                                TranNo = btitems.TranNo
                            });
                        });
                    }

                    if (tagitem != null && tagitem.Count > 0)
                    {
                        tagitem.ForEach(titems =>
                        {
                            _tdata.Add(new GE.ProductTags
                            {
                                OrgId = titems.OrgId,
                                ProductCode = titems.ProductCode,
                                TagCode = titems.TagCode,
                            });
                        });
                    }

                    if (Supplierprice != null && Supplierprice.Count > 0)
                    {
                        Supplierprice.ForEach(titems =>
                        {
                            _SupplierPrice.Add(new GE.SupplierPrices
                            {
                                slno = titems.slno,
                                BookId = titems.BookId,
                                Supplierprice = titems.price,
                                Suppliername= titems.Suppliername,
                                SupplierId = titems.SupplierId,
                            });
                        });
                    }
                }
                _data.ProductTags = _tdata;
                _data.BookTrans = _btdata;
                _data.SupplierPrices = _SupplierPrice;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public GE::Book GetbyIsbnCode(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            GE::Book _data = new GE.Book();
            List<GE::ProductTags> _tdata = new List<GE.ProductTags>();
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.ISBN13 == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);

                if (item != null)
                {
                    _data = (new GE.Book
                    {
                        OrgId = item.OrgId,
                        BookId = item.BookId,
                        ISBN10 = item.ISBN10,
                        ISBN13 = item.ISBN13,
                        BranchCode = !string.IsNullOrEmpty(item.BranchCode) ? item.BranchCode : string.Empty,
                        Title = !string.IsNullOrEmpty(item.Title) ? item.Title : string.Empty,
                        SubTitle = !string.IsNullOrEmpty(item.SubTitle) ? item.SubTitle : string.Empty,
                        AuthorName = !string.IsNullOrEmpty(item.AuthorName) ? item.AuthorName : string.Empty,
                        CategoryId = !string.IsNullOrEmpty(item.CategoryId) ? item.CategoryId : string.Empty,
                        Publisher = !string.IsNullOrEmpty(item.Publisher) ? item.Publisher : string.Empty,
                        Language = !string.IsNullOrEmpty(item.Language) ? item.Language : string.Empty,
                        BindingType = !string.IsNullOrEmpty(item.BindingType) ? item.Language : string.Empty,
                        CostPrice = item.CostPrice != null ? item.CostPrice : 0,
                        Margin = item.Margin != null ? item.Margin : 0,
                        Width = item.Width != null ? item.Width : 0,
                        SalesPrice = item.SalesPrice != null ? item.SalesPrice : 0,
                        Length = item.Length != null ? item.Length : 0,
                        Breadth = item.Breadth != null ? item.Breadth : 0,
                        Height = item.Height != null ? item.Height : 0,
                        PublishDate = item.PublishDate,
                        PublishDateString = (item.PublishDate != null) ? item.PublishDate.Value.ToERPdate() : string.Empty,
                        TotalPages = item.TotalPages != null ? item.TotalPages : 0,
                        Edition = item.Edition != null ? item.Edition : 0,
                        DetailDescription = item.DetailDescription,
                        SupplierId = item.SupplierId,
                        UnitCost = item.UnitCost != null ? item.UnitCost : 0,
                        SellingPrice = item.SellingPrice != null ? item.SellingPrice : 0,
                        SellingPriceMargin = item.SellingPriceMargin != null ? item.SellingPriceMargin : 0,
                        RetailPrice = item.RetailPrice != null ? item.SellingPriceMargin : 0,
                        RetailPriceMargin = item.RetailPriceMargin != null ? item.RetailPriceMargin : 0,
                        B2CPrice = item.B2CPrice != null ? item.B2CPrice : 0,
                        B2CPriceMargin = item.B2CPriceMargin != null ? item.B2CPriceMargin : 0,
                        Weight = item.Weight != null ? item.Weight : 0,
                        Thickness = item.Thickness != null ? item.Thickness : 0,
                        IsActive = item.IsActive != null ? item.IsActive : false,
                        IsB2C = item.IsB2C != null ? item.IsB2C : false,
                        IsPos = item.IsPos != null ? item.IsPos : false,
                        IsNetPrice = item.IsNetPrice != null ? item.IsNetPrice : false,
                        BookImage = URL_BookImgPath,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
                else
                {
                    var item1 = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);

                    if (item1 != null)
                    {
                        _data = (new GE.Book
                        {
                            OrgId = item1.OrgId,
                            BookId = item1.BookId,
                            ISBN10 = item1.ISBN10,
                            ISBN13 = item1.ISBN13,
                            BranchCode = !string.IsNullOrEmpty(item1.BranchCode) ? item1.BranchCode : string.Empty,
                            Title = !string.IsNullOrEmpty(item1.Title) ? item1.Title : string.Empty,
                            SubTitle = !string.IsNullOrEmpty(item1.SubTitle) ? item1.SubTitle : string.Empty,
                            AuthorName = !string.IsNullOrEmpty(item1.AuthorName) ? item1.AuthorName : string.Empty,
                            CategoryId = !string.IsNullOrEmpty(item1.CategoryId) ? item1.CategoryId : string.Empty,
                            Publisher = !string.IsNullOrEmpty(item1.Publisher) ? item1.Publisher : string.Empty,
                            Language = !string.IsNullOrEmpty(item1.Language) ? item1.Language : string.Empty,
                            BindingType = !string.IsNullOrEmpty(item1.BindingType) ? item1.Language : string.Empty,
                            CostPrice = item1.CostPrice != null ? item1.CostPrice : 0,
                            Margin = item1.Margin != null ? item1.Margin : 0,
                            Width = item1.Width != null ? item1.Width : 0,
                            SalesPrice = item1.SalesPrice != null ? item1.SalesPrice : 0,
                            Length = item1.Length != null ? item1.Length : 0,
                            Breadth = item1.Breadth != null ? item1.Breadth : 0,
                            Height = item1.Height != null ? item1.Height : 0,
                            PublishDate = item1.PublishDate,
                            PublishDateString = (item1.PublishDate != null) ? item1.PublishDate.Value.ToERPdate() : string.Empty,
                            TotalPages = item1.TotalPages != null ? item1.TotalPages : 0,
                            Edition = item1.Edition != null ? item1.Edition : 0,
                            DetailDescription = item1.DetailDescription,
                            SupplierId = item1.SupplierId,
                            UnitCost = item1.UnitCost != null ? item1.UnitCost : 0,
                            SellingPrice = item1.SellingPrice != null ? item1.SellingPrice : 0,
                            SellingPriceMargin = item1.SellingPriceMargin != null ? item1.SellingPriceMargin : 0,
                            RetailPrice = item1.RetailPrice != null ? item1.SellingPriceMargin : 0,
                            RetailPriceMargin = item1.RetailPriceMargin != null ? item1.RetailPriceMargin : 0,
                            B2CPrice = item1.B2CPrice != null ? item1.B2CPrice : 0,
                            B2CPriceMargin = item1.B2CPriceMargin != null ? item1.B2CPriceMargin : 0,
                            Weight = item1.Weight != null ? item1.Weight : 0,
                            Thickness = item1.Thickness != null ? item1.Thickness : 0,
                            IsActive = item1.IsActive != null ? item1.IsActive : false,
                            IsB2C = item1.IsB2C != null ? item1.IsB2C : false,
                            IsPos = item1.IsPos != null ? item1.IsPos : false,
                            IsNetPrice = item1.IsNetPrice != null ? item1.IsNetPrice : false,
                            BookImage = URL_BookImgPath,
                            ChangedBy = item1.ChangedBy,
                            ChangedOn = item1.ChangedOn,
                            CreatedBy = item1.CreatedBy,
                            CreatedOn = item1.CreatedOn
                        });
                    }
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public GE::Book GetbyIsbn10Code(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            GE::Book _data = new GE.Book();
            List<GE::ProductTags> _tdata = new List<GE.ProductTags>();
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.ISBN10 == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);

                if (item != null)
                {
                    _data = (new GE.Book
                    {
                        OrgId = item.OrgId,
                        BookId = item.BookId,
                        ISBN10 = item.ISBN10,
                        ISBN13 = item.ISBN13,
                        BranchCode = !string.IsNullOrEmpty(item.BranchCode) ? item.BranchCode : string.Empty,
                        Title = !string.IsNullOrEmpty(item.Title) ? item.Title : string.Empty,
                        SubTitle = !string.IsNullOrEmpty(item.SubTitle) ? item.SubTitle : string.Empty,
                        AuthorName = !string.IsNullOrEmpty(item.AuthorName) ? item.AuthorName : string.Empty,
                        CategoryId = !string.IsNullOrEmpty(item.CategoryId) ? item.CategoryId : string.Empty,
                        Publisher = !string.IsNullOrEmpty(item.Publisher) ? item.Publisher : string.Empty,
                        Language = !string.IsNullOrEmpty(item.Language) ? item.Language : string.Empty,
                        BindingType = !string.IsNullOrEmpty(item.BindingType) ? item.Language : string.Empty,
                        CostPrice = item.CostPrice != null ? item.CostPrice : 0,
                        Margin = item.Margin != null ? item.Margin : 0,
                        Width = item.Width != null ? item.Width : 0,
                        SalesPrice = item.SalesPrice != null ? item.SalesPrice : 0,
                        Length = item.Length != null ? item.Length : 0,
                        Breadth = item.Breadth != null ? item.Breadth : 0,
                        Height = item.Height != null ? item.Height : 0,
                        PublishDate = item.PublishDate,
                        PublishDateString = (item.PublishDate != null) ? item.PublishDate.Value.ToERPdate() : string.Empty,
                        TotalPages = item.TotalPages != null ? item.TotalPages : 0,
                        Edition = item.Edition != null ? item.Edition : 0,
                        DetailDescription = item.DetailDescription,
                        SupplierId = item.SupplierId,
                        UnitCost = item.UnitCost != null ? item.UnitCost : 0,
                        SellingPrice = item.SellingPrice != null ? item.SellingPrice : 0,
                        SellingPriceMargin = item.SellingPriceMargin != null ? item.SellingPriceMargin : 0,
                        RetailPrice = item.RetailPrice != null ? item.SellingPriceMargin : 0,
                        RetailPriceMargin = item.RetailPriceMargin != null ? item.RetailPriceMargin : 0,
                        B2CPrice = item.B2CPrice != null ? item.B2CPrice : 0,
                        B2CPriceMargin = item.B2CPriceMargin != null ? item.B2CPriceMargin : 0,
                        Weight = item.Weight != null ? item.Weight : 0,
                        Thickness = item.Thickness != null ? item.Thickness : 0,
                        IsActive = item.IsActive != null ? item.IsActive : false,
                        IsB2C = item.IsB2C != null ? item.IsB2C : false,
                        IsPos = item.IsPos != null ? item.IsPos : false,
                        IsNetPrice = item.IsNetPrice != null ? item.IsNetPrice : false,
                        BookImage = URL_BookImgPath,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public GE::Book GetByCodePosAdd(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            GE::Book _data = new GE.Book();
            List<GE::ProductTags> _tdata = new List<GE.ProductTags>();
            GE::GiftVoucher _gvdata = new GE.GiftVoucher();
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => (o.BookId == inputdata.TranNo || o.ISBN13 == inputdata.TranNo) && o.OrgId == inputdata.OrganisationId);
                var tagitem = ERPMASTERDatabase().ProductTags.Where(o => o.ProductCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).ToList();

                var query = "Sp_CheckGiftVoucher";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@VoucherCode", inputdata.TranNo);
                var list = SqlMapper.Query<GE.POSInvoice_Detail>(GetConnection, query, param, commandType: CommandType.StoredProcedure).ToList();
                GetConnection.Close();

                if (list.Count == 0)
                {
                    var giftvoucheritem = ERPMASTERDatabase().Master_GiftVoucher.Where(o => o.VoucherCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).FirstOrDefault();
                    if (giftvoucheritem != null)
                    {
                        _gvdata = (new GE.GiftVoucher
                        {
                            OrgId = giftvoucheritem.OrgId,
                            VoucherCode = giftvoucheritem.VoucherCode,
                            VoucherName = giftvoucheritem.VoucherName,
                            Amount = giftvoucheritem.Amount,
                            CreatedBy = giftvoucheritem.CreatedBy,
                            CreatedOn = giftvoucheritem.CreatedOn,
                            ChangedBy = giftvoucheritem.ChangedBy,
                            ChangedOn = giftvoucheritem.ChangedOn
                        });
                        _data.GiftVoucherInfo = _gvdata;
                    }
                }
                if (item != null)
                {
                    if (!string.IsNullOrEmpty(item.BookImage))
                    {
                        URL_BookImgPath = item.BookImage.Replace("C:\\APPEXPERTS\\", IP_FilePath).Replace(@"\", "//");
                    }
                    _data = (new GE.Book
                    {
                        OrgId = item.OrgId,
                        BookId = item.BookId,
                        ISBN10 = item.ISBN10,
                        ISBN13 = item.ISBN13,
                        BranchCode = !string.IsNullOrEmpty(item.BranchCode) ? item.BranchCode : string.Empty,
                        Title = !string.IsNullOrEmpty(item.Title) ? item.Title : string.Empty,
                        SubTitle = !string.IsNullOrEmpty(item.SubTitle) ? item.SubTitle : string.Empty,
                        AuthorName = !string.IsNullOrEmpty(item.AuthorName) ? item.AuthorName : string.Empty,
                        CategoryId = !string.IsNullOrEmpty(item.CategoryId) ? item.CategoryId : string.Empty,
                        Publisher = !string.IsNullOrEmpty(item.Publisher) ? item.Publisher : string.Empty,
                        Language = !string.IsNullOrEmpty(item.Language) ? item.Language : string.Empty,
                        BindingType = !string.IsNullOrEmpty(item.BindingType) ? item.Language : string.Empty,
                        CostPrice = item.CostPrice != null ? item.CostPrice : 0,
                        Margin = item.Margin != null ? item.Margin : 0,
                        Width = item.Width != null ? item.Width : 0,
                        SalesPrice = item.SalesPrice != null ? item.SalesPrice : 0,
                        Length = item.Length != null ? item.Length : 0,
                        Breadth = item.Breadth != null ? item.Breadth : 0,
                        Height = item.Height != null ? item.Height : 0,
                        PublishDate = item.PublishDate,
                        PublishDateString = (item.PublishDate != null) ? item.PublishDate.Value.ToERPdate() : string.Empty,
                        TotalPages = item.TotalPages != null ? item.TotalPages : 0,
                        Edition = item.Edition != null ? item.Edition : 0,
                        DetailDescription = item.DetailDescription,
                        SupplierId = item.SupplierId,
                        UnitCost = item.UnitCost != null ? item.UnitCost : 0,
                        SellingPrice = item.SellingPrice != null ? item.SellingPrice : 0,
                        SellingPriceMargin = item.SellingPriceMargin != null ? item.SellingPriceMargin : 0,
                        RetailPrice = item.RetailPrice != null ? item.SellingPriceMargin : 0,
                        RetailPriceMargin = item.RetailPriceMargin != null ? item.RetailPriceMargin : 0,
                        B2CPrice = item.B2CPrice != null ? item.B2CPrice : 0,
                        B2CPriceMargin = item.B2CPriceMargin != null ? item.B2CPriceMargin : 0,
                        Weight = item.Weight != null ? item.Weight : 0,
                        Thickness = item.Thickness != null ? item.Thickness : 0,
                        IsActive = item.IsActive != null ? item.IsActive : false,
                        IsB2C = item.IsB2C != null ? item.IsB2C : false,
                        IsPos = item.IsPos != null ? item.IsPos : false,
                        IsNetPrice = item.IsNetPrice != null ? item.IsNetPrice : false,
                        BookImage = URL_BookImgPath,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });

                    if (tagitem != null && tagitem.Count > 0)
                    {
                        tagitem.ForEach(titems =>
                        {
                            _tdata.Add(new GE.ProductTags
                            {
                                OrgId = titems.OrgId,
                                ProductCode = titems.ProductCode,
                                TagCode = titems.TagCode,
                            });
                        });
                    }
                }
                else
                {
                    var mitem = ERPMASTERDatabase().Magazines.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.MagazineId == inputdata.TranNo);
                    if (mitem != null)
                    {
                        _data = (new GE.Book
                        {
                            OrgId = mitem.OrgId,
                            BranchCode = mitem.BranchCode,
                            BookId = mitem.MagazineId,
                            MagazineCode = mitem.MagazineCode,
                            Title = mitem.MagazineName,
                            ShortDescription = mitem.ShortDescription,
                            LongDescription = mitem.LongDescription,
                            BarCode = mitem.BarCode,
                            //Title = mitem.Title,
                            Category = mitem.Category,
                            SubCategoryCode = mitem.SubCategoryCode,
                            Publishcurrency = mitem.Publishcurrency,
                            CurrencyValue = mitem.CurrencyValue,
                            CurrencyRate = mitem.CurrencyRate,
                            PublishPrice = mitem.PublishPrice != null ? mitem.PublishPrice : 0,
                            Price = mitem.Price != null ? mitem.Price : 0,
                            ISSN = mitem.ISSN,
                            FrequencyCode = mitem.FrequencyCode,
                            FrequencyValue = mitem.FrequencyValue,
                            CountryCode = mitem.CountryCode,
                            PriceWGST = mitem.PriceWGST != null ? mitem.PriceWGST : 0,
                            PriceWOGST = mitem.PriceWOGST != null ? mitem.PriceWOGST : 0,
                            UnitPrice = mitem.UnitPrice != null ? mitem.UnitPrice : 0,
                            Postal = mitem.Postal != null ? mitem.Postal : 0,
                            IsActive = mitem.IsActive,
                            ChangedBy = mitem.ChangedBy,
                            ChangedOn = mitem.ChangedOn,
                            CreatedBy = mitem.CreatedBy,
                            CreatedOn = mitem.CreatedOn
                        });
                    }
                }
                _data.ProductTags = _tdata;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the book details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the book details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BOOK, inputData.OrganisationId);
            }
            return result;
        }
        public List<GE::BookStock> GetAllProductWithStock(GE::ERPInputmodel inputdata)
        {
            List<GE::BookStock> _list = new List<GE.BookStock>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetProductWithStock(inputdata.OrganisationId, inputdata.IsActive, inputdata.BranchCode).ToList();

                if (_data != null && _data.Count > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.BookStock
                        {
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            AvailableBoxQty = item.AvailableBoxQty,
                            AvailablePcsQty = item.AvailablePcsQty,
                            AvailableQty = item.AvailableQty,
                            AvailableWQty = item.AvailableWQty,
                            WeightProduct = item.WeightProduct,
                            PcsPerCarton = item.PcsPerCarton,
                            Category = item.Category,
                            SubCategory = item.SubCategory
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCT, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::Book> GetbyTagCode(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            List<GE::Book> _data = new List<GE.Book>();
            try
            {
                _data = (from A in ERPMASTERDatabase().Master_Book
                         join B in ERPMASTERDatabase().ProductTags on new { X1 = A.OrgId, X2 = A.BookId } equals new { X1 = B.OrgId, X2 = B.ProductCode }
                         where B.OrgId == inputdata.OrganisationId && B.TagCode == inputdata.TranNo
                         select new GE::Book
                         {
                             OrgId = A.OrgId,
                             BookId = A.BookId,
                             ISBN10 = A.ISBN10,
                             ISBN13 = A.ISBN13,
                             BranchCode = !string.IsNullOrEmpty(A.BranchCode) ? A.BranchCode : string.Empty,
                             Title = !string.IsNullOrEmpty(A.Title) ? A.Title : string.Empty,
                             SubTitle = !string.IsNullOrEmpty(A.SubTitle) ? A.SubTitle : string.Empty,
                             AuthorName = !string.IsNullOrEmpty(A.AuthorName) ? A.AuthorName : string.Empty,
                             CategoryId = !string.IsNullOrEmpty(A.CategoryId) ? A.CategoryId : string.Empty,
                             Publisher = !string.IsNullOrEmpty(A.Publisher) ? A.Publisher : string.Empty,
                             Language = !string.IsNullOrEmpty(A.Language) ? A.Language : string.Empty,
                             BindingType = !string.IsNullOrEmpty(A.BindingType) ? A.Language : string.Empty,
                             CostPrice = A.CostPrice != null ? A.CostPrice : 0,
                             Margin = A.Margin != null ? A.Margin : 0,
                             Width = A.Width != null ? A.Width : 0,
                             SalesPrice = A.SalesPrice != null ? A.SalesPrice : 0,
                             Length = A.Length != null ? A.Length : 0,
                             Breadth = A.Breadth != null ? A.Breadth : 0,
                             Height = A.Height != null ? A.Height : 0,
                             PublishDate = A.PublishDate,
                             //PublishDateString = (A.PublishDate != null) ? A.PublishDate.Value.ToERPdate() : string.Empty,
                             TotalPages = A.TotalPages != null ? A.TotalPages : 0,
                             Edition = A.Edition != null ? A.Edition : 0,
                             DetailDescription = A.DetailDescription,
                             SupplierId = A.SupplierId,
                             UnitCost = A.UnitCost != null ? A.UnitCost : 0,
                             SellingPrice = A.SellingPrice != null ? A.SellingPrice : 0,
                             SellingPriceMargin = A.SellingPriceMargin != null ? A.SellingPriceMargin : 0,
                             RetailPrice = A.RetailPrice != null ? A.SellingPriceMargin : 0,
                             RetailPriceMargin = A.RetailPriceMargin != null ? A.RetailPriceMargin : 0,
                             B2CPrice = A.B2CPrice != null ? A.B2CPrice : 0,
                             B2CPriceMargin = A.B2CPriceMargin != null ? A.B2CPriceMargin : 0,
                             Weight = A.Weight != null ? A.Weight : 0,
                             Thickness = A.Thickness != null ? A.Thickness : 0,
                             IsActive = A.IsActive != null ? A.IsActive : false,
                             IsB2C = A.IsB2C != null ? A.IsB2C : false,
                             IsPos = A.IsPos != null ? A.IsPos : false,
                             IsNetPrice = A.IsNetPrice != null ? A.IsNetPrice : false,
                             BookImage = URL_BookImgPath,
                             ChangedBy = A.ChangedBy,
                             ChangedOn = A.ChangedOn,
                             CreatedBy = A.CreatedBy,
                             CreatedOn = A.CreatedOn,
                         }).ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public List<GE::BookAuthorSearch> GetAllByAuthor(GE::ERPInputmodel inputdata)
        {
            List<GE::BookAuthorSearch> _list = new List<GE.BookAuthorSearch>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetBookDetail(inputdata.OrganisationId, inputdata.TranNo, inputdata.ISBN13, inputdata.ISBN10, inputdata.title).Where(x => x.IsActive == inputdata.IsActive && x.AuthorName != String.Empty).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.BookAuthorSearch
                        {
                            AuthorName = item.AuthorName,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::CategoryTag> GetByCategoryTagCode(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            List<GE::CategoryTag> _data = new List<GE.CategoryTag>();
            List<GE::Book> _bdata = new List<GE.Book>();
            try
            {
                var data = (from A in ERPMASTERDatabase().Master_Category
                            join B in ERPMASTERDatabase().Master_CategoryTag on new { X1 = A.OrgId, X2 = A.Code } equals new { X1 = B.OrgId, X2 = B.CategoryCode } into co
                            from B in co.DefaultIfEmpty()
                            where B.OrgId == inputdata.OrganisationId && A.Code == inputdata.TranNo
                            select new { A, B }).ToList();
                if (data != null && data.Count > 0)
                {
                    data.ForEach(item => {

                        _bdata = (from A in ERPMASTERDatabase().Master_Book
                                  join B in ERPMASTERDatabase().ProductTags on new { X1 = A.OrgId, X2 = A.BookId } equals new { X1 = B.OrgId, X2 = B.ProductCode } into co
                                  from B in co.DefaultIfEmpty()
                                  where B.OrgId == inputdata.OrganisationId && B.TagCode == item.B.TagCode
                                  select new GE::Book
                                  {
                                      OrgId = A.OrgId,
                                      BookId = A.BookId,
                                      ISBN10 = A.ISBN10,
                                      ISBN13 = A.ISBN13,
                                      BranchCode = !string.IsNullOrEmpty(A.BranchCode) ? A.BranchCode : string.Empty,
                                      Title = !string.IsNullOrEmpty(A.Title) ? A.Title : string.Empty,
                                      SubTitle = !string.IsNullOrEmpty(A.SubTitle) ? A.SubTitle : string.Empty,
                                      AuthorName = !string.IsNullOrEmpty(A.AuthorName) ? A.AuthorName : string.Empty,
                                      CategoryId = !string.IsNullOrEmpty(A.CategoryId) ? A.CategoryId : string.Empty,
                                      Publisher = !string.IsNullOrEmpty(A.Publisher) ? A.Publisher : string.Empty,
                                      Language = !string.IsNullOrEmpty(A.Language) ? A.Language : string.Empty,
                                      BindingType = !string.IsNullOrEmpty(A.BindingType) ? A.Language : string.Empty,
                                      CostPrice = A.CostPrice != null ? A.CostPrice : 0,
                                      Margin = A.Margin != null ? A.Margin : 0,
                                      Width = A.Width != null ? A.Width : 0,
                                      SalesPrice = A.SalesPrice != null ? A.SalesPrice : 0,
                                      Length = A.Length != null ? A.Length : 0,
                                      Breadth = A.Breadth != null ? A.Breadth : 0,
                                      Height = A.Height != null ? A.Height : 0,
                                      PublishDate = A.PublishDate,
                                      //PublishDateString = (A.PublishDate != null) ? A.PublishDate.Value.ToERPdate() : string.Empty,
                                      TotalPages = A.TotalPages != null ? A.TotalPages : 0,
                                      Edition = A.Edition != null ? A.Edition : 0,
                                      DetailDescription = A.DetailDescription,
                                      SupplierId = A.SupplierId,
                                      UnitCost = A.UnitCost != null ? A.UnitCost : 0,
                                      SellingPrice = A.SellingPrice != null ? A.SellingPrice : 0,
                                      SellingPriceMargin = A.SellingPriceMargin != null ? A.SellingPriceMargin : 0,
                                      RetailPrice = A.RetailPrice != null ? A.SellingPriceMargin : 0,
                                      RetailPriceMargin = A.RetailPriceMargin != null ? A.RetailPriceMargin : 0,
                                      B2CPrice = A.B2CPrice != null ? A.B2CPrice : 0,
                                      B2CPriceMargin = A.B2CPriceMargin != null ? A.B2CPriceMargin : 0,
                                      Weight = A.Weight != null ? A.Weight : 0,
                                      Thickness = A.Thickness != null ? A.Thickness : 0,
                                      IsActive = A.IsActive != null ? A.IsActive : false,
                                      IsB2C = A.IsB2C != null ? A.IsB2C : false,
                                      IsPos = A.IsPos != null ? A.IsPos : false,
                                      IsNetPrice = A.IsNetPrice != null ? A.IsNetPrice : false,
                                      BookImage = URL_BookImgPath,
                                      ChangedBy = A.ChangedBy,
                                      ChangedOn = A.ChangedOn,
                                      CreatedBy = A.CreatedBy,
                                      CreatedOn = A.CreatedOn,
                                  }).ToList();

                        _data.Add(new GE::CategoryTag
                        {
                            OrgId = item.A.OrgId,
                            CategoryCode = item.A.Code,
                            CategoryName = !string.IsNullOrEmpty(item.A.Name) ? item.A.Name : string.Empty,
                            TagCode = !string.IsNullOrEmpty(item.B.TagCode) ? item.B.TagCode : string.Empty,
                            ChangedBy = item.A.ChangedBy,
                            ChangedOn = item.A.ChangedOn,
                            CreatedBy = item.A.CreatedBy,
                            CreatedOn = item.A.CreatedOn,
                            BookDetails = _bdata
                        });
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public List<GE::SubCategoryTag> GetBySubCategoryTagCode(GE::ERPInputmodel inputdata)
        {
            string URL_BookImgPath = string.Empty;
            List<GE::SubCategoryTag> _data = new List<GE.SubCategoryTag>();
            List<GE::Book> _bdata = new List<GE.Book>();
            try
            {
                var data = (from A in ERPMASTERDatabase().Master_SubCategory
                            join B in ERPMASTERDatabase().Master_SubCategoryTag on new { X1 = A.OrgId, X2 = A.Code } equals new { X1 = B.OrgId, X2 = B.SubCategoryCode } into co
                            from B in co.DefaultIfEmpty()
                            where B.OrgId == inputdata.OrganisationId && A.Code == inputdata.TranNo
                            select new { A, B }).ToList();
                if (data != null && data.Count > 0)
                {
                    data.ForEach(item => {

                        _bdata = (from A in ERPMASTERDatabase().Master_Book
                                  join B in ERPMASTERDatabase().ProductTags on new { X1 = A.OrgId, X2 = A.BookId } equals new { X1 = B.OrgId, X2 = B.ProductCode } into co
                                  from B in co.DefaultIfEmpty()
                                  where B.OrgId == inputdata.OrganisationId && B.TagCode == item.B.TagCode
                                  select new GE::Book
                                  {
                                      OrgId = A.OrgId,
                                      BookId = A.BookId,
                                      ISBN10 = A.ISBN10,
                                      ISBN13 = A.ISBN13,
                                      BranchCode = !string.IsNullOrEmpty(A.BranchCode) ? A.BranchCode : string.Empty,
                                      Title = !string.IsNullOrEmpty(A.Title) ? A.Title : string.Empty,
                                      SubTitle = !string.IsNullOrEmpty(A.SubTitle) ? A.SubTitle : string.Empty,
                                      AuthorName = !string.IsNullOrEmpty(A.AuthorName) ? A.AuthorName : string.Empty,
                                      CategoryId = !string.IsNullOrEmpty(A.CategoryId) ? A.CategoryId : string.Empty,
                                      Publisher = !string.IsNullOrEmpty(A.Publisher) ? A.Publisher : string.Empty,
                                      Language = !string.IsNullOrEmpty(A.Language) ? A.Language : string.Empty,
                                      BindingType = !string.IsNullOrEmpty(A.BindingType) ? A.Language : string.Empty,
                                      CostPrice = A.CostPrice != null ? A.CostPrice : 0,
                                      Margin = A.Margin != null ? A.Margin : 0,
                                      Width = A.Width != null ? A.Width : 0,
                                      SalesPrice = A.SalesPrice != null ? A.SalesPrice : 0,
                                      Length = A.Length != null ? A.Length : 0,
                                      Breadth = A.Breadth != null ? A.Breadth : 0,
                                      Height = A.Height != null ? A.Height : 0,
                                      PublishDate = A.PublishDate,
                                      //PublishDateString = (A.PublishDate != null) ? A.PublishDate.Value.ToERPdate() : string.Empty,
                                      TotalPages = A.TotalPages != null ? A.TotalPages : 0,
                                      Edition = A.Edition != null ? A.Edition : 0,
                                      DetailDescription = A.DetailDescription,
                                      SupplierId = A.SupplierId,
                                      UnitCost = A.UnitCost != null ? A.UnitCost : 0,
                                      SellingPrice = A.SellingPrice != null ? A.SellingPrice : 0,
                                      SellingPriceMargin = A.SellingPriceMargin != null ? A.SellingPriceMargin : 0,
                                      RetailPrice = A.RetailPrice != null ? A.SellingPriceMargin : 0,
                                      RetailPriceMargin = A.RetailPriceMargin != null ? A.RetailPriceMargin : 0,
                                      B2CPrice = A.B2CPrice != null ? A.B2CPrice : 0,
                                      B2CPriceMargin = A.B2CPriceMargin != null ? A.B2CPriceMargin : 0,
                                      Weight = A.Weight != null ? A.Weight : 0,
                                      Thickness = A.Thickness != null ? A.Thickness : 0,
                                      IsActive = A.IsActive != null ? A.IsActive : false,
                                      IsB2C = A.IsB2C != null ? A.IsB2C : false,
                                      IsPos = A.IsPos != null ? A.IsPos : false,
                                      IsNetPrice = A.IsNetPrice != null ? A.IsNetPrice : false,
                                      BookImage = URL_BookImgPath,
                                      ChangedBy = A.ChangedBy,
                                      ChangedOn = A.ChangedOn,
                                      CreatedBy = A.CreatedBy,
                                      CreatedOn = A.CreatedOn,
                                  }).ToList();

                        _data.Add(new GE::SubCategoryTag
                        {
                            OrgId = item.A.OrgId,
                            SubCategoryCode = item.A.Code,
                            SubCategoryName = !string.IsNullOrEmpty(item.A.Name) ? item.A.Name : string.Empty,
                            TagCode = !string.IsNullOrEmpty(item.B.TagCode) ? item.B.TagCode : string.Empty,
                            ChangedBy = item.A.ChangedBy,
                            ChangedOn = item.A.ChangedOn,
                            CreatedBy = item.A.CreatedBy,
                            CreatedOn = item.A.CreatedOn,
                            BookDetails = _bdata
                        });
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _data;
        }

        public string SaveShopeeToken(GE::ShopeeResponse item, string user, int organizationId)
        {
            string result = string.Empty;

            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Shopee_Token.FirstOrDefault(o => o.OrgId == organizationId && o.AccessToken == item.access_token);
                    if (_data != null)
                    {
                        _data.AccessToken = item.access_token;
                        _data.RefreshToken = item.refresh_token;
                        _data.RequestId = item.request_id;
                        _data.ExpireIn = item.expire_in;
                        _data.Error = item.error;
                        _data.Message = item.message;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        _data.ShopeeCode = item.ShopeeCode;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        var _data1 = ERPMASTERDatabase().Shopee_Token.Where(o => o.OrgId == organizationId && o.IsActive == true).ToList();
                        if (_data1 != null && _data1.Count > 0)
                        {
                            _data1.ForEach(d => {
                                d.IsActive = false;
                                ERPMASTERDatabase().SaveChanges();
                                result = PASS;
                            });
                        }
                        Shopee_Token token = new Shopee_Token()
                        {
                            OrgId = organizationId,
                            AccessToken = item.access_token,
                            RefreshToken = item.refresh_token,
                            RequestId = item.request_id,
                            ExpireIn = item.expire_in,
                            Error = item.error,
                            Message = item.message,
                            ShopId = item.ShopId,
                            Code = item.Code,
                            Sign = item.Sign,
                            IsActive = true,
                            ShopeeCode = item.ShopeeCode,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                        };
                        ERPMASTERDatabase().Shopee_Token.Add(token);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, BOOK, organizationId);
            }
            return result;
        }

        public GE::ShopeeToken GetShopeeAccessToken(GE::ERPInputmodel inputdata)
        {
            GE::ShopeeToken _list = new GE.ShopeeToken();
            try
            {
                var _data = ERPMASTERDatabase().Shopee_Token.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.IsActive == true);
                if (_data != null)
                {

                    _list = new GE.ShopeeToken
                    {
                        OrgId = _data.OrgId,

                        SlNo = _data.SlNo,
                        AccessToken = _data.AccessToken,
                        RefreshToken = _data.RefreshToken,
                        RequestId = _data.RequestId,
                        ExpireIn = _data.ExpireIn,
                        Error = _data.Error,
                        Message = _data.Message,
                        ShopId = _data.ShopId,
                        Code = _data.Code,
                        Sign = _data.Sign,
                        IsActive = _data.IsActive,
                        ShopeeCode = _data.ShopeeCode,
                        CreatedBy = _data.CreatedBy,
                        CreatedOn = _data.CreatedOn,
                        ChangedBy = _data.ChangedBy,
                        ChangedOn = _data.ChangedOn,
                    };
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::Book> GetAllProductMagazine(GE::ERPInputmodel inputdata)
        {
            List<GE::Book> _list = new List<GE.Book>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetBookDetailWithMagazine(inputdata.OrganisationId).Where(x => x.IsActive == inputdata.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Book
                        {
                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            BookId = item.BookId,
                            ISBN13 = item.ISBN13,
                            ISBN10 = item.ISBN10,
                            Title = item.Title,
                            AuthorName = item.AuthorName,
                            DetailDescription = item.DetailDescription,
                            SubTitle = item.SubTitle,
                            CategoryId = item.CategoryId,
                            Publisher = item.Publisher,
                            Language = item.Language,
                            BindingType = item.BindingType,
                            CostPrice = item.CostPrice,
                            Margin = item.Margin,
                            SalesPrice = item.SalesPrice,
                            Length = item.Length,
                            Breadth = item.Breadth,
                            Width = item.Width,
                            Height = item.Height,
                            IsNetPrice = false,
                            PublishDate = item.PublishDate,
                            Edition = item.Edition,
                            TotalPages = item.TotalPages,
                            SupplierId = item.SupplierId,
                            UnitCost = item.UnitCost,
                            SellingPrice = item.SellingPrice,
                            SellingPriceMargin = item.SellingPriceMargin,
                            RetailPrice = item.RetailPrice,
                            RetailPriceMargin = item.RetailPriceMargin,
                            B2CPrice = item.B2CPrice,
                            B2CPriceMargin = item.B2CPriceMargin,
                            Thickness = item.Thickness,
                            Uom = item.Uom,
                            BookImage = item.BookImage,
                            SlNo = item.SlNo,
                            ProductImage = item.ProductImage,
                            ProductImageURL = item.ProductImageURL,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                            Type = item.Type
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE.MultiTenant> GetMultiTenant(GE::ERPInputmodel inputdata)
        {
            List <GE.MultiTenant> multiTenants = new List<GE.MultiTenant>();
            try
            {
                var data = ERPMASTERDatabase().Vw_MultiTenant.Select(s => s).ToList();
                if (data != null && data.Any())
                {
                    data.ForEach(item =>
                    {
                        multiTenants.Add(new GE.MultiTenant
                        {
                            RowNo = item.RowNo,
                            Code = item.Code,
                            Category = item.Category,
                            ShopName = item.ShopName
                            
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return multiTenants;
        }
        public List<GE.EcommerceMultiTenant> GetTenentbyBookId(GE::ERPInputmodel inputdata)
        {
            List<GE::EcommerceMultiTenant> data = new List<GE.EcommerceMultiTenant>();
            try
            {
                var multitenants = ERPMASTERDatabase().Ecommerce_Multitenant.Where(o => o.BookId == inputdata.BookId && o.OrgId == inputdata.OrganisationId && o.IsActive == true).ToList();
                
                if (multitenants?.Any() == true)
                {
                    multitenants.ForEach(items =>
                    {
                        data.Add(new GE.EcommerceMultiTenant
                        {
                            OrgId = items.OrgId,
                            BookId = items.BookId,
                            ShopCode = items.ShopCode,
                            Price = items.Price,
                            IsLazadaSkuActive = items.IsLazadaSkuActive
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return data;
        }
        public string GetbyLazadaShopCode(GE::ERPInputmodel inputdata)
        {
            string appKey = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Lazada.FirstOrDefault(o => o.LazadaCode == inputdata.LazadaCode && o.OrgId == inputdata.OrganisationId);

                if (item != null)
                {
                    appKey = item.AppKey;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BOOK, inputdata.OrganisationId);
            }
            return appKey;
        }
        public async Task<bool> DeleteLazadaProduct(string BookId, string ShopCode,string OAuth)
        {
            LazadaClient objLazadaClient = new LazadaClient();
            return await objLazadaClient.DeleteLazadaProduct(BookId,ShopCode, OAuth);
        }
    }
}

