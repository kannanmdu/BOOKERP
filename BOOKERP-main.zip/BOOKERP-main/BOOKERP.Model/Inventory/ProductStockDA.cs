﻿using Dapper;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class ProductStockDA : CommonDA
    {
        public List<GE::ProductStock> GetAll(GE::ERPInputmodel inputdata)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["BOOKMERCHANT_DEVConnectionString"].ConnectionString; ;
            List<GE::ProductStock> _list = new List<GE.ProductStock>();
            try
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    string sqlQuery = @" EXEC GetAllProductStock @OrganisationId,@BranchCode,@LoginUser";

                    var parameters = new
                    {
                        OrganisationId = inputdata.OrganisationId,
                        BranchCode = inputdata.BranchCode,
                        LoginUser = "",
                    };

                    var Books = connection.Query<GE.ProductStock>(sqlQuery, parameters).ToList();
                    return Books;
                }
                ////_list = (from p in ERPMASTERDatabase().Product_ProductStock.Where(o => o.OrgId == inputdata.OrganisationId && o.BranchCode == inputdata.BranchCode)
                ////         orderby p.ProductCode ascending
                ////         group p by p.ProductCode into pg
                ////         join bp in ERPMASTERDatabase().Master_Book.Where(o => o.OrgId == inputdata.OrganisationId)
                ////         on pg.FirstOrDefault().ProductCode equals bp.BookId

                ////         select new GE.ProductStock
                ////         {
                ////             ProductName = pg.FirstOrDefault().ProductName,
                ////             OrgId = pg.FirstOrDefault().OrgId,
                ////             BranchCode = pg.FirstOrDefault().BranchCode,
                ////             ProductCode = pg.FirstOrDefault().ProductCode,
                ////             StockQty = pg.Sum(c => c.StockQty),
                ////             StockBoxQty = pg.Sum(c => c.StockBoxQty),
                ////             StockPcsQty = pg.Sum(c => c.StockPcsQty),
                ////             BoxCount = pg.FirstOrDefault().BoxCount,
                ////             CreatedBy = pg.FirstOrDefault().CreatedBy,
                ////             CreatedOn = pg.FirstOrDefault().CreatedOn,
                ////             ChangedBy = pg.FirstOrDefault().ChangedBy,
                ////             ChangedOn = pg.FirstOrDefault().ChangedOn,
                ////             StockWQty = pg.Sum(c => c.StockWQty),
                ////             ISBN13 = bp.ISBN13,
                ////             AuthorName = bp.AuthorName,
                ////             Title = bp.Title,
                ////             Publisher = bp.Publisher,
                ////             ISBN10 = bp.ISBN10
                ////             //Category = bp.Category,
                ////             //SubCategory = bp.SubCategory,
                ////             //SupplierCode = bp.SupplierCode,
                ////             //UnitCost = bp.PcsPrice,
                ////             //SellingCost = bp.SellingCost
                ////         }).ToList();

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCTSTOCK, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::ProductStock> GetAllStockInfo(GE::ERPInputmodel inputdata)
        {
            List<GE::ProductStock> _list = new List<GE.ProductStock>();
            try
            {
                var _data = ERPMASTERDatabase().Product_ProductStock.Where(o => o.ProductCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).OrderBy(o => o.ProductCode).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.ProductStock
                        {

                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            StockQty = item.StockQty,
                            StockBoxQty = item.StockBoxQty,
                            StockPcsQty = item.StockPcsQty,
                            BoxCount = item.BoxCount,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            StockWQty = item.StockWQty
                        });
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCTSTOCK, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::ProductStock> GetAllStockMovement(GE::ERPInputmodel inputdata)
        {
            List<GE::ProductStock> _list = new List<GE.ProductStock>();
            try
            {

                var _data = ERPMASTERDatabase().Sp_GetStockMovement(inputdata.OrganisationId, inputdata.TranNo, inputdata.FromDate, inputdata.ToDate, inputdata.BranchCode).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.ProductStock
                        {
                            Type = item.Type,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate != null) ? item.TranDate.ToERPdate() : string.Empty,
                            BranchCode = item.LocationCode,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            BoxCount = item.BoxCount,
                            BoxQty = item.BoxQty,
                            PcsQty = item.PcsQty,
                            Qty = item.Qty,
                            WQty = item.WQty,
                            CustomerId = item.CustomerId,
                            CustomerName = item.CustomerName
                        });
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCTSTOCK, inputdata.OrganisationId);
            }
            return _list;
        }

    }
}
