﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;
using System.Net;
using System.Web;
using System.Data.Entity;
using System.Security.Cryptography;
using System.IO;
using GE = BOOKERP.Entities;
using System.Data.Common;
using System.Reflection;

namespace BOOKERP.Model
{
    public class CommonDA
    {
        BOOKMERCHANT_DEVEntities db1 = new BOOKMERCHANT_DEVEntities();
        private string _connectionstring = ConfigurationManager.ConnectionStrings["BOOKMERCHANT_DEVEntities"].ConnectionString;


        #region Constant
        public const string MAGAZINES = "Magazines";
        public const string SUBSCRIPTION = "Subscription";
        public const string ACTIVE = "Active";
        public const string CASHREGISTER = "CASHREGISTER";
        public const string INACTIVE = "In Active";
        public const string EDITPROFILE = "EditProfile";
        public const string COMPANY = "company";
        public const string ORGANIZATION = "Organization";
        public const string PAYMODE = "PayMode";
        public const string CURRENCY = "Currency";
        public const string GIFTVOUCHER = "GiftVoucher";        
        public const string FREQUENCY = "Frequency";
        public const string GIFTVOUCHERSETTINGS = "GiftVoucherSettings";
        public const string AREA = "Area";
        public const string BOOK = "Book";
        public const string CUSTOMERGROUP = "CustomerGroup";
        public const string CUSTOMERTYPE = "CustomerType";
        public const string STOCKADJUSTMENTMASTER = "StockAdjustmentType";
        public const string CUSTOMERVISITED = "CustomerVisited";
        public const string CUSTOMER = "Customer";
        public const string B2CCUSTOMER = "B2CCustomer";
        public const string SUPPLIER = "Supplier";
        public const string USER = "User";
        public const string BANK = "Bank";
        public const string DEPARTMENT = "Department";
        public const string DRIVER = "Driver";
        public const string VEHICLE = "Vehicle";
        public const string TAX = "Tax";
        public const string USERGROUP = "UserGroup";
        public const string USERPERMISSION = "UserPermission";
        public const string EMPLOYEE = "Employee";
        public const string ATTENDANCE = "Attendance";
        public const string DESIGNATIONS = "Designations";
        public const string BANNERS = "Banners";
        public const string VARIANT = "Variant";
        public const string VARIANTQTY = "VariantQty";
        public const string VARIANTPACKSIZE = "VariantPackSize";
        public const string ACTIVITY = "Activity";
        public const string ATTRIBUTES = "Attributes";
        public const string MANUFACTURERS = "Manufacturers";
        public const string SPECIFICATIONS = "Specifications";
        public const string TYPES = "Types";
        public const string VENDORS = "Vendors";
        public const string WAREHOUSES = "Warehouses";
        public const string BRANCH = "Branch";
        public const string COUNTRY = "Country";
        public const string TERMS = "Terms";
        public const string CATEGORY = "Category";
        public const string SUBCATEGORY = "subcategory";
        public const string UOM = "UOM";
        public const string BRAND = "Brand";
        public const string PRODUCT = "Product";
        public const string DASHBOARD = "Dashboard";
        public const string OFFERS = "Offers";
        public const string ORDERS = "Orders";
        public const string PRODUCTIMAGE = "ProductImage";
        public const string PRODUCTPRICE = "ProductPrice";
        public const string ITEMATTRIBUTES = "ItemAttributes";
        public const string POSINVOICE = "PosInvoice";
        public const string POSHOLDINVOICE = "PosHoldInvoice";
        public const string POSRECEIPT = "PosReceipt";
        public const string POSWORKSTATION = "PosWorkStation";
        public const string MEMBER = "Member";
        public const string CUSTOMERCONTACT = "Customercontact";
        public const string CUSTOMERDELIVERY = "Customerdelivery";
        public const string B2CCUSTOMERDELIVERY = "B2CCustomerdelivery";
        public const string HOMEDESIGNS = "HomeDesigns";
        public const string PURCHASEREQUEST = "PurchaseRequest";
        public const string PURCHASERETURN = "PurchaseReturn";
        public const string PURCHASEORDERDETAILS = "PurchaseOrderDetails";
        public const string PURCHASEORDERHEADER = "PurchaseOrderHeader";
        public const string PURCHASEORDER = "PurchaseOrder";
        public const string GOODSRECEIVE = "GoodsReceive";
        public const string STOCKIN = "StockIn";
        public const string STOCKINACCOUNT = "StockInAccount";
        public const string STOCKINRETURN = "StockInReturn";
        public const string STOCKINDO = "StockInDo";
        public const string SALESORDER = "SalesOrder";
        public const string PACKINGLIST = "Packinglist";
        public const string SALESDO = "SalesDo";
        public const string EXCHANGE = "Exchange";
        public const string INVOICE = "Invoice";
        public const string SALESRETURN = "SalesReturn";
        public const string PRODUCTVARIANT = "Productvariant";
        public const string PRICESETTINGS = "PriceSettings";
        public const string PASS = "pass";
        public const string FAIL = "fail";
        public const string ITEM = "Item";
        public const string ECOMCUSTOMER = "EComCustomer";
        public const int INCREASE = 1;
        public const string PRODUCTVARIANTSTOCK = "ProductVariantStock";
        public const string PRODUCTSTOCK = "ProductStock";
        public const string TRANSFER = "Transfer";
        public const string STOCKTAKE = "StockTake";
        public const string STOCKREQUEST = "StockRequest";
        public const string CHARTOFACCOUNT = "ChartOfAccount";
        public const string GENERALLEDGER = "GeneralLEDGER";
        public const string TRIALBALANCE = "TrialBalance";
        public const string BALANCESHEET = "BalanceSheet";
        public const string PROFITLOSS = "ProfitLoss";
        public const string STOCKADJUSTMENT = "StockAdjustment";
        public Guid DUMMYGUID = Guid.Parse("00000000-0000-0000-0000-000000000000");

        public const string RECEIPT = "receipt";
        public const string PAYMENT = "payment";
        public const string VOUCHER = "voucher";
        public const string STAFF = "Staff";
        public const string PUBLICHOLIDAY = "PublicHoliday";
        public const string CHARGESDISCOUNT = "ChargesDiscount";
        public const string INCOME = "income";

        public const string TAG = "Tag";
        public const string SALESQUOTE = "SalesQuote";
        public const string B2CBANNERIMAGE = "B2CBannerImage";
        public const string CONSIGNMENT = "Consignment";
        public const string B2CCUSTOMERORDER = "B2CCustomerOrder";
        public const string ECOMMERCE = "ECommerce";

        public const string POSSETTLEMENT = "POSSettlement";
        public const string POSDAYENDSUMMARY = "POSDayEndSummary";
        public const string CASHINOUT = "CashInOut";

        public const string CRMCUSTOMER = "CRMCustomer";
        public const string LEAVE = "Leave";

        public const string SHOPEE = "Shopee";
        public const string LAZADA = "Lazada";

        public const string FINANCIALSETTINGS = "FinancialSettings";

        public const string OPENINGBALANCE = "openingbalance";
        public const string BANKRECONCILIATION = "BankReconcilation";

        #endregion


        public GE::Roleaccess GetAccessPermissionbyModule(string MenuName, string UserRole, string LoginUser, int OrganisationId)
        {
            GE::Roleaccess _data = new GE.Roleaccess();
            try
            {
                var item = ERPMASTERDatabase().Security_UserRolePermission.FirstOrDefault(o => o.SubMenuId == MenuName && o.UserRoleCode == UserRole && o.OrgId == OrganisationId);
                if (item != null)
                {

                    item.IsFullAccess = item.IsFullAccess != null & item.IsFullAccess.HasValue ? item.IsFullAccess.Value : false;
                    item.IsView = item.IsView != null & item.IsView.HasValue ? item.IsView.Value : false;
                    item.IsAdd = item.IsAdd != null & item.IsAdd.HasValue ? item.IsAdd.Value : false;
                    item.IsEdit = item.IsEdit != null & item.IsEdit.HasValue ? item.IsEdit.Value : false;
                    item.IsDelete = item.IsDelete != null & item.IsDelete.HasValue ? item.IsDelete.Value : false;
                    item.IsConvert = item.IsConvert != null & item.IsConvert.HasValue ? item.IsConvert.Value : false;

                    _data = (new GE.Roleaccess
                    {
                        OrganisationId = item.OrgId,
                        UserRolecode = item.UserRoleCode,
                        MenuId = item.MenuId,
                        SubMenuId = item.SubMenuId,

                        IsFullAccess = item.IsFullAccess != null & item.IsFullAccess.Value ? 1 : 0,
                        IsView = item.IsView != null & item.IsView.Value ? 1 : 0,
                        IsAdd = item.IsAdd != null & item.IsAdd.Value ? 1 : 0,
                        IsEdit = item.IsEdit != null & item.IsEdit.Value ? 1 : 0,
                        IsDelete = item.IsDelete != null & item.IsDelete.Value ? 1 : 0,
                        IsConvert = item.IsConvert != null & item.IsConvert.Value ? 1 : 0

                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, LoginUser, USERPERMISSION, OrganisationId);
            }
            return _data;
        }
        public BOOKMERCHANT_DEVEntities ERPMASTERDatabase()
        {
            return db1;
        }
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["ERPBOOKMERCHANT"].ConnectionString;
        public IDbConnection GetConnection
        {
            get
            {
                var factory = DbProviderFactories.GetFactory("System.Data.SqlClient");
                var conn = factory.CreateConnection();
                conn.ConnectionString = connectionString;

                if (conn.State != ConnectionState.Open)
                {
                    conn.Close();
                    conn.Open();
                }
                return conn;
            }
        }
        public class ListtoDataTableConverter
        {
            public DataTable ToDataTable<T>(List<T> items)
            {
                DataTable dataTable = new DataTable(typeof(T).Name);
                //Get all the properties
                PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo prop in Props)
                {
                    //Setting column names as Property names
                    dataTable.Columns.Add(prop.Name);
                }
                foreach (T item in items)
                {
                    var values = new object[Props.Length];
                    for (int i = 0; i < Props.Length; i++)
                    {
                        //inserting property values to datatable rows
                        values[i] = Props[i].GetValue(item, null);
                    }
                    dataTable.Rows.Add(values);
                }
                //put a breakpoint here and check datatable
                return dataTable;
            }
        }
        public int GetMaxID(string Modulename, int companyid = 0)
        {
            int id = 1;
            if (Modulename == ORGANIZATION)
            {
                if (db1.Master_Organization.Count() > 0)
                {
                    id = db1.Master_Organization.Max(o => o.OrgId) + 1;
                }
            }
            if (Modulename == B2CCUSTOMERDELIVERY)
            {
                if (db1.B2C_CustomerDeliveryAddress.Count() > 0)
                {
                    id = db1.B2C_CustomerDeliveryAddress.Max(o => o.DeliveryId) + 1;
                }
            }
            if (Modulename == SHOPEE)
            {
                if (db1.Master_Shopee.Count() > 0)
                {
                    id = db1.Master_Shopee.Max(o => o.OrgId) + 1;
                }
            }
            return id;
        }

        public string CheckNull(string text)
        {
            var result = String.IsNullOrEmpty(text) ? string.Empty : text;
            return result;
        }

        public string GetTransactionNumber(string Module, string BranchCode, int OrgId)
        {
            string Result = string.Empty;
            var _result = ERPMASTERDatabase().SP_GetTransactionNumber(OrgId, BranchCode, Module).FirstOrDefault();
            if (_result != null)
            {
                Result = _result.Result;
            }
            return Result;
        }

        public bool IsMobileExist(string Module, string Mobile, int OrgId)
        {
            bool Result = false;
            if (Module == ORGANIZATION)
            {
                var item = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.MobileNo == Mobile && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == BRANCH)
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.MobileNo == Mobile && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }      
            if (Module == USER || Module == EDITPROFILE)
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.MobileNo == Mobile && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == CUSTOMER)
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.Mobile == Mobile && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == EMPLOYEE)
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.MobileNo == Mobile && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            return Result;
        }
        public bool IsEmailExist(string Module, string Email, int OrgId)
        {
            bool Result = false;
            if (Module == ORGANIZATION)
            {
                var item = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.Email == Email && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == BRANCH)
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.Email == Email && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }      
            if (Module == USER || Module == EDITPROFILE)
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.EmailId == Email && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == CUSTOMER)
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.EMail == Email && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == EMPLOYEE)
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.Email == Email && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            return Result;
        }
        public bool IsCodeExist(string Module, string Code, int OrgId)
        {
            bool Result = false;
            if (Module == BRANCH)
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.BranchCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }

            if (Module == CURRENCY)
            {
                var item = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.CurrencyCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == TERMS)
            {
                var item = ERPMASTERDatabase().Master_Term.FirstOrDefault(o => o.TermCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == CUSTOMER)
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.Code == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == SUPPLIER)
            {
                var item = ERPMASTERDatabase().Master_Suppliers.FirstOrDefault(o => o.Code == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == CASHREGISTER.ToLower())
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.CashRegisterCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == B2CCUSTOMER.ToLower())
            {
                var item = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == B2CBANNERIMAGE.ToLower())
            {
                var item = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.BannerId == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == GIFTVOUCHER.ToLower())
            {
                var item = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.VoucherCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == GIFTVOUCHERSETTINGS.ToLower())
            {
                var item = ERPMASTERDatabase().Master_GiftVoucherSettings.FirstOrDefault(o => o.VoucherSettingsCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == FREQUENCY.ToLower())
            {
                var item = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.FrequencyCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == SUBSCRIPTION.ToLower())
            {
                var item = ERPMASTERDatabase().Master_Subscription.FirstOrDefault(o => o.DocNo == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == EMPLOYEE)
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == Code && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            return Result;
        }
        public bool IsNameExist(string Module, string Name, int OrgId)
        {
            bool Result = false;
           
            if (Module == BRANCH)
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.BranchName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == CURRENCY)
            {
                var item = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.CurrencyDesc == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == CASHREGISTER.ToLower())
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.TerminalName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == B2CBANNERIMAGE.ToLower())
            {
                var item = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.Title == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == GIFTVOUCHER.ToLower())
            {
                var item = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.VoucherName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == FREQUENCY.ToLower())
            {
                var item = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.FrequencyName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module.ToLower() == SUBSCRIPTION.ToLower())
            {
                var item = ERPMASTERDatabase().Master_Subscription.FirstOrDefault(o => o.DocName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            if (Module == EMPLOYEE)
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeName == Name && o.OrgId == OrgId);
                if (item != null)
                {
                    Result = true;
                }
            }
            return Result;
        }

        public bool GetAddressAPIDetails(string module, string apiAddress, int orgId, string branchCode, string user)
        {
            bool result = false;
            if (!string.IsNullOrEmpty(apiAddress))
            {
                Master_GetAddressAPIDetails getApiAddress = new Master_GetAddressAPIDetails()
                {
                    OrgId = orgId,
                    BranchCode = branchCode,
                    Address = apiAddress,
                    ModuleName = module,
                    CreatedOn = DateTime.Now,
                    CreatedBy = user
                };
                ERPMASTERDatabase().Master_GetAddressAPIDetails.Add(getApiAddress);
                ERPMASTERDatabase().SaveChanges();
                result = true;
            }            
            return result;
        }

        public static String ConvertToWords(String numb)
        {
            String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
            String endStr = "Only";
            try
            {
                int decimalPlace = numb.IndexOf(".");
                if (decimalPlace > 0)
                {
                    wholeNo = numb.Substring(0, decimalPlace);
                    points = numb.Substring(decimalPlace + 1);
                    if (Convert.ToInt32(points) > 0)
                    {
                        int numDigits = points.Length;
                        if (numDigits == 1)
                            points = points + "0";
                        andStr = "and";// just to separate whole numbers from points/cents    
                        endStr = "Cents " + endStr;//Cents    
                        //pointStr = ConvertDecimals(points);
                        pointStr = ConvertWholeNumber(points).Trim();
                    }
                }
                val = String.Format("{0} {1} {2} {3}", ConvertWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
            }
            catch { }
            return val;
        }

        public static String ConvertDecimals(String number)
        {
            String cd = "", digit = "", engOne = "";
            for (int i = 0; i < number.Length; i++)
            {
                digit = number[i].ToString();
                if (digit.Equals("0"))
                {
                    engOne = "Zero";
                }
                else
                {
                    engOne = ones(digit);
                }
                cd += " " + engOne;
            }
            return cd;
        }

        public static String ones(String Number)
        {
            int _Number = Convert.ToInt32(Number);
            String name = "";
            switch (_Number)
            {

                case 1:
                    name = "One";
                    break;
                case 2:
                    name = "Two";
                    break;
                case 3:
                    name = "Three";
                    break;
                case 4:
                    name = "Four";
                    break;
                case 5:
                    name = "Five";
                    break;
                case 6:
                    name = "Six";
                    break;
                case 7:
                    name = "Seven";
                    break;
                case 8:
                    name = "Eight";
                    break;
                case 9:
                    name = "Nine";
                    break;
            }
            return name;
        }

        public static String ConvertWholeNumber(String Number)
        {
            string word = "";
            try
            {
                bool beginsZero = false;//tests for 0XX    
                bool isDone = false;//test if already translated    
                double dblAmt = (Convert.ToDouble(Number));
                //if ((dblAmt > 0) && number.StartsWith("0"))    
                if (dblAmt > 0)
                {//test for zero or digit zero in a nuemric    
                    beginsZero = Number.StartsWith("0");

                    int numDigits = Number.Length;
                    int pos = 0;//store digit grouping    
                    String place = "";//digit grouping name:hundres,thousand,etc...    
                    switch (numDigits)
                    {
                        case 1://ones' range    

                            word = ones(Number);
                            isDone = true;
                            break;
                        case 2://tens' range    
                            word = tens(Number);
                            isDone = true;
                            break;
                        case 3://hundreds' range    
                            pos = (numDigits % 3) + 1;
                            place = " Hundred ";
                            break;
                        case 4://thousands' range    
                        case 5:
                        case 6:
                            pos = (numDigits % 4) + 1;
                            place = " Thousand ";
                            break;
                        case 7://millions' range    
                        case 8:
                        case 9:
                            pos = (numDigits % 7) + 1;
                            place = " Million ";
                            break;
                        case 10://Billions's range    
                        case 11:
                        case 12:

                            pos = (numDigits % 10) + 1;
                            place = " Billion ";
                            break;
                        //add extra case options for anything above Billion...    
                        default:
                            isDone = true;
                            break;
                    }
                    if (!isDone)
                    {//if transalation is not done, continue...(Recursion comes in now!!)    
                        if (Number.Substring(0, pos) != "0" && Number.Substring(pos) != "0")
                        {
                            try
                            {
                                word = ConvertWholeNumber(Number.Substring(0, pos)) + place + ConvertWholeNumber(Number.Substring(pos));
                            }
                            catch { }
                        }
                        else
                        {
                            word = ConvertWholeNumber(Number.Substring(0, pos)) + ConvertWholeNumber(Number.Substring(pos));
                        }
                    }
                    //ignore digit grouping names    
                    if (word.Trim().Equals(place.Trim())) word = "";
                }
            }
            catch { }
            return word.Trim();
        }

        public static String tens(String Number)
        {
            int _Number = Convert.ToInt32(Number);
            String name = null;
            switch (_Number)
            {
                case 10:
                    name = "Ten";
                    break;
                case 11:
                    name = "Eleven";
                    break;
                case 12:
                    name = "Twelve";
                    break;
                case 13:
                    name = "Thirteen";
                    break;
                case 14:
                    name = "Fourteen";
                    break;
                case 15:
                    name = "Fifteen";
                    break;
                case 16:
                    name = "Sixteen";
                    break;
                case 17:
                    name = "Seventeen";
                    break;
                case 18:
                    name = "Eighteen";
                    break;
                case 19:
                    name = "Nineteen";
                    break;
                case 20:
                    name = "Twenty";
                    break;
                case 30:
                    name = "Thirty";
                    break;
                case 40:
                    name = "Fourty";
                    break;
                case 50:
                    name = "Fifty";
                    break;
                case 60:
                    name = "Sixty";
                    break;
                case 70:
                    name = "Seventy";
                    break;
                case 80:
                    name = "Eighty";
                    break;
                case 90:
                    name = "Ninety";
                    break;
                default:
                    if (_Number > 0)
                    {
                        name = tens(Number.Substring(0, 1) + "0") + " " + ones(Number.Substring(1));
                    }
                    break;
            }
            return name;
        }

        public string GetMasterNextNo(int OrgId, string MenuName)
        {

            string Result = string.Empty;
            var _Result = ERPMASTERDatabase().Fn_MasterGetNextNo(OrgId, MenuName).FirstOrDefault();
            return _Result.NextNo;
        }
        public string AutoTranNo(int OrgId, string Branchcode, string MenuName)
        {
            string Result = string.Empty;
            var _Result = ERPMASTERDatabase().SP_GetTransactionNextId(OrgId, Branchcode, MenuName).FirstOrDefault();
            return _Result.Result;
        }

        public string WriteFile(string Path, string Filename, byte[] byteArray)
        {
            string FilePath = string.Empty;
            try
            {
                Guid BatchID = Guid.NewGuid();
                if (!Directory.Exists(Path))
                {
                    Directory.CreateDirectory(Path);
                }
                FilePath = Path + "\\" + BatchID + "_" + Filename;
                ByteArrayToFile(FilePath, byteArray);
            }
            catch (Exception ex)
            {

            }
            return FilePath;
        }
        public bool ByteArrayToFile(string fileName, byte[] byteArray)
        {
            try
            {
                using (var fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
                {
                    fs.Write(byteArray, 0, byteArray.Length);
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught in process: {0}", ex);
                return false;
            }
        }

        public GE::EmailTemplate GetbyEmailTemplate(GE::ERPInputmodel inputdata)
        {
            GE::EmailTemplate _list = new GE.EmailTemplate();
            try
            {


                var _data = ERPMASTERDatabase().EmailTemplateSettings.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.EmailTemplateName == inputdata.TranNo);

                if (_data != null)
                {
                    _list = (new GE.EmailTemplate
                    {
                        OrgId = _data.OrgId,
                        EmailTemplateNo = _data.EmailTemplateNo,
                        EmailTemplateName = _data.EmailTemplateName,
                        FromEmail = _data.FromEmail,
                        FromEmailPassword = _data.FromEmailPassword,
                        CCEmail = _data.CCEmail,
                        BCCEmail = _data.BCCEmail,
                        EmailSubject = _data.EmailSubject,
                        EmailBody = _data.EmailBody,
                        TranType = _data.TranType,
                        IsDefaultEmail = _data.IsDefaultEmail,
                        SMTP_Host = _data.SMTP_Host,
                        SMTP_Port = _data.SMTP_Port,
                        CreatedBy = _data.CreatedBy,
                        CreatedOn = _data.CreatedOn,
                        ChangedBy = _data.ChangedBy,
                        ChangedOn = _data.ChangedOn,
                    });

                }



            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCT, inputdata.OrganisationId);
            }
            return _list;
        }
        public bool SaveOTP(GE::RegisterOTP item, string Type)
        {
            string result = string.Empty;
            bool bUpdate = false;
            if (item != null)
            {
                try
                {

                    using (var context = new BOOKMERCHANT_DEVEntities())
                    {
                        using (var dbContextTransaction = context.Database.BeginTransaction())
                        {
                            var data = context.SaveRegisterOTP(item.OrgId, item.Name, item.OTP, item.EmailId, item.Expirted_Date, item.Created_Date, Type).FirstOrDefault();
                            if (data != null)
                            {
                                result = data.Result;
                            }
                            if (!string.IsNullOrEmpty(result))
                            {
                                context.SaveChanges();
                                bUpdate = true;
                                dbContextTransaction.Commit();
                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
            return bUpdate;
        }

        public string GetOTP(GE::RegisterOTP item, string Type)
        {
            string result = string.Empty;

            try
            {
                var data = ERPMASTERDatabase().RegisterOTPs.FirstOrDefault(o => o.OrgId == item.OrgId && o.EmailId == item.EmailId && o.OTP == item.OTP && o.Deleted == false && o.OTP_Type == Type);
                if (data != null)
                {
                    data.Deleted = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = "YES";
                }
                else
                    result = "Invalid OTP!";

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
