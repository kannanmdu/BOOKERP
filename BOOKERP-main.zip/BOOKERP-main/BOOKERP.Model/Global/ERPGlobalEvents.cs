﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BOOKERP.Model
{
   public static class ERPGlobalEvents
    {
        public static string ToERPdate(this DateTime date)
        {
            string returndate = string.Empty;
            if (date != null)
            {
                System.Globalization.CultureInfo ukCulture = new System.Globalization.CultureInfo("en-GB");
                Thread.CurrentThread.CurrentCulture = ukCulture;
                returndate = String.Format("{0:00}", date.Day) + "/" + String.Format("{0:00}", date.Month) + "/" + date.Year.ToString();

            }
            return returndate;

        }
        public static string ToERPdatetime(this DateTime date)
        {
            string returndate = string.Empty;
            if (date != null)
            {
                CultureInfo ukCulture = new System.Globalization.CultureInfo("en-GB");
                Thread.CurrentThread.CurrentCulture = ukCulture;
                returndate = String.Format("{0:00}", date.Hour) + ":" + String.Format("{0:00}", date.Minute);
            }
            return returndate;

        }
        public static DateTime? GetERPDateFormat(this string Datestring)
        {
            DateTime? CalculatedDate = null;
            try
            {
                if (!string.IsNullOrEmpty(Datestring))
                {
                    if (Datestring.Contains("/"))
                    {
                        string CalculatedDATE = string.Format("{0}/{1}/{2} {3}", Datestring.Split('/')[2], Datestring.Split('/')[1], Datestring.Split('/')[0], "00:00:00");
                        CalculatedDate = !string.IsNullOrEmpty(CalculatedDATE) ? Convert.ToDateTime(CalculatedDATE) : DateTime.Now;
                    }
                    if (Datestring.Contains("-"))
                    {
                        string CalculatedDATE = string.Format("{0}/{1}/{2} {3}", Datestring.Split('-')[2], Datestring.Split('-')[1], Datestring.Split('-')[0], "00:00:00");
                        CalculatedDate = !string.IsNullOrEmpty(CalculatedDATE) ? Convert.ToDateTime(CalculatedDATE) : DateTime.Now;
                    }
                }
                else
                    CalculatedDate = DateTime.Now.Date;

            }
            catch (Exception) { CalculatedDate = DateTime.Now.Date; }
            return CalculatedDate;
        }

        public static string ToERPDateQueryFormat(this string Value)
        {
            if (!string.IsNullOrEmpty(Value))
            {
                DateTime dt;
                string dtStr;

                CultureInfo ukCulture = new System.Globalization.CultureInfo("en-GB");
                Thread.CurrentThread.CurrentCulture = ukCulture;

                dt = DateTime.Parse(Value);
                dtStr = dt.Year.ToString() + String.Format("{0:00}", dt.Month) + String.Format("{0:00}", dt.Day);

                Value = "'" + dtStr + "'";
                return Value;
            }
            else
                return "''";

        }

        public static string ToERPString(this string Value)
        {
            if (!string.IsNullOrEmpty(Value))
            {
                Value = "'" + Value + "'";
                return Value;
            }
            else
                return "''";

        }
    }
}
