﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class DashboardDA : CommonDA
    {
        public List<GE::DashboardMaster> GetMasterInfo(int OrgId, string User)
        {
            List<GE::DashboardMaster> _data = new List<GE.DashboardMaster>();
            try
            {
                var _list = ERPMASTERDatabase().SP_GetdashboardCustomerProduct(OrgId).ToList();
                if (_list != null && _list.Count() > 0)
                {
                    _list.ForEach(item =>
                    {
                        _data.Add(new GE.DashboardMaster
                        {
                            ModuleName = item.ModuleName,
                            Code = item.Code,
                            Column3 = !string.IsNullOrEmpty(item.Column3) ? item.Column3 : string.Empty,
                            Column4 = !string.IsNullOrEmpty(item.Column4) ? item.Column4 : string.Empty,
                            Name = item.Name
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, User, DASHBOARD, OrgId);
            }
            return _data;
        }

        public List<GE::DashboardTransaction> GetTransactionInfo(int OrgId, string User)
        {
            List<GE::DashboardTransaction> _data = new List<GE.DashboardTransaction>();
            try
            {
                var _List = ERPMASTERDatabase().SP_GetdashboardTransaction(OrgId).ToList();
                if (_List != null && _List.Count > 0)
                {
                    _List.ForEach(item =>
                    {
                        _data.Add(new GE.DashboardTransaction
                        {
                            ModuleName = item.ModuleName,
                            TranNo = item.TranNo,
                            CustomerName = item.CustomerName,
                            NetTotal = item.NetTotal,
                            TranDate = item.TranDate,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, User, DASHBOARD, OrgId);
            }
            return _data;
        }
    }
}
