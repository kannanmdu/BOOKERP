﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Model
{
   public class ExceptionDA : CommonDA
    {
        public void Save(string Message, string user, string Module, int OrganizationId)
        {
            try
            {
            }
            catch (Exception)
            {

            }
        }

        internal void Save(string message, string loginUser, object mAGAZINES, int organisationId)
        {
            throw new NotImplementedException();
        }
    }
}
