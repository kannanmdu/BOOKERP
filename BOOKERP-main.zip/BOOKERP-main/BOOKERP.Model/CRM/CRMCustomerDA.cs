﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class CRMCustomerDA : CommonDA
    {
        // Get the customer details
        public List<GE::CRMCustomers> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::CRMCustomers> _list = new List<GE.CRMCustomers>();
            try
            {
                var _data = (from a in ERPMASTERDatabase().CRM_Customers.Where(o => o.IsActive == inputData.IsActive)
                             join b in ERPMASTERDatabase().Master_Countries
                             on a.CountryId equals b.CountryCode into co
                             from b in co.DefaultIfEmpty()
                             where a.OrgId == inputData.OrganisationId
                             orderby a.CreatedOn descending
                             select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.CRMCustomers
                        {
                            Code = item.a.Code,
                            
                            Name = item.a.Name,
                            EMail = item.a.EMail,
                            AddressLine1 = item.a.AddressLine1,
                            AddressLine2 = item.a.AddressLine2,
                            AddressLine3 = item.a.AddressLine3,
                            CountryId = item.a.CountryId,
                            PostalCode = item.a.PostalCode,
                            Mobile = item.a.Mobile,
                            Phone = item.a.Phone,
                            Fax = item.a.Fax,
                           
                            PaymentTerms = item.a.PaymentTerms,
                           
                            TaxTypeId = item.a.TaxTypeId,
                           
                            IsActive = item.a.IsActive,
                           
                            ChangedBy = item.a.ChangedBy,
                            ChangedOn = item.a.ChangedOn,
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            OrgId = item.a.OrgId,
                            CreatedFrom = item.a.CreatedFrom
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CRMCUSTOMER, 1);
            }
            return _list;
        }
        //Save and update the customer details
        public string Save(GE::CRMCustomers item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    if (string.IsNullOrEmpty(item.Code))
                    {
                        var autocode = GetMasterNextNo(organizationId, CRMCUSTOMER);
                        item.Code = autocode;
                    }
                    var _data = ERPMASTERDatabase().FN_CRM_CustomerSave(organizationId, item.Code, item.Name, item.EMail, item.AddressLine1, item.AddressLine2, item.AddressLine3, item.CountryId, item.PostalCode, item.Mobile, item.Phone, item.Fax, item.CurrencyId, item.TaxTypeId, item.PaymentTerms, item.CreatedFrom, item.IsActive, user).FirstOrDefault();                    

                    if (_data != null)
                    {
                        result = _data.Result;
                    }
                }               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CRMCUSTOMER, organizationId);
            }

            return result;
        }
        //Edit the customer details
        public GE::CRMCustomers GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::CRMCustomers _data = new GE.CRMCustomers();
            try
            {
                var item = ERPMASTERDatabase().CRM_Customers.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.CustomerCode);
                if (item != null)
                {
                    _data = (new GE.CRMCustomers
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,                        
                       
                        Name = item.Name,
                        EMail = item.EMail,
                        AddressLine1 = item.AddressLine1,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        Mobile = item.Mobile,
                        Phone = item.Phone,
                        Fax = item.Fax,
                        
                        CurrencyId = item.CurrencyId,
                        PaymentTerms = item.PaymentTerms,
                      
                        TaxTypeId = item.TaxTypeId,
                        IsActive = item.IsActive,
                      CreatedFrom=item.CreatedFrom,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CRMCUSTOMER, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the customer details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().CRM_Customers.FirstOrDefault(o => o.Code == inputdata.CustomerCode && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CRMCUSTOMER, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the customer details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().CRM_Customers.FirstOrDefault(o => o.Code == inputData.CustomerCode && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CRMCUSTOMER, inputData.OrganisationId);
            }
            return result;
        }
    }
}
