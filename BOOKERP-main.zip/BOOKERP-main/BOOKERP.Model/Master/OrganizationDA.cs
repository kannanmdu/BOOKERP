﻿using BOOKERP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class OrganizationDA : CommonDA
    {
        // Get the organization details
        public List<GE::Organization> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::Organization> _list = new List<GE.Organization>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetOrganizationDetails(inputData.OrganisationId, inputData.IsActive).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Organization
                        {
                            OrgId = item.OrgId,
                            OrgName = item.OrgName,
                            OrgLogo = item.OrgLogo,
                            //OrgLogoString = GetStringfrombyte(item.OrgLogo),
                            RegNo = item.RegNo,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            PostalCode = item.PostalCode,
                            PhoneNo = item.PhoneNo,
                            MobileNo = item.MobileNo,
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            Currency = item.Currency,
                            Website = item.Website,
                            OrgRefCode = item.OrgRefCode,
                            Fax = item.Fax,
                            Email = item.Email,
                            ContactNo = item.ContactNo,
                            ContactPerson = item.ContactPerson,
                            IsActive = item.IsActive,
                            TaxCode = item.TaxCode,
                            TaxPerc = item.TaxPerc,
                            TaxRegNo = item.TaxRegNo,
                            TaxType = item.TaxType,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, COMPANY, inputData.OrganisationId);
            }
            return _list;
        }
        public List<GE::Currency> GetAllCurrency(ERPInputmodel inputData)
        {
            List<GE::Currency> _list = new List<GE.Currency>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Currency.Where(o => o.IsActive == inputData.IsActive && o.OrgId == inputData.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Currency
                        {
                            OrgId = item.OrgId,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyDesc = item.CurrencyDesc,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BRANCH, inputData.OrganisationId);
            }
            return _list;
        }

        // Edit
        public GE::Organization GetbyCode(GE::ERPInputmodel inputData)
        {
            GE::Organization _data = new GE.Organization();
            try
            {
                var item = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.Organization
                    {
                        OrgId = item.OrgId,
                        OrgName = item.OrgName,
                        OrgLogo = item.OrgLogo,
                        OrgLogoString = GetStringfrombyte(item.OrgLogo),
                        RegNo = item.RegNo,
                        AddressLine1 = item.AddressLine1,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        PostalCode = item.PostalCode,
                        PhoneNo = item.PhoneNo,
                        MobileNo = item.MobileNo,
                        CountryCode = item.Country,
                        Currency = item.Currency,
                        Website = item.Website,
                        OrgRefCode = item.OrgRefCode,
                        Fax = item.Fax,
                        Email = item.Email,
                        ContactNo = item.ContactNo,
                        ContactPerson = item.ContactPerson,
                        IsActive = item.IsActive,
                        TaxCode = item.TaxCode,
                        TaxPerc = item.TaxPerc,
                        TaxRegNo = item.TaxRegNo,
                        TaxType = item.TaxType,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, COMPANY, inputData.OrganisationId);
            }
            return _data;
        }
        //Save and update
        public string Save(GE::Organization item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {

                    var _data = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == item.OrgId);
                    if (_data != null)
                    {
                        item.OrgId = _data.OrgId;
                        _data.OrgName = item.OrgName;
                        _data.OrgLogo = item.OrgLogo;
                        //_data.OrgLogoString = item.OrgLogoString;
                        _data.RegNo = item.RegNo;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.PostalCode = item.PostalCode;
                        _data.PhoneNo = item.PhoneNo;
                        _data.MobileNo = !string.IsNullOrEmpty(item.MobileNo) ? item.MobileNo : string.Empty;
                        _data.Country = item.CountryCode;
                        _data.Currency = item.Currency;
                        _data.Website = item.Website;
                        _data.OrgRefCode = item.OrgRefCode;
                        _data.Fax = item.Fax;
                        _data.Email = !string.IsNullOrEmpty(item.Email) ? item.Email : string.Empty;
                        _data.ContactNo = item.ContactNo;
                        _data.ContactPerson = item.ContactPerson;
                        _data.IsActive = item.IsActive;
                        _data.TaxCode = item.TaxCode;
                        _data.TaxPerc = item.TaxPerc;
                        _data.TaxRegNo = item.TaxRegNo;
                        _data.TaxType = item.TaxType;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {

                        Master_Organization _Organisations = new Master_Organization()
                        {
                            OrgId = GetMaxID(ORGANIZATION),
                            OrgName = item.OrgName,
                            OrgLogo = item.OrgLogo,
                            //OrgLogoString = item.OrgLogoString,
                            RegNo = item.RegNo,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            PostalCode = item.PostalCode,
                            PhoneNo = item.PhoneNo,
                            MobileNo = !string.IsNullOrEmpty(item.MobileNo) ? item.MobileNo : string.Empty,
                            Country = item.CountryCode,
                            Currency = item.Currency,
                            Website = item.Website,
                            OrgRefCode = item.OrgRefCode,
                            Fax = item.Fax,
                            Email = !string.IsNullOrEmpty(item.Email) ? item.Email : string.Empty,
                            ContactNo = item.ContactNo,
                            ContactPerson = item.ContactPerson,
                            IsActive = item.IsActive,
                            TaxCode = item.TaxCode,
                            TaxPerc = item.TaxPerc,
                            TaxRegNo = item.TaxRegNo,
                            TaxType = item.TaxType,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user

                        };
                        ERPMASTERDatabase().Master_Organization.Add(_Organisations);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }

                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.InnerException.Message, user, COMPANY, organizationId);
            }
            return result + "~" + item.OrgId;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, COMPANY, inputData.OrganisationId);
            }
            return result;
        }

        //Make Active
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, COMPANY, inputData.OrganisationId);
            }
            return result;
        }

        public string GetStringfrombyte(byte[] ImageArray)
        {
            string imgDataURL = string.Empty;
            if (ImageArray != null)
            {
                string imreBase64Data = Convert.ToBase64String(ImageArray);
                imgDataURL = string.Format("data:image/png;base64,{0}", imreBase64Data);
            }
            return imgDataURL;
        }

        public List<GE::ERPSetting> GetERPCommonSetting(GE::ERPInputmodel inputdata)
        {
            List<GE::ERPSetting> _data = new List<GE::ERPSetting>();
            try
            {

                string Query = string.Empty;
                Query = "select SettingId,SettingValue,SettingDescription from org.ERPSettings";

                Query += " Where OrgId = " + inputdata.TransNo.ToString().ToERPString();



                var item = ERPMASTERDatabase().Database.SqlQuery<GE::ERPSetting>(Query).ToList();

                //var item = ERPMASTERDatabase().ERPSettings.Where(o => o.OrgId == inputdata.TransNo).ToList();
                if (item != null)
                {

                    item.ForEach(i =>
                    {
                        GE::ERPSetting _datas = new GE.ERPSetting();
                        _datas = (new GE.ERPSetting
                        {
                            SettingId = i.SettingId,
                            SettingValue = i.SettingValue,
                            SettingDescription = i.SettingDescription
                        });

                        _data.Add(_datas);
                    });

                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, COMPANY, inputdata.OrganisationId);
            }
            return _data;
        }
        public List<GE::Organization> GetListbyCode(int OrganizationId, string user)
        {
            List<GE::Organization> _list = new List<GE.Organization>();
            try
            {
                var _data = (from a in ERPMASTERDatabase().Master_Organization.Where(o => o.OrgId == OrganizationId)
                             join b in ERPMASTERDatabase().Master_Countries
                             on a.Country equals b.CountryCode
                             orderby a.CreatedOn descending
                             select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Organization
                        {
                            // OrganisationId = item.a.OrganisationId,
                            OrgId = item.a.OrgId,
                            OrgName = item.a.OrgName,
                            OrgLogo = item.a.OrgLogo,
                            //OrgLogoString = GetStringfrombyte(item.OrgLogo),
                            RegNo = item.a.RegNo,
                            AddressLine1 = item.a.AddressLine1,
                            AddressLine2 = item.a.AddressLine2,
                            AddressLine3 = item.a.AddressLine3,
                            PostalCode = item.a.PostalCode,
                            PhoneNo = item.a.PhoneNo,
                            MobileNo = item.a.MobileNo,
                            //CountryCode = item.a.CountryCode,
                            //CountryName = item.a.CountryName,
                            Currency = item.a.Currency,
                            Website = item.a.Website,
                            OrgRefCode = item.a.OrgRefCode,
                            Fax = item.a.Fax,
                            Email = item.a.Email,
                            ContactNo = item.a.ContactNo,
                            ContactPerson = item.a.ContactPerson,
                            IsActive = item.a.IsActive,
                            TaxCode = item.a.TaxCode,
                            TaxPerc = item.a.TaxPerc,
                            TaxRegNo = item.a.TaxRegNo,
                            TaxType = item.a.TaxType,
                            ChangedOn = item.a.ChangedOn,
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            ChangedBy = item.a.ChangedBy
                            //TaxRegNo = item.a.TaxRegNo != null ? item.a.TaxRegNo : ""
                        }); ;
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, COMPANY, OrganizationId);
            }
            return _list;
        }

        public string ImageSave(GE::Organization item, string user, int OrganizationId)
        {
            string result = string.Empty;
            int orgid = Convert.ToInt32(item.OrgId);
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == item.OrgId);
                    if (_data != null)
                    {
                        _data.OrgLogo = item.OrgLogo;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, COMPANY, OrganizationId);
            }
            return result;
        }

        #region SHOPEE

        public string SaveShopee(GE::MasterShopee item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Shopee.FirstOrDefault(o => o.OrgId == item.OrgId && o.ShopeeCode == item.ShopeeCode);
                    if (_data != null)
                    {
                        _data.ShopName = item.ShopName;
                        _data.Host = item.Host;
                        _data.Path = item.Path;
                        _data.RedirectUrl = item.RedirectUrl;
                        _data.PartnerId = item.PartnerId;
                        _data.TempPartnerKey = item.TempPartnerKey;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.ShopeeCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, SHOPEE);
                            item.ShopeeCode = autoCode;
                        }
                        Master_Shopee _Shopee = new Master_Shopee()
                        {
                            OrgId = item.OrgId,//GetMaxID(SHOPEE),
                            ShopeeCode = item.ShopeeCode,
                            ShopName = item.ShopName,
                            Host = item.Host,
                            Path = item.Path,
                            RedirectUrl = item.RedirectUrl,
                            PartnerId = item.PartnerId,
                            TempPartnerKey = item.TempPartnerKey,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Shopee.Add(_Shopee);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.InnerException.Message, user, SHOPEE, organizationId);
            }
            return result + "~" + item.OrgId;
        }

        public GE::MasterShopee GetByCodeShopee(GE::ERPInputmodel inputData)
        {
            GE::MasterShopee _data = new GE.MasterShopee();
            try
            {
                var item = ERPMASTERDatabase().Master_Shopee.FirstOrDefault(o => o.OrgId == inputData.OrganisationId && o.ShopeeCode == inputData.ShopeeCode);
                if (item != null)
                {
                    _data = (new GE.MasterShopee
                    {
                        OrgId = item.OrgId,
                        ShopeeCode = item.ShopeeCode,
                        ShopName = item.ShopName,
                        Host = item.Host,
                        Path = item.Path,
                        RedirectUrl = item.RedirectUrl,
                        PartnerId = item.PartnerId,
                        TempPartnerKey = item.TempPartnerKey,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, SHOPEE, inputData.OrganisationId);
            }
            return _data;
        }

        public List<GE::MasterShopee> GetAllShopee(GE::ERPInputmodel inputData)
        {
            List<GE::MasterShopee> _data = new List<GE.MasterShopee>();
            try
            {
                var data = ERPMASTERDatabase().Master_Shopee.Where(o => o.OrgId == inputData.OrganisationId).ToList();
                if (data != null && data.Count>0)
                {
                    data.ForEach(item =>
                    {
                        _data.Add(new GE.MasterShopee
                        {
                            OrgId = item.OrgId,
                            ShopeeCode = item.ShopeeCode,
                            ShopName = item.ShopName,
                            Host = item.Host,
                            Path = item.Path,
                            RedirectUrl = item.RedirectUrl,
                            PartnerId = item.PartnerId,
                            TempPartnerKey = item.TempPartnerKey,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, SHOPEE, inputData.OrganisationId);
            }
            return _data;
        }

        #endregion

        #region LAZASA

        public string SaveLazada(GE::MasterLazada item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Lazada.FirstOrDefault(o => o.OrgId == item.OrgId && o.LazadaCode == item.LazadaCode);
                    if (_data != null)
                    {
                        _data.ShopName = item.ShopName;
                        _data.Host = item.Host;
                        _data.AppSecret = item.AppSecret;
                        _data.AppKey = item.AppKey;
                        _data.CountryCode = item.CountryCode;
                        _data.LazadaCode = item.LazadaCode;
                        _data.OAuthCode = string.Empty;
                        _data.OAuthTimeStamp = DateTime.Now;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        _data.IsActive = true;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.LazadaCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, SHOPEE);
                            item.LazadaCode = autoCode;
                        }
                        Master_Lazada _Lazada = new Master_Lazada()
                        {
                            OrgId = item.OrgId,
                            LazadaCode = item.LazadaCode,
                            ShopName = item.ShopName,
                            Host = item.Host,
                            AppKey = item.AppKey,
                            AppSecret = item.AppSecret,
                            CountryCode = item.CountryCode,
                            OAuthCode = string.Empty,
                            OAuthTimeStamp = DateTime.Now,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                            IsActive = true,
                        };
                        ERPMASTERDatabase().Master_Lazada.Add(_Lazada);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.InnerException.Message, user, LAZADA, organizationId);
            }
            return result + "~" + item.OrgId;
        }

        public GE::MasterLazada GetByCodeLazada(GE::ERPInputmodel inputData)
        {
            GE::MasterLazada _data = new GE.MasterLazada();
            try
            {
                var item = ERPMASTERDatabase().Master_Lazada.FirstOrDefault(o => o.OrgId == inputData.OrganisationId && o.LazadaCode == inputData.LazadaCode && o.IsActive == true);
                if (item != null)
                {
                    _data = (new GE.MasterLazada
                    {
                        OrgId = item.OrgId,
                        LazadaCode = inputData.LazadaCode,
                        ShopName = item.ShopName,
                        Host = item.Host,
                        AppKey = item.AppKey,
                        AppSecret = item.AppSecret,
                        CountryCode = item.CountryCode,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, LAZADA, inputData.OrganisationId);
            }
            return _data;
        }

        public List<GE::MasterLazada> GetAllLazada(GE::ERPInputmodel inputData)
        {
            List<GE::MasterLazada> _data = new List<GE.MasterLazada>();
            try
            {
                var data = ERPMASTERDatabase().Master_Lazada.Where(o => o.OrgId == inputData.OrganisationId && o.IsActive == true).ToList();
                if (data != null && data.Count > 0)
                {
                    data.ForEach(item =>
                    {
                        _data.Add(new GE.MasterLazada
                        {
                            OrgId = item.OrgId,
                            LazadaCode = item.LazadaCode,
                            ShopName = item.ShopName,
                            Host = item.Host,
                            AppKey = item.AppKey,
                            AppSecret = item.AppSecret,
                            CountryCode = item.CountryCode,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            IsActive = item.IsActive,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, SHOPEE, inputData.OrganisationId);
            }
            return _data;
        }

        public bool DeleteByCodeLazada(GE::ERPInputmodel inputData)
        {
            bool result = false;
            try
            {
                var item = ERPMASTERDatabase().Master_Lazada.FirstOrDefault(o => o.OrgId == inputData.OrganisationId  && o.LazadaCode == inputData.LazadaCode && o.IsActive == true);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputData.LoginUser, COMPANY, inputData.OrganisationId);
            }
            return result;
        }

        #endregion
    }
}
