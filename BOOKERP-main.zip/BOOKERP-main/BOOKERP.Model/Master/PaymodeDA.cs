﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class PaymodeDA : CommonDA
    {
        // Get All
        public List<GE::Paymode> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Paymode> _list = new List<GE.Paymode>();
            try
            {
                var _data = ERPMASTERDatabase().Master_PayModes.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Paymode
                        {
                            OrgId = item.OrgId,
                            Code = item.Code,
                            Name = item.Name,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PAYMODE, inputdata.OrganisationId);
            }
            
            return _list;
        }

        // save and update the paymode details
        public string Save(GE::Paymode item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_PayModes.FirstOrDefault(o => o.Code == item.Code && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.Code = item.Code;
                        _data.Name = item.Name;
                        _data.IsActive = item.IsActive;
                        _data.DisplayOrder = item.DisplayOrder;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.Code))
                        {
                            var autoCode = GetMasterNextNo(organizationId, PAYMODE);
                            item.Code = autoCode;
                        }
                        Master_PayModes payMode = new Master_PayModes()
                        {
                            OrgId = organizationId,
                            Code = item.Code,
                            Name = item.Name,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_PayModes.Add(payMode);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, PAYMODE, organizationId);
            }

            return result;
        }
        //Edit the paymode details
        public GE::Paymode GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Paymode _data = new GE.Paymode();
            try
            {
                var item = ERPMASTERDatabase().Master_PayModes.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Paymode
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,                        
                        Name = item.Name,
                        DisplayOrder = item.DisplayOrder,
                        IsActive = item.IsActive,                        
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PAYMODE, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the paymode details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_PayModes.FirstOrDefault(o => o.Code == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PAYMODE, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the paymode details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_PayModes.FirstOrDefault(o => o.Code == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, PAYMODE, inputData.OrganisationId);
            }
            return result;
        }
    }
}
