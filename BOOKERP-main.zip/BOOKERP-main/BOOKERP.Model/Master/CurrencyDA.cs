﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class CurrencyDA : CommonDA
    {
        // Get All
        public List<GE::Currency> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Currency> _list = new List<GE.Currency>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Currency.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Currency
                        {
                            OrgId = item.OrgId,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyDesc = item.CurrencyDesc,
                            CurrencyValue = item.CurrencyValue,
                            CurrencyRate = item.CurrencyRate,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            IsDefault = item.IsDefault,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CURRENCY, inputdata.OrganisationId);
            }
            
            return _list;
        }

        // save and update the currency details
        public string Save(GE::Currency item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.CurrencyCode == item.CurrencyCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.CurrencyCode = item.CurrencyCode;
                        _data.CurrencyDesc = item.CurrencyDesc;
                        _data.CurrencyValue = item.CurrencyValue;
                        _data.CurrencyRate = item.CurrencyRate;
                        _data.IsActive = item.IsActive;
                        _data.DisplayOrder = item.DisplayOrder;
                        _data.IsDefault = item.IsDefault;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.CurrencyCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, CURRENCY);
                            item.CurrencyCode = autoCode;
                        }
                        Master_Currency currency = new Master_Currency()
                        {
                            OrgId = organizationId,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyDesc = item.CurrencyDesc,
                            CurrencyValue = item.CurrencyValue,
                            CurrencyRate = item.CurrencyRate,
                            DisplayOrder = item.DisplayOrder,
                            IsDefault = item.IsDefault,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_Currency.Add(currency);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CURRENCY, organizationId);
            }

            return result;
        }
        //Edit the currency details
        public GE::Currency GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Currency _data = new GE.Currency();
            try
            {
                var item = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.CurrencyCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Currency
                    {
                        OrgId = item.OrgId,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyDesc = item.CurrencyDesc,  
                        CurrencyValue = item.CurrencyValue,
                        CurrencyRate = item.CurrencyRate,
                        DisplayOrder = item.DisplayOrder,
                        IsDefault = item.IsDefault,
                        IsActive = item.IsActive,                        
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CURRENCY, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the currency details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.CurrencyCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CURRENCY, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the currency details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Currency.FirstOrDefault(o => o.CurrencyCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CURRENCY, inputData.OrganisationId);
            }
            return result;
        }
    }
}
