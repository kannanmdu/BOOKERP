﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class UserGroupDA : CommonDA
    {
        // Get the user group details
        public List<GE::UserGroup> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::UserGroup> _list = new List<GE.UserGroup>();
            try
            {
                var _data = ERPMASTERDatabase().Security_UserRole.Where(x=>x.IsActive == inputData.IsActive && x.OrgId == inputData.OrganisationId).ToList();
               
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.UserGroup
                        {
                            OrgId = item.OrgId,
                            UserRoleCode = item.UserRoleCode,
                            UserRoleName = item.UserRoleName,                       
                            IsActive = item.IsActive,                           
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USERGROUP, inputData.OrganisationId);
            }
            return _list;
        }
        //Save and update the user group details
        public string Save(GE::UserGroup item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Security_UserRole.FirstOrDefault(o => o.UserRoleCode == item.UserRoleCode && o.OrgId == organizationId);
                    if (_data != null)
                    {                        
                        _data.UserRoleCode = item.UserRoleCode;
                        _data.UserRoleName = item.UserRoleName;
                        _data.IsActive = item.IsActive;                     
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.UserRoleCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, USERGROUP);
                            item.UserRoleCode = autoCode;
                        }
                        Security_UserRole userRole = new Security_UserRole()
                        {
                            OrgId = organizationId,
                            UserRoleCode = item.UserRoleCode,
                            UserRoleName = item.UserRoleName,                          
                            IsActive = item.IsActive,                         
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Security_UserRole.Add(userRole);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, USERGROUP, organizationId);
            }

            return result;
        }
        //Edit the user group details
        public GE::UserGroup GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::UserGroup _data = new GE.UserGroup();
            try
            {
                var item = ERPMASTERDatabase().Security_UserRole.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.UserRoleCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.UserGroup
                    {
                        OrgId = item.OrgId,
                        UserRoleCode = item.UserRoleCode,
                        UserRoleName = item.UserRoleName,                                            
                        IsActive = item.IsActive,                    
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, USERGROUP, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the user group details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Security_UserRole.FirstOrDefault(o => o.UserRoleCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, USERGROUP, inputdata.OrganisationId);
            }
            return result;
        }
       
        //To active the user group details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Security_UserRole.FirstOrDefault(o => o.UserRoleCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USERGROUP, inputData.OrganisationId);
            }
            return result;
        }
    }
}
