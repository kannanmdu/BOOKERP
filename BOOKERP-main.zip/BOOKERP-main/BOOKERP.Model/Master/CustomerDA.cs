﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class CustomerDA : CommonDA
    {
        // Get the customer details
        public List<GE::Customer> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::Customer> _list = new List<GE.Customer>();
            try
            {
                // var _data = ERPMASTERDatabase().Master_Customers.Where(o => o.IsActive == true && o.OrgId==inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                var _data = (from a in ERPMASTERDatabase().Master_Customers.Where(o => o.IsActive == inputData.IsActive)
                             join b in ERPMASTERDatabase().Master_Countries
                             on a.CountryId equals b.CountryCode into co
                             from b in co.DefaultIfEmpty()
                             where a.OrgId == inputData.OrganisationId
                             orderby a.CreatedOn descending
                             select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Customer
                        {
                            Code = item.a.Code,
                            UniqueNo = item.a.UniqueNo,
                            Activity1 = item.a.Activity1,
                            Activity2 = item.a.Activity2,
                            Name = item.a.Name,
                            EMail = item.a.EMail,
                            AddressLine1 = item.a.AddressLine1,
                            AddressLine2 = item.a.AddressLine2,
                            AddressLine3 = item.a.AddressLine3,
                            CountryId = item.a.CountryId,
                            PostalCode = item.a.PostalCode,
                            Mobile = item.a.Mobile,
                            Phone = item.a.Phone,
                            Fax = item.a.Fax,
                            DirectorName = item.a.DirectorName,
                            DirectorPhone = item.a.DirectorPhone,
                            DirectorMobile = item.a.DirectorMobile,
                            DirectorMail = item.a.DirectorMail,
                            SalesPerson = item.a.SalesPerson,
                            PaymentTerms = item.a.PaymentTerms,
                            CustomerGroup = item.a.CustomerGroup,
                            Source = item.a.Source,
                            TaxTypeId = item.a.TaxTypeId,
                            AccountNo = item.a.AccountNo,
                            IsActive = item.a.IsActive,
                            IsOutStanding = item.a.IsOutStanding,
                            ChangedBy = item.a.ChangedBy,
                            ChangedOn = item.a.ChangedOn,
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            OrgId = item.a.OrgId,
                            CreditLimit = item.a.CreditLimit,
                            PriceSettings = item.a.PriceSettings,
                            CountryName = item.b != null ? item.b.CountryName : string.Empty,
                            Remarks = item.a.Remarks,
                            CustomerType = item.a.CustomerType,
                            ContactType = item.a.ContactType,
                            CRMCustomerCode = item.a.CRMCustomerCode
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CUSTOMER, 1);
            }
            return _list;
        }
        //Save and update the customer details
        public string Save(GE::Customer item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    if (string.IsNullOrEmpty(item.Code))
                    {
                        var autocode = GetMasterNextNo(organizationId, CUSTOMER);
                        item.Code = autocode;
                        var autocode1 = GetMasterNextNo(organizationId, CRMCUSTOMER);
                        item.CRMCustomerCode = autocode1;
                    }
                    var _data = ERPMASTERDatabase().Fn_Master_CustomerSave(organizationId, item.Code, item.Name, item.CustomerGroup, item.UniqueNo, item.EMail, item.AddressLine1, item.AddressLine2, item.AddressLine3, item.CountryId, item.PostalCode, item.Mobile, item.Phone, item.Fax, item.CurrencyId, item.TaxTypeId, item.DirectorName, item.DirectorPhone, item.DirectorMobile, item.DirectorMail, item.SalesPerson, item.PaymentTerms, item.Source, item.IsActive, item.Activity1, item.Activity2, item.ContactPerson, item.PriceSettings, Convert.ToDecimal(item.CreditLimit), item.AccountNo, item.IsOutStanding, item.Remarks, item.CustomerType, item.Password, item.ContactType,item.CRMCustomerCode, user).FirstOrDefault();                    

                    if (_data != null)
                    {
                        result = _data.Result;
                    }


                    var _data1 = ERPMASTERDatabase().FN_CRM_CustomerSave(organizationId, item.CRMCustomerCode, item.Name, item.EMail, item.AddressLine1, item.AddressLine2, item.AddressLine3, item.CountryId, item.PostalCode, item.Mobile, item.Phone, item.Fax, item.CurrencyId, item.TaxTypeId, item.PaymentTerms, "C", item.IsActive, user).FirstOrDefault();
                    
                }               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CUSTOMER, organizationId);
            }

            return result + "~"+ item.Code;
        }
        //Edit the customer details
        public GE::Customer GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Customer _data = new GE.Customer();
            try
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.CustomerCode);
                if (item != null)
                {
                    _data = (new GE.Customer
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,                        
                        UniqueNo = item.UniqueNo,
                        Activity1 = item.Activity1,
                        Activity2 = item.Activity2,
                        Name = item.Name,
                        EMail = item.EMail,
                        AddressLine1 = item.AddressLine1,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        Mobile = item.Mobile,
                        Phone = item.Phone,
                        Fax = item.Fax,
                        DirectorName = item.DirectorName,
                        DirectorPhone = item.DirectorPhone,
                        DirectorMobile = item.DirectorMobile,
                        DirectorMail = item.DirectorMail,
                        SalesPerson = item.SalesPerson,
                        CurrencyId = item.CurrencyId,
                        PaymentTerms = item.PaymentTerms,
                        CustomerGroup = item.CustomerGroup,
                        Source = item.Source,
                        TaxTypeId = item.TaxTypeId,
                        IsActive = item.IsActive,
                        IsOutStanding = item.IsOutStanding,     
                        ContactPerson = item.ContactPerson,
                        CreditLimit = item.CreditLimit,
                        PriceSettings = item.PriceSettings,
                        AccountNo = item.AccountNo,                                 
                        Remarks = item.Remarks,
                        CustomerType = item.CustomerType,
                        Password = item.Password,
                        ContactType = item.ContactType,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        CRMCustomerCode = item.CRMCustomerCode
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CUSTOMER, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the customer details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.Code == inputdata.CustomerCode && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CUSTOMER, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the customer details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Customers.FirstOrDefault(o => o.Code == inputData.CustomerCode && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CUSTOMER, inputData.OrganisationId);
            }
            return result;
        }
    }
}
