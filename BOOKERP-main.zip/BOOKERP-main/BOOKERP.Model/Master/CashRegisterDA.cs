﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using System.Data.Entity.Validation;

namespace BOOKERP.Model
{
   public class CashRegisterDA : CommonDA
    {
        // Get All
        public List<GE::CashRegister> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::CashRegister> _list = new List<GE.CashRegister>();
            try
            {
                var _data = ERPMASTERDatabase().POSCashRegisters.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.CashRegister
                        {
                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            CashRegisterCode = item.CashRegisterCode,
                            TerminalName = item.TerminalName,
                            DepositAmount = item.DepositAmount,
                            CashierName = item.CashierName,
                            IsActive = item.IsActive,
                            CreatedOn = item.CreatedOn,
                            CreatedBy = item.CreatedBy,
                            ChangedOn = item.ChangedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                            CreatedOnString = (item.CreatedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                            OBstatus = item.OBstatus
                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHREGISTER, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::CashRegister GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::CashRegister _data = new GE.CashRegister();
            try
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.CashRegisterCode == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.CashRegister
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        CashRegisterCode = item.CashRegisterCode,
                        TerminalName = item.TerminalName,
                        DepositAmount = item.DepositAmount,
                        CashierName = item.CashierName,
                        IsActive = item.IsActive,
                        CreatedOn = item.CreatedOn,
                        CreatedBy = item.CreatedBy,
                        ChangedOn = item.ChangedOn,
                        ChangedBy = item.ChangedBy,
                        OBstatus = item.OBstatus
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHREGISTER, inputdata.OrganisationId);
            }
            return _data;
        }

        public GE::CashRegister GetMachineNameByName(GE::ERPInputmodel inputdata)
        {
            GE::CashRegister _data = new GE.CashRegister();
            try
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.IsActive==true &&  o.TerminalName == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.CashRegister
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        CashRegisterCode = item.CashRegisterCode,
                        TerminalName = item.TerminalName,
                        DepositAmount = item.DepositAmount,
                        CashierName = item.CashierName,
                        IsActive = item.IsActive,
                        CreatedOn = item.CreatedOn,
                        CreatedBy = item.CreatedBy,
                        ChangedOn = item.ChangedOn,
                        ChangedBy = item.ChangedBy,
                        OBstatus = item.OBstatus
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHREGISTER, inputdata.OrganisationId);
            }
            return _data;
        }

        // Create or Update
        public string Save(GE::CashRegister item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {               
                if (string.IsNullOrEmpty(item.CashRegisterCode))
                {                           
                    var autocode = GetMasterNextNo(OrganizationId, CASHREGISTER);
                    item.CashRegisterCode = autocode;
                }
                POSCashRegister bank = new POSCashRegister()
                {
                    OrgId = OrganizationId,
                    BranchCode = item.BranchCode,
                    CashRegisterCode = item.CashRegisterCode,
                    TerminalName = item.TerminalName,
                    DepositAmount = 0,
                    CashierName = string.Empty,
                    IsActive = item.IsActive,
                    CreatedOn = DateTime.Now,
                    CreatedBy = user,
                    ChangedOn = DateTime.Now,
                    ChangedBy = user,
                    OBstatus = false
                };
                ERPMASTERDatabase().POSCashRegisters.Add(bank);
                ERPMASTERDatabase().SaveChanges();
                result = PASS;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CASHREGISTER, OrganizationId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.CashRegisterCode == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHREGISTER, inputdata.OrganisationId);
            }
            return result;
        }
        //Make Active
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.CashRegisterCode == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHREGISTER, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
