﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class UserPermissionDA : CommonDA
    {
        // Get the user permission details
        public List<GE::UserPermission> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::UserPermission> _list = new List<GE.UserPermission>();
            try
            {
                var _data = ERPMASTERDatabase().Security_UserRolePermission.Where(x=>x.IsActive == inputData.IsActive && x.OrgId == inputData.OrganisationId).ToList();
               
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.UserPermission
                        {
                            OrgId = item.OrgId,
                            UserRoleCode = item.UserRoleCode,
                            UserRolePermissionId = Convert.ToInt32(item.UserRolePermissionId),
                            MenuId = item.MenuId,
                            SubMenuId = item.SubMenuId,
                            IsAdd = item.IsAdd,
                            IsEdit = item.IsEdit,
                            IsDelete = item.IsDelete,
                            IsConvert = item.IsConvert,
                            IsFullAccess = item.IsFullAccess,
                            IsView = item.IsView,
                            IsActive = item.IsActive,                           
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USERPERMISSION, inputData.OrganisationId);
            }
            return _list;
        }     
        //Save and update the user permission details
        public string Save(List<GE::UserPermission> details, string user, int organisationId)
        {

            string result = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (details != null && details.Count > 0)
                        {
                            RemovePermission(details[0].UserRoleCode, user, organisationId, context);
                            details.ForEach(_details =>
                            {
                                SavePermission(_details, user, organisationId, context);
                                listcount++;
                            });
                            if (listcount == details.Count)
                            {
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                                result = PASS;
                            }
                            else
                                dbContextTransaction.Rollback();

                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, USERPERMISSION, organisationId);
            }
            return result;

        }
        public string SavePermission(GE::UserPermission item, string user, int organizationId, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    if (item.UserRolePermissionId == 0)
                    {
                        var autoCode = GetMasterNextNo(organizationId, USERPERMISSION);
                        item.UserRolePermissionId = Convert.ToInt32(autoCode);
                    }
                    Security_UserRolePermission _data = new Security_UserRolePermission();
                    _data.OrgId = organizationId;
                    _data.UserRolePermissionId = item.UserRolePermissionId;
                    _data.UserRoleCode = item.UserRoleCode;
                    _data.MenuId = item.MenuId;
                    _data.SubMenuId = item.SubMenuId;
                    _data.IsFullAccess = item.IsFullAccess;
                    _data.IsView = item.IsView;
                    _data.IsAdd = item.IsAdd;
                    _data.IsEdit = item.IsEdit;
                    _data.IsDelete = item.IsDelete;
                    _data.IsConvert = item.IsConvert;
                    _data.IsActive = item.IsActive;
                    _data.CreatedOn = DateTime.Now;
                    _data.CreatedBy = user;
                    _data.ChangedOn = DateTime.Now;
                    _data.ChangedBy = user;
                    dBEntities.Security_UserRolePermission.Add(_data);
                    dBEntities.SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, USERPERMISSION, organizationId);
            }
            return result;
        }
        //Edit the user permission details
        public List<GE::UserPermission> GetbyCode(GE::ERPInputmodel inputdata)
        {
            List<GE::UserPermission> _list = new List<GE.UserPermission>();
            var dBEntities = new BOOKMERCHANT_DEVEntities();
            try
            {
                var _data = dBEntities.Sp_GetUserRolePermission(inputdata.OrganisationId, inputdata.TranNo).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.UserPermission
                        {
                            OrgId = item.OrgId,
                            UserRoleCode = item.UserRoleCode,
                            UserRolePermissionId = Convert.ToInt32(item.UserRolePermissionId),
                            SubMenuName = item.SubMenuName,
                            MenuName = item.MenuName,
                            MenuId = item.MenuId,
                            SubMenuId = item.SubMenuId,
                            IsFullAccess = item.IsFullAccess,
                            IsView = item.IsView,
                            IsAdd = item.IsAdd,
                            IsEdit = item.IsEdit,
                            IsDelete = item.IsDelete,
                            IsConvert = item.IsConvert
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, USERPERMISSION, inputdata.OrganisationId);
            }
            return _list;

        }
        //Delete the user permission details
        public string RemovePermission(string userRoleCode, string user, int organizationId, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var item = dBEntities.Security_UserRolePermission.Where(o => o.UserRoleCode == userRoleCode && o.OrgId == organizationId).ToList();
                if (item != null && item.Count() > 0)
                {
                    item.ForEach(data =>
                    {
                        dBEntities.Security_UserRolePermission.Remove(data);
                        dBEntities.SaveChanges();
                    });
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, USERPERMISSION, organizationId);
            }
            return result;
        }
    }
}
