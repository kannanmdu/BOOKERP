﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class TaxDA : CommonDA
    {
        // Get All
        public List<GE::Tax> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Tax> _list = new List<GE.Tax>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Tax.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Tax
                        {
                            TaxCode = item.TaxCode,
                            TaxType = item.TaxType,
                            TaxPerc = item.TaxPerc,
                            TaxName = item.TaxName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAX, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::Tax item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Tax.FirstOrDefault(o => o.TaxCode == item.TaxCode && o.OrgId == organizationId);
                    if (_data != null)
                    {                       
                        _data.TaxCode = item.TaxCode;
                        _data.TaxPerc = item.TaxPerc;
                        _data.TaxType = item.TaxType;
                        _data.TaxName = item.TaxName;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (item.TaxCode == 0)
                        {
                            var autoCode = GetMasterNextNo(organizationId, TAX);
                            item.TaxCode = Convert.ToInt32(autoCode);
                        }
                        Master_Tax tax = new Master_Tax()
                        {
                            OrgId = organizationId,
                            TaxCode = item.TaxCode,
                            TaxType = item.TaxType,
                            TaxName = item.TaxName,
                            TaxPerc = item.TaxPerc,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Tax.Add(tax);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, TAX, organizationId);
            }

            return result;
        }

        //Edit the tax details
        public GE::Tax GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Tax _data = new GE.Tax();
            try
            {
                inputdata.TransNo = Convert.ToInt32(inputdata.TranNo);
                var item = ERPMASTERDatabase().Master_Tax.FirstOrDefault(o => o.TaxCode == inputdata.TransNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.Tax
                    {
                        OrgId = item.OrgId,
                        TaxCode = item.TaxCode,
                        TaxPerc = item.TaxPerc,
                        TaxType = item.TaxType.Trim(),
                        TaxName = item.TaxName,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAX, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the tax details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Tax.FirstOrDefault(o => o.TaxCode == inputdata.TransNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAX, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the tax details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Tax.FirstOrDefault(o => o.TaxCode == inputData.TransNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, TAX, inputData.OrganisationId);
            }
            return result;
        }
    }
}
