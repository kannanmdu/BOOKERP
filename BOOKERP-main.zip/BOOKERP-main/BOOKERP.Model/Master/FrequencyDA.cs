﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class FrequencyDA : CommonDA
    {
        // Get All
        public List<GE::Frequency> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Frequency> _list = new List<GE.Frequency>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Frequency.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Frequency
                        {
                            OrgId = item.OrgId,
                            FrequencyCode = item.FrequencyCode,
                            FrequencyName = item.FrequencyName,
                            FrequencyValue = item.FrequencyValue != null ? item.FrequencyValue : 0,                          
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, FREQUENCY, inputdata.OrganisationId);
            }
            
            return _list;
        }

        // save and update 
        public string Save(GE::Frequency item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.FrequencyCode == item.FrequencyCode && o.OrgId == organizationId);
                    if (_data != null)
                    {                        
                        _data.FrequencyCode = item.FrequencyCode;
                        _data.FrequencyName = item.FrequencyName;
                        _data.FrequencyValue = item.FrequencyValue;
                        _data.IsActive = item.IsActive;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.FrequencyCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, FREQUENCY);
                            item.FrequencyCode = autoCode;
                        }
                        Master_Frequency frequency = new Master_Frequency()
                        {
                            OrgId = organizationId,
                            FrequencyCode = item.FrequencyCode,
                            FrequencyName = item.FrequencyName,
                            FrequencyValue = item.FrequencyValue,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_Frequency.Add(frequency);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, FREQUENCY, organizationId);
            }

            return result;
        }
        //Edit the gift Frequency details
        public GE::Frequency GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Frequency _data = new GE.Frequency();
            try
            {
                var item = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.FrequencyCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Frequency
                    {
                        OrgId = item.OrgId,
                        FrequencyCode = item.FrequencyCode,
                        FrequencyName = item.FrequencyName,
                        FrequencyValue = item.FrequencyValue != null ? item.FrequencyValue : 0,
                        IsActive = item.IsActive,                        
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, FREQUENCY, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the frequency details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.FrequencyCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, FREQUENCY, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the frequency details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Frequency.FirstOrDefault(o => o.FrequencyCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, FREQUENCY, inputData.OrganisationId);
            }
            return result;
        }
    }
}
