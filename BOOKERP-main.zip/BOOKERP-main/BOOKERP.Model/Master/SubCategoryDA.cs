﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class SubCategoryDA : CommonDA
    {
        // Get All
        public List<GE::SubCategory> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::SubCategory> _list = new List<GE.SubCategory>();
            try
            {
                //var _data = ERPMASTERDatabase().Master_SubCategory.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();

                var _data = (from a in ERPMASTERDatabase().Master_SubCategory.Where(o => o.IsActive == inputdata.IsActive)
                             join b in ERPMASTERDatabase().Master_Category
                             on a.CategoryCode equals b.Code into co
                             from b in co.DefaultIfEmpty()
                             where a.OrgId == inputdata.OrganisationId
                             orderby a.CreatedOn descending
                             select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.SubCategory
                        {
                            OrgId = item.a.OrgId,
                            Code = item.a.Code,
                            Name = item.a.Name,
                            CategoryCode = item.a.CategoryCode,
                            DisplayOrder = item.a.DisplayOrder,
                            IsActive = item.a.IsActive,
                            CategoryName = item.b != null ? item.b.Name : string.Empty,
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            ChangedBy = item.a.ChangedBy,
                            ChangedOn = item.a.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBCATEGORY, inputdata.OrganisationId);
            }

            return _list;
        }

        // save and update the currency details
        public string Save(GE::SubCategory item, List<GE::SubCategoryTag> Tags, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_SubCategory.FirstOrDefault(o => o.Code == item.Code && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.Code = item.Code;
                        _data.Name = item.Name;
                        _data.CategoryCode = item.CategoryCode;
                        _data.DisplayOrder = item.DisplayOrder;
                        _data.IsActive = item.IsActive;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.Code))
                        {
                            var autoCode = GetMasterNextNo(organizationId, CATEGORY);
                            item.Code = autoCode;
                        }
                        Master_SubCategory subCategory = new Master_SubCategory()
                        {
                            OrgId = organizationId,
                            Code = item.Code,
                            Name = item.Name,
                            CategoryCode =item.CategoryCode,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_SubCategory.Add(subCategory);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }

                    result = DeleteTag(item.Code, organizationId);
                    if (Tags != null && Tags.Count > 0)
                    {
                        Tags.ForEach(titems =>
                        {
                            titems.OrgId = organizationId;
                            titems.SubCategoryCode = item.Code;
                            titems.TagCode = titems.TagCode;
                            result = SaveTag(titems, user);
                        });
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, SUBCATEGORY, organizationId);
            }

            return result;
        }

        //Edit the currency details
        public GE::SubCategory GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::SubCategory _data = new GE.SubCategory();
            List<GE::SubCategoryTag> _tdata = new List<GE.SubCategoryTag>();
            try
            {
                var item = ERPMASTERDatabase().Master_SubCategory.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.TranNo);
                var tagitem = ERPMASTERDatabase().Master_SubCategoryTag.Where(o => o.SubCategoryCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).ToList();
                if (item != null)
                {
                    _data = (new GE.SubCategory
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,
                        Name = item.Name,
                        CategoryCode = item.CategoryCode,
                        DisplayOrder = item.DisplayOrder,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });

                    if (tagitem != null && tagitem.Count > 0)
                    {
                        tagitem.ForEach(titems =>
                        {
                            _tdata.Add(new GE.SubCategoryTag
                            {
                                OrgId = titems.OrgId,
                                SubCategoryCode = titems.SubCategoryCode,
                                TagCode = titems.TagCode,
                            });
                        });
                    }
                }
                _data.SubCategoryTags = _tdata;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBCATEGORY, inputdata.OrganisationId);
            }
            return _data;
        }

        //Delete the currency details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_SubCategory.FirstOrDefault(o => o.Code == inputdata.CategoryCode && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBCATEGORY, inputdata.OrganisationId);
            }
            return result;
        }
        // Get All
        public List<GE::SubCategory> GetbyCategoryCode(GE::ERPInputmodel inputdata)
        {
            List<GE::SubCategory> _list = new List<GE.SubCategory>();
            try
            {
                var _data = ERPMASTERDatabase().Master_SubCategory.Where(o => o.OrgId == inputdata.OrganisationId && o.CategoryCode == inputdata.TransactionNo && o.IsActive == true).OrderByDescending(o => o.CreatedOn).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.SubCategory
                        {
                            OrgId = item.OrgId,
                            Code = item.Code,
                            Name = item.Name,
                            CategoryCode = item.CategoryCode,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBCATEGORY, inputdata.OrganisationId);
            }
            return _list;
        }

        public string DeleteTag(string SubCategoryCode, int OrganizationId)
        {
            string Result = string.Empty;
            string qString = "Delete From Master_SubCategoryTag WHERE SubCategoryCode = " + SubCategoryCode.ToString().ToERPString();
            qString += "AND OrgId = " + OrganizationId.ToString().ToERPString();
            ERPMASTERDatabase().Database.ExecuteSqlCommand(qString);
            Result = PASS;
            return Result;
        }

        public string SaveTag(GE::SubCategoryTag bitem, string user)
        {
            string Result = string.Empty;
            Master_SubCategoryTag _tag = new Master_SubCategoryTag()
            {
                OrgId = bitem.OrgId,
                SubCategoryCode = bitem.SubCategoryCode,
                TagCode = bitem.TagCode,
                IsActive = true,
                CreatedOn = DateTime.Now,
                CreatedBy = user,
                ChangedOn = DateTime.Now,
                ChangedBy = user,
            };
            ERPMASTERDatabase().Master_SubCategoryTag.Add(_tag);
            ERPMASTERDatabase().SaveChanges();
            Result = PASS;
            return Result;
        }
    }
}
