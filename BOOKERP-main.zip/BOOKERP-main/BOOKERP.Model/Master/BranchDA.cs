﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class BranchDA : CommonDA
    {
        // Get the branch details
        public List<GE::Branch> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::Branch> _list = new List<GE.Branch>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetBranchDetails(inputData.OrganisationId, inputData.IsActive).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Branch
                        {
                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            BranchName = item.BranchName,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            Email = item.Email,
                            PostalCode = item.PostalCode,
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            MobileNo = item.MobileNo,
                            PhoneNo = item.PhoneNo,
                            IsActive = item.IsActive,
                            IsMainBranch = item.IsMainBranch,
                            ContactNo = item.ContactNo,
                            ContactPerson = item.ContactPerson,
                            Fax = item.Fax,
                            HaveStock = item.HaveStock,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BRANCH, inputData.OrganisationId);
            }
            return _list;
        }
        //Save and update the branch details
        public string Save(GE::Branch item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.BranchCode == item.BranchCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.BranchName = item.BranchName;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.Country = item.CountryCode;
                        _data.PostalCode = item.PostalCode;
                        _data.MobileNo = item.MobileNo;
                        _data.PhoneNo = item.PhoneNo;
                        _data.Fax = item.Fax;
                        _data.Email = item.Email;
                        _data.ContactNo = item.ContactNo;
                        _data.ContactPerson = item.ContactPerson;
                        _data.IsMainBranch = item.IsMainBranch;
                        _data.IsActive = item.IsActive;
                        _data.HaveStock = item.HaveStock;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.BranchCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, BRANCH);
                            item.BranchCode = autoCode;
                        }
                        Master_Branch branch = new Master_Branch()
                        {
                            OrgId = organizationId,
                            BranchName = item.BranchName,
                            BranchCode = item.BranchCode,
                            AddressLine1 = CheckNull(item.AddressLine1),
                            AddressLine2 = CheckNull(item.AddressLine2),
                            AddressLine3 = CheckNull(item.AddressLine3),
                            Country = item.CountryCode,
                            PostalCode = item.PostalCode,
                            MobileNo = item.MobileNo,
                            PhoneNo = item.PhoneNo,
                            Fax = item.Fax,
                            Email = item.Email,
                            ContactNo = item.ContactNo,
                            ContactPerson = item.ContactPerson,
                            IsActive = item.IsActive,
                            IsMainBranch = item.IsMainBranch,
                            HaveStock = item.HaveStock,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Branch.Add(branch);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, BRANCH, organizationId);
            }

            return result;
        }
        //Edit the branch details
        public GE::Branch GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Branch _data = new GE.Branch();
            try
            {
                string country = string.Empty;
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.BranchCode == inputdata.BranchCode);
                if (item != null)
                {
                    if (!String.IsNullOrEmpty(item.Country))
                    {
                        country = ERPMASTERDatabase().Master_Countries.FirstOrDefault(o => o.CountryCode == item.Country).CountryName;
                    }

                    _data = (new GE.Branch
                    {
                        OrgId = item.OrgId,
                        BranchName = item.BranchName,
                        BranchCode = item.BranchCode,
                        AddressLine1 = CheckNull(item.AddressLine1),
                        AddressLine2 = CheckNull(item.AddressLine2),
                        AddressLine3 = CheckNull(item.AddressLine3),
                        CountryName = country,
                        CountryCode = item.Country,
                        PostalCode = item.PostalCode,
                        MobileNo = item.MobileNo,
                        PhoneNo = item.PhoneNo,
                        Fax = item.Fax,
                        Email = item.Email,
                        ContactNo = item.ContactNo,
                        ContactPerson = item.ContactPerson,
                        IsActive = item.IsActive,
                        HaveStock = item.HaveStock,
                        IsMainBranch = item.IsMainBranch,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the branch details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.BranchCode == inputdata.BranchCode && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return result;
        }
        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputData)
        {
            List<GE::Country> _list = new List<GE.Country>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Countries.Where(o => o.IsActive == inputData.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Country
                        {
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BRANCH, inputData.OrganisationId);
            }
            return _list;
        }
        //To active the branch details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Branch.FirstOrDefault(o => o.BranchCode == inputData.BranchCode && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BRANCH, inputData.OrganisationId);
            }
            return result;
        }
    }
}
