﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class CountryDA : CommonDA
    {


        public List<GE::Country> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Country> _list = new List<GE.Country>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Countries.Where(o => o.IsActive == inputdata.IsActive).OrderBy(o => o.CountryName).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Country
                        {

                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            CountryDialCode = item.CountryDialCode,
                            //CountryNUM = item.CountryNUM,
                            //CountryISO = item.CountryISO,
                            //CountryISD = item.CountryISD,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn
                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, COUNTRY, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::Country GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Country _data = new GE.Country();
            try
            {
                var item = ERPMASTERDatabase().Master_Countries.Find(inputdata.TransactionNo);
                if (item != null)
                {
                    _data = (new GE.Country
                    {

                        CountryCode = item.CountryCode,
                        CountryName = item.CountryName,
                        CountryDialCode = item.CountryDialCode,
                        //CountryNUM = item.CountryNUM,
                        //CountryISO = item.CountryISO,
                        //CountryISD = item.CountryISD,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn

                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, COUNTRY, inputdata.OrganisationId);
            }
            return _data;
        }
        // Create or Update
        public string Save(GE::Country item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Countries.FirstOrDefault(o => o.CountryCode == item.CountryCode);
                    if (_data != null)
                    {
                        _data.CountryCode = item.CountryCode;
                        _data.CountryName = item.CountryName;
                        _data.CountryDialCode = item.CountryDialCode;
                        //_data.CountryNUM = item.CountryNUM;
                        //_data.CountryISO = item.CountryISO;
                        //_data.CountryISD = item.CountryISD;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.CountryCode))
                        {
                            var autoCode = GetMasterNextNo(OrganizationId,COUNTRY);
                            item.CountryCode = autoCode;
                        }
                        Master_Countries coun = new Master_Countries()
                        {
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            CountryDialCode = item.CountryDialCode,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Countries.Add(coun);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, COMPANY, OrganizationId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Countries.FirstOrDefault(o => o.CountryCode == inputdata.TransactionNo);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, COUNTRY, inputdata.OrganisationId);
            }
            return result;
        }
        //Make Active
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Countries.FirstOrDefault(o => o.CountryCode == inputdata.TransactionNo);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, COUNTRY, inputdata.OrganisationId);
            }
            return result;
        }


    }
}
