﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class GiftVoucherSettingsDA : CommonDA
    {
        // Get All
        public List<GE::GiftVoucherSettings> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::GiftVoucherSettings> _list = new List<GE.GiftVoucherSettings>();
            try
            {
                //var _data = ERPMASTERDatabase().Master_GiftVoucherSettings.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                var _data = (from a in ERPMASTERDatabase().Master_GiftVoucherSettings.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId)
                            join b in ERPMASTERDatabase().Master_GiftVoucher
                            on a.VoucherCode equals b.VoucherCode into v
                            from b in v.DefaultIfEmpty()
                            orderby a.CreatedOn descending
                            select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.GiftVoucherSettings
                        {
                            OrgId = item.a.OrgId,
                            VoucherSettingsCode = item.a.VoucherSettingsCode,
                            VoucherCode = item.a.VoucherCode,
                            VoucherName = item.b.VoucherName,
                            Amount = item.a.Amount != null ? item.a.Amount : 0,
                            Validity = item.a.Validity != null ? item.a.Validity : 0,
                            StartNo = item.a.StartNo != null ? item.a.StartNo : 0,
                            Total = item.a.Total != null ? item.a.Total : 0,
                            GenerateDate = item.a.GenerateDate,
                            GenerateDateString = (item.a.GenerateDate != null) ? item.a.GenerateDate.Value.ToERPdate() : string.Empty,
                            IsActive = item.a.IsActive,                           
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            ChangedBy = item.a.ChangedBy,
                            ChangedOn = item.a.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHERSETTINGS, inputdata.OrganisationId);
            }
            
            return _list;
        }

        // save and update the gift voucher settings details
        public string Save(GE::GiftVoucherSettings item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_GiftVoucherSettings.FirstOrDefault(o => o.VoucherSettingsCode == item.VoucherSettingsCode && o.OrgId == organizationId);
                    if (_data != null)
                    {                        
                        _data.VoucherCode = item.VoucherCode;
                        _data.Amount = item.Amount;
                        _data.Validity = item.Validity;
                        _data.StartNo = item.StartNo;
                        _data.GenerateDate = item.GenerateDate;
                        _data.Total = item.Total;
                        _data.IsActive = item.IsActive; 
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.VoucherSettingsCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, GIFTVOUCHERSETTINGS);
                            item.VoucherSettingsCode = autoCode;
                        }
                        Master_GiftVoucherSettings giftVoucherSettings = new Master_GiftVoucherSettings()
                        {
                            OrgId = organizationId,
                            VoucherSettingsCode = item.VoucherSettingsCode,
                            VoucherCode = item.VoucherCode,
                            Amount = item.Amount,
                            Validity = item.Validity,
                            GenerateDate = item.GenerateDate,
                            StartNo = item.StartNo,
                            Total = item.Total,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_GiftVoucherSettings.Add(giftVoucherSettings);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, GIFTVOUCHERSETTINGS, organizationId);
            }

            return result;
        }
        //Edit the gift voucher settings details
        public GE::GiftVoucherSettings GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::GiftVoucherSettings _data = new GE.GiftVoucherSettings();
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucherSettings.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.VoucherSettingsCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.GiftVoucherSettings
                    {
                        OrgId = item.OrgId,
                        VoucherSettingsCode = item.VoucherSettingsCode,
                        VoucherCode = item.VoucherCode,
                        Amount = item.Amount != null ? item.Amount : 0,
                        Validity = item.Validity != null ? item.Validity : 0,
                        StartNo = item.StartNo != null ? item.StartNo : 0,
                        Total = item.Total != null ? item.Total : 0,
                        GenerateDate = item.GenerateDate,
                        GenerateDateString = (item.GenerateDate != null) ? item.GenerateDate.Value.ToERPdate() : string.Empty,
                        IsActive = item.IsActive,                        
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHERSETTINGS, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the gift voucher settings details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucherSettings.FirstOrDefault(o => o.VoucherSettingsCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHERSETTINGS, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the gift voucher settings details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucherSettings.FirstOrDefault(o => o.VoucherSettingsCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, GIFTVOUCHERSETTINGS, inputData.OrganisationId);
            }
            return result;
        }
    }
}
