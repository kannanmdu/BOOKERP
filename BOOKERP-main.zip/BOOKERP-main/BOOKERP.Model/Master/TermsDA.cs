﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class TermsDA: CommonDA
    {
        // Get All

        public List<GE::Terms> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Terms> _list = new List<GE.Terms>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Term.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Terms
                        {
                            OrgId = item.OrgId,
                            TermCode = item.TermCode,
                            TermName = item.TermName,
                            DisplayOrder = item.DisplayOrder,
                            NeedAlertBefore = item.NeedAlertBefore,
                            NoOfDays = item.NoOfDays,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TERMS, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::Terms item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Term.FirstOrDefault(o => o.OrgId == organizationId && o.TermCode == item.TermCode);
                    if (_data != null)
                    {                        
                        _data.TermCode = item.TermCode;
                        _data.TermName = item.TermName;
                        _data.IsActive = item.IsActive;
                        _data.DisplayOrder = item.DisplayOrder;
                        _data.NeedAlertBefore = item.NeedAlertBefore;
                        _data.NoOfDays = item.NoOfDays;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.TermCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, TERMS);
                            item.TermCode = autoCode;
                        }
                        Master_Term term = new Master_Term()
                        {
                            OrgId = organizationId,
                            TermCode = item.TermCode,                            
                            TermName = item.TermName,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            NeedAlertBefore = item.NeedAlertBefore,
                            NoOfDays = item.NoOfDays,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Term.Add(term);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, TERMS, organizationId);
            }

            return result;
        }

        //Edit the term details
        public GE::Terms GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Terms _data = new GE.Terms();
            try
            {
                var item = ERPMASTERDatabase().Master_Term.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.TermCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Terms
                    {
                        TermCode = item.TermCode,
                        TermName = item.TermName,
                        OrgId = item.OrgId,
                        IsActive = item.IsActive,
                        DisplayOrder = item.DisplayOrder,
                        NoOfDays = item.NoOfDays,
                        NeedAlertBefore = item.NeedAlertBefore,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TERMS, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the term details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Term.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.TermCode == inputdata.TranNo);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TERMS, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the bank details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Term.FirstOrDefault(o => o.OrgId == inputData.OrganisationId && o.TermCode == inputData.TranNo);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, TERMS, inputData.OrganisationId);
            }
            return result;
        }
    }
}
