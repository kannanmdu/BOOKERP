﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class SupplierDA : CommonDA
    {
        public List<GE::Supplier> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::Supplier> _list = new List<GE.Supplier>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Suppliers.Where(o => o.IsActive == inputData.IsActive && o.OrgId == inputData.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Supplier
                        {
                            OrgId = item.OrgId,
                            Code = item.Code,
                            Name = item.Name,
                            UniqueNo = item.UniqueNo,
                            Mail = item.Mail,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            CountryId = item.CountryId,
                            PostalCode = item.PostalCode,
                            Mobile = item.Mobile,
                            Phone = item.Phone,
                            Fax = item.Fax,
                            TaxTypeId = item.TaxTypeId,
                            CurrencyId = item.CurrencyId,
                            PaymentTerms = item.PaymentTerms,
                            SalesPerson = item.SalesPerson,
                            Source = item.Source,
                            IsActive = item.IsActive,
                            AccountNo = item.AccountNo,
                            Activity1 = item.Activity1,
                            Activity2 = item.Activity2,
                            ContactPerson = item.ContactPerson,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, SUPPLIER, inputData.OrganisationId);
            }
            return _list;
        }

        //Save and update the Supplier details
        public string Save(GE::Supplier item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Suppliers.FirstOrDefault(o => o.Code == item.Code && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.Name = item.Name;
                        _data.Code = item.Code;
                        _data.UniqueNo = item.UniqueNo;
                        _data.Mobile = item.Mobile;
                        _data.Phone = item.Phone;
                        _data.Mail = item.Mail;
                        _data.Fax = item.Fax;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.PostalCode = item.PostalCode;
                        _data.ContactPerson = item.ContactPerson;
                        _data.AccountNo = item.AccountNo;
                        _data.Activity1 = item.Activity1;
                        _data.Activity2 = item.Activity2;
                        _data.CountryId = item.CountryId;
                        _data.CurrencyId = item.CurrencyId;
                        _data.TaxTypeId = item.TaxTypeId;
                        _data.PaymentTerms = item.PaymentTerms;
                        _data.SalesPerson = item.SalesPerson;
                        _data.Source = item.Source;
                        _data.IsActive = item.IsActive;                        
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.Code))
                        {
                            var autoCode = GetMasterNextNo(organizationId, SUPPLIER);
                            item.Code = autoCode;
                        }
                        Master_Suppliers suppliers = new Master_Suppliers()
                        {
                            OrgId = organizationId,
                            Name = item.Name,
                            Code = item.Code,
                            UniqueNo = item.UniqueNo,
                            Mobile = item.Mobile,
                            Phone = item.Phone,
                            Mail = item.Mail,
                            Fax = item.Fax,
                            AddressLine1 = CheckNull(item.AddressLine1),
                            AddressLine2 = CheckNull(item.AddressLine2),
                            AddressLine3 = CheckNull(item.AddressLine3),
                            PostalCode = item.PostalCode,
                            ContactPerson = item.ContactPerson,
                            IsActive = item.IsActive,
                            AccountNo = item.AccountNo,
                            Activity1 = item.Activity1,
                            Activity2 = item.Activity2,
                            CountryId = item.CountryId,
                            CurrencyId = item.CurrencyId,
                            TaxTypeId = item.TaxTypeId,
                            PaymentTerms = item.PaymentTerms,
                            SalesPerson = item.SalesPerson,
                            Source = item.Source,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Suppliers.Add(suppliers);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, SUPPLIER, organizationId);
            }

            return result;
        }

        //Edit the supplier details
        public GE::Supplier GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Supplier _data = new GE.Supplier();
            try
            {
                var item = ERPMASTERDatabase().Master_Suppliers.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Supplier
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,
                        UniqueNo = item.UniqueNo,
                        Activity1 = item.Activity1,
                        Activity2 = item.Activity2,
                        Name = item.Name,
                        Mail = item.Mail,
                        AddressLine1 = item.AddressLine1,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        Mobile = item.Mobile,
                        Phone = item.Phone,
                        Fax = item.Fax,                        
                        SalesPerson = item.SalesPerson,
                        CurrencyId = item.CurrencyId,
                        PaymentTerms = item.PaymentTerms,                      
                        Source = item.Source,
                        TaxTypeId = item.TaxTypeId,
                        IsActive = item.IsActive,                     
                        ContactPerson = item.ContactPerson,                       
                        AccountNo = item.AccountNo,                   
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUPPLIER, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the supplier details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Suppliers.FirstOrDefault(o => o.Code == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUPPLIER, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the supplier details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Suppliers.FirstOrDefault(o => o.Code == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, SUPPLIER, inputData.OrganisationId);
            }
            return result;
        }

    }
}
