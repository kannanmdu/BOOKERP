﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
   public class BankDA: CommonDA
    {
        // Get All

        public List<GE::Bank> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Bank> _list = new List<GE.Bank>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Bank.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Bank
                        {
                            OrgId = item.OrgId,
                            BankCode = item.BankCode,
                            BankName = item.BankName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = (item.ChangedOn != null) ? item.CreatedOn.Value.ToERPdate() : string.Empty,
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANK, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::Bank item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Bank.FirstOrDefault(o => o.BankCode == item.BankCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.BankCode = item.BankCode;
                        _data.BankName = item.BankName;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.BankCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, BANK);
                            item.BankCode = autoCode;
                        }
                        Master_Bank bank = new Master_Bank()
                        {
                            OrgId = organizationId,
                            BankCode = item.BankCode,
                            BankName = item.BankName,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Master_Bank.Add(bank);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, BANK, organizationId);
            }

            return result;
        }

        //Edit the bank details
        public GE::Bank GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Bank _data = new GE.Bank();
            try
            {
                var item = ERPMASTERDatabase().Master_Bank.FirstOrDefault(o => o.BankCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.Bank
                    {
                        OrgId = item.OrgId,
                        BankCode = item.BankCode,
                        BankName = item.BankName,                        
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANK, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the bank details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Bank.FirstOrDefault(o => o.BankCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANK, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the bank details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Bank.FirstOrDefault(o => o.BankCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BANK, inputData.OrganisationId);
            }
            return result;
        }
    }
}
