﻿using BOOKERP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class UserDA : CommonDA
    {
        // Get the user details
        public List<GE::User> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::User> _list = new List<GE.User>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetUserDetails(inputData.OrganisationId, inputData.IsActive).ToList();              
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.User
                        {
                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            UserName = item.UserName,
                            Password = item.Password,
                            FullName = item.FullName,
                            UserRoleCode = item.UserRoleCode,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            Country = item.CountryName,
                            PostalCode = item.PostalCode,
                            MobileNo = item.MobileNo,
                            IsActive = item.IsActive,
                            EmailId = item.EmailId,
                            UserImage = item.UserImage,
                            DefaultBranchCode = item.DefaultBranchCode,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USER, inputData.OrganisationId);
            }
            return _list;
        }
        //Save and update the user details
        public string Save(GE::User item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.UserName == item.UserName && o.OrgId == organizationId);
                    if (_data != null)
                    {                        
                        _data.BranchCode = item.BranchCode;
                        _data.UserName = item.UserName;
                        _data.Password = !string.IsNullOrEmpty(item.Password) ? item.Password : _data.Password;
                        _data.FullName = item.FullName;
                        _data.UserRoleCode = item.UserRoleCode;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.Country = item.Country;
                        _data.PostalCode = item.PostalCode;
                        _data.MobileNo = item.MobileNo;
                        _data.IsActive = item.IsActive;
                        _data.EmailId = item.EmailId;
                        _data.UserImage = item.UserImage;
                        _data.DefaultBranchCode = item.DefaultBranchCode;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {                       
                        Security_UserMaster userMaster = new Security_UserMaster()
                        {
                            OrgId = organizationId,
                            UserName = item.UserName,
                            BranchCode = item.BranchCode,
                            AddressLine1 = CheckNull(item.AddressLine1),
                            AddressLine2 = CheckNull(item.AddressLine2),
                            AddressLine3 = CheckNull(item.AddressLine3),
                            Password = item.Password,
                            FullName = item.FullName,
                            UserRoleCode = item.UserRoleCode,
                            Country = item.Country,
                            PostalCode = item.PostalCode,
                            MobileNo = item.MobileNo,
                            EmailId = item.EmailId,
                            IsActive = item.IsActive,
                            UserImage = item.UserImage,
                            DefaultBranchCode = item.DefaultBranchCode,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().Security_UserMaster.Add(userMaster);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, USER, organizationId);
            }

            return result;
        }
        //Edit the user details
        public GE::User GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::User _data = new GE.User();
            try
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.UserName == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.User
                    {
                        OrgId = item.OrgId,
                        UserName = item.UserName,
                        Password = item.Password,
                        BranchCode = item.BranchCode,
                        FullName = item.FullName,
                        AddressLine1 = CheckNull(item.AddressLine1),
                        AddressLine2 = CheckNull(item.AddressLine2),
                        AddressLine3 = CheckNull(item.AddressLine3),
                        UserRoleCode = item.UserRoleCode,
                        PostalCode = item.PostalCode,
                        MobileNo = item.MobileNo,
                        Country = item.Country,
                        EmailId = item.EmailId,                       
                        IsActive = item.IsActive,
                        UserImage = item.UserImage,
                        DefaultBranchCode = item.DefaultBranchCode,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, USER, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the user details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.UserName == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, USER, inputdata.OrganisationId);
            }
            return result;
        }
       
        //To active the user details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.UserName == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USER, inputData.OrganisationId);
            }
            return result;
        }

        public GE::User GetbyLogin(GE::LoginModel loginModel)
        {
            GE::User _data = new GE.User();
            try
            {
                //var item = ERPMASTERDatabase().Users.FirstOrDefault(o => o.Username == username && o.Password == password);
                var item = (from a in ERPMASTERDatabase().Security_UserMaster
                            join b in ERPMASTERDatabase().Master_Organization
                             on a.OrgId equals b.OrgId
                            where a.UserName == loginModel.Username && a.Password == loginModel.Password && a.OrgId == loginModel.OrgId
                            select new { a, b }).FirstOrDefault();
                if (item != null)
                {
                    _data = (new GE.User
                    {
                        UserName = item.a.UserName,
                        FullName = item.a.FullName,
                        //UniqueNo = item.a.UniqueNo,
                        OrgId = item.a.OrgId,
                        Password = item.a.Password,
                        UserRoleCode = item.a.UserRoleCode,
                        AddressLine1 = item.a.AddressLine1,
                        AddressLine2 = item.a.AddressLine2,
                        AddressLine3 = item.a.AddressLine3,
                        Country = item.a.Country,
                        PostalCode = item.a.PostalCode,
                        //Phone = item.a.Phone,
                        //Mobile = item.a.Mobile,
                        //Mail = item.a.Mail,
                        //Fax = item.a.Fax,
                        //Facebook = item.a.Facebook,
                        //LinkedIn = item.a.LinkedIn,
                        IsActive = item.a.IsActive,
                        ChangedBy = item.a.ChangedBy,
                        ChangedOn = item.a.ChangedOn,
                        CreatedBy = item.a.CreatedBy,
                        CreatedOn = item.a.CreatedOn,
                        OrganisationName = item.b.OrgName,
                        BranchCode = item.a.BranchCode,
                        ItemImageString = String.IsNullOrEmpty(GetStringfrombyte(item.a.UserImage)) ? "/Content/images/profilepic.png" : GetStringfrombyte(item.a.UserImage),
                        CompanyImageString = String.IsNullOrEmpty(GetStringfrombyte(item.b.OrgLogo)) ? "/Content/images/profilepic.png" : GetStringfrombyte(item.b.OrgLogo)
                    });
                }
            }
            catch (Exception ex)
            {
                var aa = ex.GetBaseException();
                new ExceptionDA().Save(ex.Message, string.Empty, USER, loginModel.OrgId);
            }
            return _data;
        }

        public string GetStringfrombyte(byte[] ImageArray)
        {
            string imgDataURL = string.Empty;
            if (ImageArray != null)
            {
                string imreBase64Data = Convert.ToBase64String(ImageArray);
                imgDataURL = string.Format("data:image/png;base64,{0}", imreBase64Data);
            }
            return imgDataURL;
        }

        public string GetbyDecrypted(string Username, int orgid)
        {
            string _data = string.Empty;
            try
            {
                //var item = ERPMASTERDatabase().Users.FirstOrDefault(o => o.Username == username && o.Password == password);
                var item = (from a in ERPMASTERDatabase().Security_UserMaster
                            join b in ERPMASTERDatabase().Master_Organization
                             on a.OrgId equals b.OrgId
                            where a.UserName == Username && a.OrgId == orgid
                            select new { a, b }).FirstOrDefault();
                if (item != null)
                {
                    _data = item.a.Password;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USER, orgid);
            }
            return _data;
        }
        public bool CheckAdministratorlogin(GE::LoginModel loginModel)
        {
            bool Result = false;
            try
            {
                var item = ERPMASTERDatabase().Security_UserMaster.FirstOrDefault(o => o.UserName == loginModel.Username && o.Password == loginModel.Password && o.OrgId == loginModel.OrgId);
                if (item != null)
                {
                    if (item.UserRoleCode == "admin")
                    {
                        Result = true;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, USER, loginModel.OrgId);
            }
            return Result;
        }
    }
}
