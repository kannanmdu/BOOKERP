﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class GiftVoucherDA : CommonDA
    {
        // Get All
        public List<GE::GiftVoucher> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::GiftVoucher> _list = new List<GE.GiftVoucher>();
            try
            {
                var _data = ERPMASTERDatabase().Master_GiftVoucher.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.GiftVoucher
                        {
                            OrgId = item.OrgId,
                            VoucherCode = item.VoucherCode,
                            VoucherName = item.VoucherName,
                            Amount = item.Amount != null ? item.Amount : 0,
                            DueDate = item.DueDate,
                            DueDateString = (item.DueDate != null) ? item.DueDate.Value.ToERPdate() : string.Empty,
                            StartNo = item.StartNo != null ? item.StartNo : 0,
                            SequenceNo = item.SequenceNo != null ? item.SequenceNo : 0,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHER, inputdata.OrganisationId);
            }
            
            return _list;
        }

        // save and update 
        public string Save(GE::GiftVoucher item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.VoucherCode == item.VoucherCode && o.OrgId == organizationId);
                    if (_data != null)
                    {                        
                        _data.VoucherName = item.VoucherName;
                        _data.Amount = item.Amount;
                        _data.DueDate = item.DueDate;
                        _data.IsActive = item.IsActive;
                        _data.StartNo = item.StartNo;
                        _data.SequenceNo = item.SequenceNo;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.VoucherCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, GIFTVOUCHER);
                            item.VoucherCode = autoCode;
                        }
                        Master_GiftVoucher giftvoucher = new Master_GiftVoucher()
                        {
                            OrgId = organizationId,
                            VoucherCode = item.VoucherCode,
                            VoucherName = item.VoucherName,
                            Amount = item.Amount,
                            DueDate = item.DueDate,
                            StartNo = item.StartNo,
                            SequenceNo = item.SequenceNo,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_GiftVoucher.Add(giftvoucher);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, GIFTVOUCHER, organizationId);
            }

            return result;
        }
        //Edit the gift voucher details
        public GE::GiftVoucher GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::GiftVoucher _data = new GE.GiftVoucher();
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.VoucherCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.GiftVoucher
                    {
                        OrgId = item.OrgId,
                        VoucherCode = item.VoucherCode,
                        VoucherName = item.VoucherName,
                        Amount = item.Amount != null ? item.Amount : 0,
                        DueDate = item.DueDate,
                        DueDateString = (item.DueDate != null) ? item.DueDate.Value.ToERPdate() : string.Empty,
                        StartNo = item.StartNo != null ? item.StartNo : 0,
                        SequenceNo = item.SequenceNo != null ? item.SequenceNo : 0,
                        IsActive = item.IsActive,                        
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHER, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the gift voucher details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.VoucherCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GIFTVOUCHER, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the gift voucher details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_GiftVoucher.FirstOrDefault(o => o.VoucherCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, GIFTVOUCHER, inputData.OrganisationId);
            }
            return result;
        }
    }
}
