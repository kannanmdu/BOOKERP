﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class CategoryDA : CommonDA
    {
        // Get All
        public List<GE::Category> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Category> _list = new List<GE.Category>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Category.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Category
                        {
                            OrgId = item.OrgId,
                            Code = item.Code,
                            Name = item.Name,
                            SortOrder = item.SortOrder,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CATEGORY, inputdata.OrganisationId);
            }

            return _list;
        }

        // save and update the currency details
        public string Save(GE::Category item, List<GE::CategoryTag> Tags, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Category.FirstOrDefault(o => o.Code == item.Code && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.Code = item.Code;
                        _data.Name = item.Name;
                        _data.SortOrder = item.SortOrder;
                        _data.IsActive = item.IsActive;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.Code))
                        {
                            var autoCode = GetMasterNextNo(organizationId, CATEGORY);
                            item.Code = autoCode;
                        }
                        Master_Category category = new Master_Category()
                        {
                            OrgId = organizationId,
                            Code = item.Code,
                            Name = item.Name,
                            SortOrder = item.SortOrder,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_Category.Add(category);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    result = DeleteTag(item.Code, organizationId);
                    if (Tags != null && Tags.Count > 0)
                    {
                        Tags.ForEach(titems =>
                        {
                            titems.OrgId = organizationId;
                            titems.CategoryCode = item.Code;
                            titems.TagCode = titems.TagCode;
                            result = SaveTag(titems, user);
                        });
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CATEGORY, organizationId);
            }

            return result;
        }

        //Edit the currency details
        public GE::Category GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Category _data = new GE.Category();
            List<GE::CategoryTag> _tdata = new List<GE.CategoryTag>();
            try
            {
                var item = ERPMASTERDatabase().Master_Category.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.Code == inputdata.TranNo);
                var tagitem = ERPMASTERDatabase().Master_CategoryTag.Where(o => o.CategoryCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).ToList();
                if (item != null)
                {
                    _data = (new GE.Category    
                    {
                        OrgId = item.OrgId,
                        Code = item.Code,
                        Name = item.Name,
                        SortOrder = item.SortOrder,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });

                    if (tagitem != null && tagitem.Count > 0)
                    {
                        tagitem.ForEach(titems =>
                        {
                            _tdata.Add(new GE.CategoryTag
                            {
                                OrgId = titems.OrgId,
                                CategoryCode = titems.CategoryCode,
                                TagCode = titems.TagCode,
                            });
                        });
                    }
                }
                _data.CategoryTags = _tdata;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CATEGORY, inputdata.OrganisationId);
            }
            return _data;
        }

        //Delete the currency details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Category.FirstOrDefault(o => o.Code == inputdata.CategoryCode && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CATEGORY, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the currency details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Category.FirstOrDefault(o => o.Code == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CATEGORY, inputData.OrganisationId);
            }
            return result;
        }

        public string DeleteTag(string CategoryCode, int OrganizationId)
        {
            string Result = string.Empty;
            string qString = "Delete From Master_CategoryTag WHERE CategoryCode = " + CategoryCode.ToString().ToERPString();
            qString += "AND OrgId = " + OrganizationId.ToString().ToERPString();
            ERPMASTERDatabase().Database.ExecuteSqlCommand(qString);
            Result = PASS;
            return Result;
        }

        public string SaveTag(GE::CategoryTag bitem, string user)
        {
            string Result = string.Empty;
            Master_CategoryTag _tag = new Master_CategoryTag()
            {
                OrgId = bitem.OrgId,
                CategoryCode = bitem.CategoryCode,
                TagCode = bitem.TagCode,
                IsActive = true,
                CreatedOn = DateTime.Now,
                CreatedBy = user,
                ChangedOn = DateTime.Now,
                ChangedBy = user,
            };
            ERPMASTERDatabase().Master_CategoryTag.Add(_tag);
            ERPMASTERDatabase().SaveChanges();
            Result = PASS;
            return Result;
        }
    }
}
