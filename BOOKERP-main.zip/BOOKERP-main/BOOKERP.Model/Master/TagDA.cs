﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class TagDA : CommonDA
    {
        // Get All
        public List<GE::Tag> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Tag> _list = new List<GE.Tag>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Tag.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Tag
                        {
                            OrgId = item.OrgId,
                            TagCode = item.TagCode,
                            TagName = item.TagName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAG, inputdata.OrganisationId);
            }

            return _list;
        }

        // save and update the tag details
        public string Save(GE::Tag item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Master_Tag.FirstOrDefault(o => o.TagCode == item.TagCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.TagCode = item.TagCode;
                        _data.TagName = item.TagName;
                        _data.IsActive = item.IsActive;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.TagCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, TAG);
                            item.TagCode = autoCode;
                        }
                        Master_Tag tag = new Master_Tag()
                        {
                            OrgId = organizationId,
                            TagCode = item.TagCode,
                            TagName = item.TagName,
                            IsActive = item.IsActive,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Master_Tag.Add(tag);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, TAG, organizationId);
            }
            return result;
        }
        //Edit the tag details
        public GE::Tag GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Tag _data = new GE.Tag();
            try
            {
                var item = ERPMASTERDatabase().Master_Tag.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.TagCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Tag
                    {
                        OrgId = item.OrgId,
                        TagCode = item.TagCode,
                        TagName = item.TagName,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAG, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the tag details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Tag.FirstOrDefault(o => o.TagCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TAG, inputdata.OrganisationId);
            }
            return result;
        }
        //To active the tag details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Tag.FirstOrDefault(o => o.TagCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, TAG, inputData.OrganisationId);
            }
            return result;
        }
    }
}
