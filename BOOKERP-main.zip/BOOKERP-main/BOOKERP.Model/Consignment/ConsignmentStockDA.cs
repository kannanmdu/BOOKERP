﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class ConsignmentStockDA : CommonDA
    {
        public List<GE::ConsignmentStock> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::ConsignmentStock> _list = new List<GE.ConsignmentStock>();
            try
            {
                var _data = ERPMASTERDatabase().SP_GetConsignmentStockDetails(inputdata.OrganisationId, inputdata.TranType).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.ConsignmentStock
                        {
                            OrgId = item.OrgId,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            CustomerCode = item.CustomerCode,
                            CustomerName = item.CustomerName,
                            ISBN13 = item.ISBN13,
                            StockQty = item.StockQty,
                            StockBoxQty = item.StockBoxQty,
                            StockPcsQty = item.StockPcsQty,
                            BoxCount = item.BoxCount,
                            StockWQty = item.StockWQty,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn                           
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CONSIGNMENT, inputdata.OrganisationId);
            }
            return _list;
        }  
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                //var data = ERPMASTERDatabase().SP_SaveSalesDO_Deleted(inputdata.OrganisationId, inputdata.TranNo).FirstOrDefault();
                var data = string.Empty;
                if (data != null)
                {
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CONSIGNMENT, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
