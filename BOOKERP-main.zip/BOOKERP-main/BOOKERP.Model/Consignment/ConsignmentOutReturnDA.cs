﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class ConsignmentOutReturnDA : CommonDA
    {
        public List<GE::ConsignmentOutReturnHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::ConsignmentOutReturnHeader> _list = new List<GE.ConsignmentOutReturnHeader>();
            try
            {
                var _data = ERPMASTERDatabase().ConsignmentReturnHeaders.Where(o => o.OrgId == inputdata.OrganisationId && o.IsActive == true && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).Take(5000).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.ConsignmentOutReturnHeader
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate != null) ? item.TranDate.ToERPdate() : string.Empty,
                            CustomerSupplierId = item.CustomerSupplierId,
                            CustomerSupplierName = !string.IsNullOrEmpty(item.CustomerSupplierName) ? item.CustomerSupplierName : string.Empty,
                            CustomerSupplierAddress = item.CustomerSupplierAddress,
                            BranchCode = item.BranchCode,
                            TaxType = item.TaxType,
                            TaxPerc = item.TaxPerc,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            Total = item.Total,
                            Discount = item.Discount,
                            DiscountPerc = item.DiscountPerc,
                            SubTotal = item.SubTotal,
                            Tax = item.Tax,
                            NetTotal = item.NetTotal,
                            Remarks = item.Remarks,
                            ReferenceNo = item.ReferenceNo,
                            CreatedFrom = item.CreatedFrom,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            AssignTo = item.AssignTo,
                            TaxCode = item.TaxCode,
                            FDiscount = item.FDiscount,
                            FNetTotal = item.FNetTotal,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FTotal = item.FTotal,
                            FDiscountPerc = item.FDiscountPerc,
                            CurrencyValue = item.CurrencyValue,
                            FBillDiscount = item.FBillDiscount,
                            Status = item.Status,
                            PriceSettingCode = item.PriceSettingCode,
                            TermCode = item.TermCode,
                            InvoiceType = item.InvoiceType,
                            BillDiscount = item.BillDiscount,
                            CustomerSupplierShipToAddress = item.CustomerSupplierShipToAddress,
                            CustomerSupplierShipToId = item.CustomerSupplierShipToId,
                            Latitude = item.Latitude,
                            Longitude = item.Longitude,
                            Cameraimage = item.Cameraimage,
                            Signatureimage = item.Signatureimage,
                            SummaryRemarks = item.SummaryRemarks,
                            TranType = item.TranType
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CONSIGNMENT, inputdata.OrganisationId);
            }
            return _list;
        }
        public string Save(GE::ConsignmentOutReturnHeader header, List<GE::ConsignmentOutReturnDetail> details, string user, List<GE::ConsignmentOutDODetail> consignmentdetails)
        {
            string Result = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (string.IsNullOrEmpty(header.TranNo))
                        {
                            if (header.TranType == "C")
                                header.TranNo = AutoTranNo(header.OrgId, header.BranchCode, "Consignment Out Return");
                            else
                                header.TranNo = AutoTranNo(header.OrgId, header.BranchCode, "Consignment In Return");
                        }
                        string TranNo = SaveHeader(header, user, context);
                        if (!string.IsNullOrEmpty(TranNo))
                        {
                            context.SaveChanges();
                            details.ForEach(_details =>
                            {
                                _details.TranNo = header.TranNo;
                                _details.OrgId = header.OrgId;
                                _details.CustomerSupplierId = header.CustomerSupplierId;
                                string res = SaveDetail(_details, user, context);
                                if (res == TranNo)
                                    listcount = listcount + 1;
                            });
                            if (listcount == details.Count)
                            {
                                Result = TranNo;
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                            }
                            else
                                dbContextTransaction.Rollback();
                        }
                        else
                            dbContextTransaction.Rollback();

                        if (listcount == details.Count)
                        {
                            if (consignmentdetails.Count > 0)
                            {
                                consignmentdetails.ForEach(_consignmentdetails =>
                                {
                                    _consignmentdetails.OrgId = header.OrgId;
                                    string res = SaveConsignmentReturnDetail(_consignmentdetails, user, context);
                                });
                            }
                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CONSIGNMENT, header.OrgId);
            }
            return Result;
        }
        public string SaveHeader(GE::ConsignmentOutReturnHeader item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.SP_SaveConsignmentReturnHeader(item.OrgId, item.BranchCode, item.TranNo, item.TranDate, item.CustomerSupplierId, item.CustomerSupplierName, item.CustomerSupplierAddress, item.TaxCode, item.TaxType, item.TaxPerc, item.CurrencyCode,
                    item.CurrencyRate, item.CurrencyValue, item.Total, item.Discount, item.DiscountPerc, item.BillDiscount, item.SubTotal, item.Tax, item.NetTotal, item.FTotal, item.FDiscount, item.FSubTotal, item.FTax, item.FNetTotal,
                    item.Remarks, item.ReferenceNo, "Web", user, item.AssignTo, item.PriceSettingCode, item.TermCode, item.InvoiceType, item.CustomerSupplierShipToId, item.CustomerSupplierShipToAddress, item.SONo,
                    item.Latitude, item.Longitude, item.Signatureimage, item.Cameraimage, item.SummaryRemarks, item.FDiscountPerc, item.FBillDiscount, item.TranType).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CONSIGNMENT, item.OrgId);
            }
            return result;
        }
        public string SaveDetail(GE::ConsignmentOutReturnDetail item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.SP_SaveConsignmentReturnDetail(item.OrgId, item.TranNo, item.SlNo, item.ProductCode, item.ProductName, item.BoxQty, item.PcsQty, item.Qty, item.BoxCount, item.BoxPrice,
                     item.Price, item.Foc, item.Exchange, item.Total, item.ItemDiscount, item.ItemDiscountPerc, item.SubTotal, item.Tax, item.NetTotal, item.FBoxPrice, item.FPrice,
                     item.FTotal, item.FItemDiscount, item.FSubTotal, item.FTax, item.FNetTotal, item.Remarks, item.Weight, user, item.FItemDiscountPerc, item.CustomerSupplierId, item.StockQty, item.StockBoxQty, item.StockPcsQty).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CONSIGNMENT, item.OrgId);
            }
            return result;
        }
        public string SaveConsignmentReturnDetail(GE::ConsignmentOutDODetail item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var _data = dBEntities.Sp_SaveConsignmentDOReturnDetail(item.OrgId, item.TranNo, item.SlNo, item.ProductCode, item.ReturnQty, user).FirstOrDefault();
                if (_data != null)
                {
                    result = _data.Result;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CONSIGNMENT, item.OrgId);
            }
            return result;
        }
        public GE::ConsignmentOutReturnHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::ConsignmentOutReturnHeader _data = new GE.ConsignmentOutReturnHeader();
            List<GE::ConsignmentOutReturnDetail> _list = new List<GE.ConsignmentOutReturnDetail>();
            try
            {
                var item = ERPMASTERDatabase().ConsignmentReturnHeaders.FirstOrDefault(o => o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                var detailitem = ERPMASTERDatabase().ConsignmentReturnDetails.Where(o => o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId).ToList();

                if (item != null)
                {
                    _data = (new GE.ConsignmentOutReturnHeader
                    {
                        OrgId = item.OrgId,
                        TranNo = item.TranNo,
                        TranDate = item.TranDate,
                        TranDateString = (item.TranDate != null) ? item.TranDate.ToERPdate() : string.Empty,
                        CustomerSupplierId = item.CustomerSupplierId,
                        CustomerSupplierName = item.CustomerSupplierName,
                        CustomerSupplierAddress = item.CustomerSupplierAddress,
                        BranchCode = item.BranchCode,
                        TaxType = item.TaxType,
                        TaxPerc = item.TaxPerc,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        Total = item.Total,
                        Discount = item.Discount,
                        DiscountPerc = item.DiscountPerc,
                        SubTotal = item.SubTotal,
                        Tax = item.Tax,
                        NetTotal = item.NetTotal,
                        Remarks = item.Remarks,
                        ReferenceNo = item.ReferenceNo,
                        CreatedFrom = item.CreatedFrom,
                        IsActive = item.IsActive,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        AssignTo = item.AssignTo,
                        TaxCode = item.TaxCode,
                        FDiscount = item.FDiscount,
                        FNetTotal = item.FNetTotal,
                        FSubTotal = item.FSubTotal,
                        FTax = item.FTax,
                        FTotal = item.FTotal,
                        FDiscountPerc = item.FDiscountPerc,
                        FBillDiscount = item.FBillDiscount,
                        CurrencyValue = item.CurrencyValue,
                        Status = item.Status,
                        PriceSettingCode = item.PriceSettingCode,
                        TermCode = item.TermCode,
                        InvoiceType = item.InvoiceType,
                        BillDiscount = item.BillDiscount,
                        CustomerSupplierShipToAddress = item.CustomerSupplierShipToAddress,
                        CustomerSupplierShipToId = item.CustomerSupplierShipToId,
                        Latitude = item.Latitude,
                        Longitude = item.Longitude,
                        Cameraimage = item.Cameraimage,
                        Signatureimage = item.Signatureimage,
                        SummaryRemarks = item.SummaryRemarks,
                        TranType = item.TranType                        
                    });
                }

                if (detailitem != null && detailitem.Count > 0)
                {
                    string ISBN13 = string.Empty;
                    detailitem.ForEach(ditem =>
                    {                        
                        ISBN13 = ERPMASTERDatabase().Master_Book.FirstOrDefault(o => o.BookId == ditem.ProductCode && o.OrgId == ditem.OrgId).ISBN13;
                        _list.Add(new GE.ConsignmentOutReturnDetail
                        {
                            OrgId = ditem.OrgId,
                            TranNo = ditem.TranNo,
                            SlNo = ditem.SlNo,
                            ProductCode = ditem.ProductCode,
                            ProductName = ditem.ProductName,
                            BoxQty = ditem.BoxQty,
                            PcsQty = ditem.PcsQty,
                            Qty = ditem.Qty,
                            BoxCount = ditem.BoxCount,
                            BoxPrice = ditem.BoxPrice,
                            Price = ditem.Price,
                            FNetTotal = ditem.FNetTotal,
                            FTax = ditem.FTax,
                            FBoxPrice = ditem.FBoxPrice,
                            FItemDiscount = ditem.FItemDiscount,
                            Foc = ditem.Foc,
                            Exchange = ditem.Exchange,
                            FPrice = ditem.FPrice,
                            FSubTotal = ditem.FSubTotal,
                            FTotal = ditem.FTotal,
                            Remarks = ditem.Remarks,
                            Total = ditem.Total,
                            ItemDiscount = ditem.ItemDiscount,
                            ItemDiscountPerc = ditem.ItemDiscountPerc,
                            FItemDiscountPerc = ditem.FItemDiscountPerc,
                            SubTotal = ditem.SubTotal,
                            Tax = ditem.Tax,
                            NetTotal = ditem.NetTotal,
                            CreatedBy = ditem.CreatedBy,
                            CreatedOn = ditem.CreatedOn,
                            ChangedBy = ditem.ChangedBy,
                            ChangedOn = ditem.ChangedOn,
                            Weight = ditem.Weight != null ? ditem.Weight : 0,
                            ISBN13 = !string.IsNullOrEmpty(ISBN13) ? ISBN13 : string.Empty
                        });
                    });
                }
                _data.ConsignmentOutReturnDetail = _list;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CONSIGNMENT, inputdata.OrganisationId);
            }
            return _data;
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                //var data = ERPMASTERDatabase().SP_SaveSalesDO_Deleted(inputdata.OrganisationId, inputdata.TranNo).FirstOrDefault();
                var data = string.Empty;
                if (data != null)
                {
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CONSIGNMENT, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
