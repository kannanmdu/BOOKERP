﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using GE = BOOKERP.Entities;
using System.Security.AccessControl;
using System.Text.RegularExpressions;

namespace BOOKERP.Model
{
    public class B2CBannerImageDA : CommonDA
    {
        public static string strFilepath = System.Configuration.ConfigurationSettings.AppSettings["Filepath"].ToString().Trim();
        public static string IP_FilePath = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath"].ToString().Trim();

        public static string strFilepath2 = System.Configuration.ConfigurationSettings.AppSettings["Filepath2"].ToString().Trim();
        public static string IP_FilePath2 = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath2"].ToString().Trim();

        public static string strFileHosted = System.Configuration.ConfigurationSettings.AppSettings["IP_FileHosted"].ToString().Trim();
        public static string localImageFilePath = System.Configuration.ConfigurationSettings.AppSettings["LocalImageFilePath"].ToString().Trim();

        public int OrgId;
        // Get All
        public List<GE::B2CBannerImage> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CBannerImage> _list = new List<GE.B2CBannerImage>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_BannerImage.Where(o =>  o.OrgId == inputdata.OrganisationId && o.IsActive == inputdata.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.B2CBannerImage
                        {
                            OrgId = item.OrgId,
                            BannerId = item.BannerId,
                            BranchCode = (item.BranchCode != null) ? item.BranchCode : string.Empty,
                            Title = item.Title,
                            Description = item.Description,
                            AdditionalDesc = item.AdditionalDesc,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            ChangedBy = item.ChangedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = item.CreatedOn.ToERPdate(),
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                            BannerImageFileName = item.BannerImageFileName,
                            BannerImageFilePath = item.BannerImageFilePath,
                        });
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CBANNERIMAGE, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::B2CBannerImage> GetAllActive(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CBannerImage> _list = new List<GE.B2CBannerImage>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_BannerImage.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.B2CBannerImage
                        {

                            OrgId = item.OrgId,
                            BannerId = item.BannerId,
                            BranchCode = (item.BranchCode != null) ? item.BranchCode : string.Empty,
                            Title = item.Title,
                            Description = item.Description,
                            AdditionalDesc = item.AdditionalDesc,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            ChangedBy = item.ChangedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedOn = item.ChangedOn,
                            CreatedOnString = item.CreatedOn.ToERPdate(),
                            ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                            BannerImageFileName = item.BannerImageFileName,
                            BannerImageFilePath = item.BannerImageFilePath,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CBANNERIMAGE, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::B2CBannerImage GetbyCode(GE::ERPInputmodel inputdata)
        {
            string Uomname = string.Empty;
            string URL_ImgPath = string.Empty;
            GE::B2CBannerImage _data = new GE.B2CBannerImage();
            try
            {
                var item = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.BannerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    if (!string.IsNullOrEmpty(item.BannerImageFilePath))
                    {
                        URL_ImgPath = item.BannerImageFilePath.Replace("C:\\APPEXPERTS\\", IP_FilePath).Replace(@"\", "//");
                    }
                    else
                    {
                        item.BannerImageFileName = "NoImage.jpg";
                        URL_ImgPath = "/Content/images/NoImage.jpg";
                    }
                    _data = (new GE.B2CBannerImage
                    {
                        OrgId = item.OrgId,
                        BannerId = item.BannerId,
                        BranchCode = (item.BranchCode != null) ? item.BranchCode : string.Empty,
                        Title = item.Title,
                        Description = item.Description,
                        AdditionalDesc = item.AdditionalDesc,
                        DisplayOrder = item.DisplayOrder,
                        IsActive = item.IsActive,
                        CreatedBy = item.CreatedBy,
                        ChangedBy = item.ChangedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedOn = item.ChangedOn,
                        CreatedOnString = item.CreatedOn.ToERPdate(),
                        ChangedOnString = (item.ChangedOn != null) ? item.ChangedOn.Value.ToERPdate() : string.Empty,
                        BannerImageFileName = item.BannerImageFileName,
                        BannerImageFilePath = URL_ImgPath,

                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CBANNERIMAGE, inputdata.OrganisationId);
            }
            return _data;
        }
        // Create or Update
        public string Save(GE::B2CBannerImage item, string user, int OrganizationId)
        {
            OrgId = OrganizationId;
            string result = string.Empty;
            string Img_path = string.Empty;
            string URL_ImgPath = string.Empty;
            try
            {
                if (item != null)
                {
                    //Create Physical Image from Byte
                    if (strFileHosted == "IIS")
                    {
                        if (item.BanneImage != null && !string.IsNullOrEmpty(item.BannerImageFileName))
                        {                           
                            byte[] byteImg = item.BanneImage;
                            Img_path = WriteFile(strFilepath + "BANNERIMAGES", item.BannerImageFileName, byteImg);
                            if (!string.IsNullOrEmpty(Img_path))
                            {
                                URL_ImgPath = Img_path.Replace(localImageFilePath, IP_FilePath).Replace(@"\", "//");
                            }
                        }
                    }

                    if (strFileHosted == "P")
                    {
                        //Create Physical Image from Byte
                        if (item.BannerImageFileName != null && !string.IsNullOrEmpty(item.BannerImg_Base64String))
                        {

                            byte[] byteImg = System.Convert.FromBase64String(item.BannerImg_Base64String);
                            string aa = strFilepath2;

                            //Img_path = strFilepath2 + "BANNERIMAGES\\" + item.BannerImageFileName;
                            Img_path = WriteFile(strFilepath2 + "BANNERIMAGES", item.BannerImageFileName, byteImg);
                            if (!string.IsNullOrEmpty(Img_path))
                            {
                                URL_ImgPath = Img_path.Replace(localImageFilePath, IP_FilePath2).Replace(@"\", "//");
                            }
                        }    
                    }

                    var _data = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.BannerId == item.BannerId && o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.OrgId = item.OrgId;
                        _data.BranchCode = item.BranchCode;
                        _data.BannerId = item.BannerId;
                        _data.Title = item.Title;
                        _data.Description = item.Description;
                        _data.AdditionalDesc = item.AdditionalDesc;
                        _data.DisplayOrder = item.DisplayOrder;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        if (item.BanneImage != null && !string.IsNullOrEmpty(item.BannerImageFileName))
                        {
                            _data.BannerImageFileName = item.BannerImageFileName == null ? "" : item.BannerImageFileName;
                            _data.BannerImageFilePath = URL_ImgPath == null ? string.Empty : URL_ImgPath;

                        }
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.BannerId))                       
                            item.BannerId = GenerateCode();
                        B2C_BannerImage banner = new B2C_BannerImage()
                        {
                            OrgId = item.OrgId,
                            BannerId = item.BannerId,
                            BranchCode = (item.BranchCode != null) ? item.BranchCode : string.Empty,
                            Title = item.Title,
                            Description = item.Description,
                            AdditionalDesc = item.AdditionalDesc,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            BannerImageFileName = item.BannerImageFileName,
                            BannerImageFilePath = URL_ImgPath,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().B2C_BannerImage.Add(banner);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, B2CBANNERIMAGE, OrganizationId);
            }
            return result;
        }

        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.BannerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CBANNERIMAGE, inputdata.OrganisationId);
            }
            return result;
        }       

        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_BannerImage.FirstOrDefault(o => o.BannerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CBANNERIMAGE, inputdata.OrganisationId);
            }
            return result;
        }
        public DirectoryInfo GetCreateMyFolder(string baseFolder, string subFolder, DateTime CreateDate)
        {
            var now = DateTime.Now;
            var dayName = now.ToString("dd-MM-yyyy");
            var sFolder = subFolder.ToUpper().Trim();
            //var Year = "";//CreateDate.Year.ToString();
            //var Month = "";// CreateDate.ToString("MMM").ToUpper().Trim();//CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(UploadDate.Month);

            var folder = Path.Combine(baseFolder, dayName);
            folder = Path.Combine(folder, sFolder);
            //folder = Path.Combine(folder, Year);
            //folder = Path.Combine(folder, Month);

            bool IsExists = System.IO.Directory.Exists(folder);

            if (!IsExists)
            {
                System.IO.Directory.CreateDirectory(folder);
                FileSecurity fSec = File.GetAccessControl(folder);
                fSec.AddAccessRule(new FileSystemAccessRule("Everyone", FileSystemRights.FullControl, AccessControlType.Allow));
                File.SetAccessControl(folder, fSec);
            }
            DirectoryInfo dInfo = new DirectoryInfo(folder);
            return dInfo;
        }

        public bool IsBase64String(string base64)
        {
            base64 = base64.Trim();
            return (base64.Length % 4 == 0) && Regex.IsMatch(base64, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);
        }
        public byte[] ConvertFileToByte(string filename)
        {
            try
            {
                FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);

                // Create a byte array of file stream length
                byte[] ImageData = new byte[fs.Length];

                //Read block of bytes from stream into the byte array
                fs.Read(ImageData, 0, System.Convert.ToInt32(fs.Length));

                //Close the File Stream
                fs.Close();
                return ImageData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string ConvertFileToBaseString(string filename)
        {
            string Base64String = string.Empty;
            try
            {
                if (File.Exists(filename))
                {
                    Byte[] bytes = File.ReadAllBytes(filename);
                    Base64String = Convert.ToBase64String(bytes);
                }
                return Base64String;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public string GetStringfrombyte(byte[] ImageArray)
        {
            string imgDataURL = string.Empty;
            if (ImageArray != null)
            {
                string imreBase64Data = Convert.ToBase64String(ImageArray);
                imgDataURL = string.Format("data:image/png;base64,{0}", imreBase64Data);
            }
            return imgDataURL;
        }
        public string GenerateCode()
        {
           
            // Get the last updated record from your data source
            var lastRecord = ERPMASTERDatabase().B2C_BannerImage.OrderByDescending(o => o.ChangedOn).FirstOrDefault();

            // Get the last used code from the last record or use a default value
            var lastCode = lastRecord?.BannerId ?? "000000";

            // Convert the last code to an integer
            int lastNumber = int.Parse(lastCode);

            // Increment the last number
            int nextNumber = lastNumber + 1;

            // Convert the next number back to a 6-digit string
            string nextCode = nextNumber.ToString("D6");

            return nextCode;
        }
    }
}
