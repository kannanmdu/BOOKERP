﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class B2CContactEnquiryDA : CommonDA
    {
        // Get All
        public List<GE::B2CContactEnquiry> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CContactEnquiry> _list = new List<GE.B2CContactEnquiry>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_ContactEnqiry.Where(o => o.OrgId == inputdata.OrganisationId).OrderBy(o => o.CreatedOn).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.B2CContactEnquiry
                        {
                            OrgId = item.OrgId,
                            ContactEntryId = item.ContactEntryId,
                            ContactPersonName = item.ContactPersonName,
                            MobileNo = item.MobileNo,
                            EmailId = item.EmailId,
                            Subject = item.Subject,
                            RequestMessage = item.RequestMessage,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,


                        });
                    });

                }

            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::B2CContactEnquiry GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::B2CContactEnquiry _data = new GE.B2CContactEnquiry();
            try
            {
                var item = ERPMASTERDatabase().B2C_ContactEnqiry.FirstOrDefault(o => o.ContactEntryId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.B2CContactEnquiry
                    {
                        OrgId = item.OrgId,
                        ContactEntryId = item.ContactEntryId,
                        ContactPersonName = item.ContactPersonName,
                        MobileNo = item.MobileNo,
                        EmailId = item.EmailId,
                        Subject = item.Subject,
                        RequestMessage = item.RequestMessage,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                    });
                }
            }
            catch (Exception ex)
            {
                // new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _data;
        }

        public string Save(GE::B2CContactEnquiry item, string user, int OrganizationId)
        {
            string result = string.Empty;
            string strEnquiryId = string.Empty;

            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().B2C_ContactEnqiry.FirstOrDefault(o => o.ContactEntryId == item.ContactEntryId && o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.OrgId = item.OrgId;
                        _data.ContactEntryId = item.ContactEntryId;
                        _data.ContactPersonName = item.ContactPersonName;
                        _data.EmailId = item.EmailId;
                        _data.MobileNo = item.MobileNo;
                        _data.Subject = item.Subject;
                        _data.RequestMessage = item.RequestMessage;

                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        strEnquiryId = getRandomNumber();
                        //if (string.IsNullOrEmpty(item.CustomerGroupCode))
                        //{
                        //    item.CustomerGroupCode = GetAutoIncrement(CUSTOMERGROUP);
                        //    UpdateAutoIncrement(CUSTOMERGROUP);
                        //}
                        B2C_ContactEnqiry _CGroup = new B2C_ContactEnqiry()
                        {
                            OrgId = item.OrgId,
                            ContactEntryId = strEnquiryId,
                            ContactPersonName = item.ContactPersonName,
                            MobileNo = item.MobileNo,
                            EmailId = item.EmailId,
                            Subject = item.Subject,
                            RequestMessage = item.RequestMessage,

                            CreatedOn = DateTime.Now,
                            CreatedBy = user,

                        };
                        ERPMASTERDatabase().B2C_ContactEnqiry.Add(_CGroup);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, user, BRANCH, OrganizationId);
            }

            return result;
        }
        public string getRandomNumber()
        {
            Random random = new Random();
            string randomNumber = random.Next(100000).ToString("D6");
            return randomNumber;
        }
    }
}
