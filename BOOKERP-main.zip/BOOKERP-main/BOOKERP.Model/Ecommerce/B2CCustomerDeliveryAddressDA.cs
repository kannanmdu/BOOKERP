﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class B2CCustomerDeliveryAddressDA : CommonDA
    {
        // Get All
        public List<GE::B2CCustomerDeliveryAddress> GetAll(string CustomerId, int OrganizationId)
        {
            List<GE::B2CCustomerDeliveryAddress> _list = new List<GE.B2CCustomerDeliveryAddress>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Where(o => o.CustomerId == CustomerId && o.IsActive == true && o.OrgId == OrganizationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.B2CCustomerDeliveryAddress
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            DeliveryId = item.DeliveryId,
                            Name = item.Name,
                            AddressLine1 = item.AddressLine1,
                            FloorNo = item.FloorNo,
                            UnitNo = item.UnitNo,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            CountryId = item.CountryId,
                            PostalCode = item.PostalCode,
                            Mobile = item.Mobile,
                            Phone = item.Phone,
                            Fax = item.Fax,
                            IsDefault = item.IsDefault,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn
                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, "", CUSTOMER, OrganizationId);
            }
            return _list;
        }

        public GE::B2CCustomerDeliveryAddress GetbyCode(string user, string CustomerId, int DeliveryId, int OrganizationId)
        {
            GE::B2CCustomerDeliveryAddress _list = new GE.B2CCustomerDeliveryAddress();
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Where(o => o.CustomerId == CustomerId && o.IsActive == true && o.OrgId == OrganizationId && o.DeliveryId == DeliveryId).FirstOrDefault();
                if (item != null)
                {
                    _list = (new GE.B2CCustomerDeliveryAddress
                    {
                        OrgId = item.OrgId,
                        CustomerId = item.CustomerId,
                        DeliveryId = item.DeliveryId,
                        Name = item.Name,
                        AddressLine1 = item.AddressLine1,
                        FloorNo = item.FloorNo,
                        UnitNo = item.UnitNo,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        Mobile = item.Mobile,
                        Phone = item.Phone,
                        Fax = item.Fax,
                        IsDefault = item.IsDefault,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CUSTOMER, OrganizationId);
            }
            return _list;
        }

        // Create or Update
        public string Save(GE::B2CCustomerDeliveryAddress item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.FirstOrDefault(o => o.CustomerId == item.CustomerId && o.DeliveryId == item.DeliveryId && o.OrgId == item.OrgId);
                    if (_data != null)
                    {
                        _data.Name = item.Name;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.FloorNo = item.FloorNo;
                        _data.UnitNo = item.UnitNo;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.CountryId = item.CountryId;
                        _data.PostalCode = item.PostalCode;
                        _data.Mobile = item.Mobile;
                        _data.Phone = item.Phone;
                        _data.Fax = item.Fax;
                        _data.IsDefault = item.IsDefault;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        if (item.IsDefault == true)
                        {

                            var _data2 = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Where(o => o.CustomerId == item.CustomerId && o.DeliveryId != item.DeliveryId && o.OrgId == item.OrgId).ToList();
                            if (_data2 != null)
                            {
                                _data2.ForEach(item2 =>
                                {
                                    item2.IsDefault = false;
                                    ERPMASTERDatabase().SaveChanges();
                                });

                            }
                        }
                        result = PASS;



                    }
                    else
                    {
                        if (item.IsDefault == true)
                        {

                            var _data2 = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Where(o => o.CustomerId == item.CustomerId && o.OrgId == item.OrgId).ToList();
                            if (_data2 != null)
                            {
                                _data2.ForEach(item2 =>
                                {
                                    item2.IsDefault = false;
                                    ERPMASTERDatabase().SaveChanges();
                                });

                            }
                        }

                        B2C_CustomerDeliveryAddress deliveryAddress = new B2C_CustomerDeliveryAddress()
                        {

                            OrgId = item.OrgId,
                            DeliveryId = GetMaxID(B2CCUSTOMERDELIVERY, item.OrgId),
                            CustomerId = item.CustomerId,
                            Name = item.Name,
                            AddressLine1 = item.AddressLine1,
                            FloorNo = item.FloorNo,
                            UnitNo = item.UnitNo,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            CountryId = item.CountryId,
                            PostalCode = item.PostalCode,
                            Mobile = item.Mobile,
                            Phone = item.Phone,
                            Fax = item.Fax,
                            IsDefault = item.IsDefault,
                            IsActive = item.IsActive,
                            ChangedBy = user,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            CreatedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Add(deliveryAddress);
                        ERPMASTERDatabase().SaveChanges();


                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CUSTOMER, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.FirstOrDefault(o => o.DeliveryId == inputdata.TransNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Remove(item);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CUSTOMER, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
