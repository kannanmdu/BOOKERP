﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Data.Entity.Validation;
//using System.Net.Mail;
//using System.Net;
//using GE = BOOKERP.Entities;
//using BOOKERP.Utility;
//using Dapper;
//using System.Data;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using System.Data.Entity.Validation;
using System.Net.Mail;
using System.Net;
using BOOKERP.Utility;
using Dapper;
using System.Data;

namespace BOOKERP.Model
{
    public class B2CCustomerRegisterDA : CommonDA
    {
        // Get All
        public List<GE::GetB2CCustomerRegister> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::GetB2CCustomerRegister> _list = new List<GE.GetB2CCustomerRegister>();
            try
            {
                var query = "SP_GetB2CCustomerRegister";                
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@IsActive", inputdata.IsActive);
                var list = SqlMapper.Query<GE.GetB2CCustomerRegister>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                _list = list.ToList();               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::GetB2CCustomerRegister GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::GetB2CCustomerRegister _data = new GE.GetB2CCustomerRegister();
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    List<GE::B2CCustomerOrder> Order = new B2CCustomerOrderDA().GetOrderbyCode(inputdata, item.B2CCustomerId);
                    List<GE::B2CCustomerDeliveryAddress> Address = GetCustomerDeliveryAddressAll(item.B2CCustomerId, inputdata.OrganisationId);
                    if (item != null)
                    {
                        _data = (new GE.GetB2CCustomerRegister
                        {
                            OrgId = item.OrgId,
                            BranchCode = item.BranchCode,
                            B2CCustomerId = item.B2CCustomerId,
                            B2CCustomerName = item.B2CCustomerName,
                            EmailId = item.EmailId,
                            Password = !string.IsNullOrEmpty(item.Password) ? GetDeCodedvalue(item.Password) : item.Password,
                            AddressLine1 = item.AddressLine1,
                            FloorNo = item.FloorNo,
                            UnitNo = item.UnitNo,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            CountryId = item.CountryId,
                            PostalCode = item.PostalCode,
                            MobileNo = item.MobileNo,
                            IsApproved = item.IsApproved,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            Orders = Order,
                            Address = Address
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return _data;
        }

        public List<GE::B2CCustomerDeliveryAddress> GetCustomerDeliveryAddressAll(string CustomerId, int OrganizationId)
        {
            List<GE::B2CCustomerDeliveryAddress> _list = new List<GE.B2CCustomerDeliveryAddress>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Where(o => o.CustomerId == CustomerId && o.IsActive == true && o.OrgId == OrganizationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.B2CCustomerDeliveryAddress
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            DeliveryId = item.DeliveryId,
                            Name = item.Name,
                            AddressLine1 = item.AddressLine1,
                            FloorNo = item.FloorNo,
                            UnitNo = item.UnitNo,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            CountryId = item.CountryId,
                            PostalCode = item.PostalCode,
                            Mobile = item.Mobile,
                            Phone = item.Phone,
                            Fax = item.Fax,
                            IsDefault = item.IsDefault,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, B2CCUSTOMER, OrganizationId);
            }
            return _list;
        }
        // Get by Code
        public GE::B2CCustomerRegister GetbyEmail(GE::ERPInputmodel inputdata)
        {
            GE::B2CCustomerRegister _data = new GE.B2CCustomerRegister();
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.EmailId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.B2CCustomerRegister
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        B2CCustomerId = item.B2CCustomerId,
                        B2CCustomerName = item.B2CCustomerName,
                        EmailId = item.EmailId,
                        Password = item.Password,
                        AddressLine1 = item.AddressLine1,
                        FloorNo = item.FloorNo,
                        UnitNo = item.UnitNo,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        MobileNo = item.MobileNo,
                        IsApproved = item.IsApproved,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return _data;
        }
        // Get by Code
        public GE::B2CCustomerRegister GetbyLogin(GE::LoginModel loginModel)
        {
            GE::B2CCustomerRegister _data = new GE.B2CCustomerRegister();
            try
            {
                string password = GetEncodedvalue(loginModel.Password);
                var item = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.EmailId == loginModel.Username && o.Password == password && o.OrgId == loginModel.OrgId);
                if (item != null)
                {
                    _data = (new GE.B2CCustomerRegister
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        B2CCustomerId = item.B2CCustomerId,
                        B2CCustomerName = item.B2CCustomerName,
                        EmailId = item.EmailId,
                        AddressLine1 = item.AddressLine1,
                        FloorNo = item.FloorNo,
                        UnitNo = item.UnitNo,
                        AddressLine2 = item.AddressLine2,
                        AddressLine3 = item.AddressLine3,
                        CountryId = item.CountryId,
                        PostalCode = item.PostalCode,
                        MobileNo = item.MobileNo,
                        IsApproved = item.IsApproved,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, loginModel.Username, B2CCUSTOMER, loginModel.OrgId);
            }
            return _data;
        }
        public string Save(GE::B2CCustomerRegister item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == item.B2CCustomerId && o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.BranchCode = item.BranchCode;
                        _data.B2CCustomerName = item.B2CCustomerName;
                        _data.EmailId = item.EmailId;
                        _data.Password = GetEncodedvalue(item.Password);
                        _data.AddressLine1 = item.AddressLine1;
                        _data.FloorNo = item.FloorNo;
                        _data.UnitNo = item.UnitNo;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.CountryId = item.CountryId;
                        _data.PostalCode = item.PostalCode;
                        _data.MobileNo = item.MobileNo;
                        _data.IsApproved = item.IsApproved;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;   
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.B2CCustomerId))
                            item.B2CCustomerId = GetMasterNextNo(OrganizationId, B2CCUSTOMER);
                        try
                        {
                            B2C_CustomerRegister customer = new B2C_CustomerRegister()
                            {
                                OrgId = OrganizationId,
                                BranchCode = item.BranchCode,
                                B2CCustomerId = item.B2CCustomerId,
                                B2CCustomerName = item.B2CCustomerName,
                                EmailId = item.EmailId,
                                Password = GetEncodedvalue(item.Password),
                                AddressLine1 = item.AddressLine1,
                                FloorNo = item.FloorNo.Trim(),
                                UnitNo = item.UnitNo.Trim(),
                                AddressLine2 = item.AddressLine2,
                                AddressLine3 = item.AddressLine3,
                                CountryId = item.CountryId,
                                PostalCode = item.PostalCode,
                                MobileNo = item.MobileNo,
                                IsApproved = item.IsApproved,
                                IsActive = item.IsActive,
                                ChangedBy = user,
                                ChangedOn = DateTime.Now,
                                CreatedBy = user,
                                CreatedOn = DateTime.Now
                            };
                            ERPMASTERDatabase().B2C_CustomerRegister.Add(customer);
                            ERPMASTERDatabase().SaveChanges();
                            result = PASS;

                            B2C_CustomerDeliveryAddress deliveryAddress = new B2C_CustomerDeliveryAddress()
                            {

                                OrgId = OrganizationId,
                                DeliveryId = GetMaxID(B2CCUSTOMERDELIVERY, OrganizationId),
                                CustomerId = item.B2CCustomerId,
                                Name = item.B2CCustomerName,
                                AddressLine1 = item.AddressLine1,
                                FloorNo = item.FloorNo,
                                UnitNo = item.UnitNo,
                                AddressLine2 = item.AddressLine2,
                                AddressLine3 = item.AddressLine3,
                                CountryId = item.CountryId,
                                PostalCode = item.PostalCode,
                                Mobile = item.MobileNo,
                                Phone = item.MobileNo,
                                Fax = item.MobileNo,
                                IsDefault = true,
                                IsActive = item.IsActive,
                                ChangedBy = user,
                                CreatedBy = user,
                                ChangedOn = DateTime.Now,
                                CreatedOn = DateTime.Now
                            };
                            ERPMASTERDatabase().B2C_CustomerDeliveryAddress.Add(deliveryAddress);
                            ERPMASTERDatabase().SaveChanges();
                            result = PASS;
                        }
                        catch (DbEntityValidationException e)
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, B2CCUSTOMER, OrganizationId);
            }
            return result;
        }
        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = inputdata.IsActive;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return result;
        }

        public string EditProfile(GE::B2CEditProfile item)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == item.B2CCustomerId && o.OrgId == item.OrgId);
                    if (_data != null)
                    {
                        _data.B2CCustomerName = item.B2CCustomerName;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.PostalCode = item.PostalCode;
                        _data.CountryId = item.CountryId;
                        _data.MobileNo = item.MobileNo;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = item.B2CCustomerId;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, B2CCUSTOMER, 0);
            }
            return result;
        }
        public string EditProfilePassword(GE::B2CChangePassword item)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(item.Password) && item.Password == "string")                
                    item.Password = string.Empty;
                var _data = new B2C_CustomerRegister();
                if (!string.IsNullOrEmpty(item.B2CCustomerId))
                    _data = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.B2CCustomerId == item.B2CCustomerId && o.OrgId == item.OrgId);
                else
                    _data = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.EmailId == item.EmailId && o.OrgId == item.OrgId);

                if (_data != null)
                {
                    if (!string.IsNullOrEmpty(item.Password))
                    {
                        _data.Password = GetEncodedvalue(item.Password);
                    }
                    _data.ChangedOn = DateTime.Now;
                    _data.ChangedBy = item.B2CCustomerId;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, B2CCUSTOMER, item.OrgId);
            }
            return result;
        }
        public string SendOTP(int OrgId, string OrgName, string Email)
        {
            string strNewPassword = Generate_otp();
            var org = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == OrgId).OrgName;
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("appxpertmail@gmail.com");
            msg.To.Add(Email); 
            msg.Subject = "B2C Activation Code";
            msg.Body = "Company Name : " + org + "<br/>" +
                       "Your OTP is: " + "<b>" + strNewPassword + "</b>";
            msg.IsBodyHtml = true;

            using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
            {
                smtp.Credentials = new NetworkCredential("appxpertmail@gmail.com", "qplldsxjcpqfypjm");
                smtp.EnableSsl = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(msg);
            }
            return strNewPassword;
        }
        public static string Generate_otp()
        {
            char[] charArr = "0123456789".ToCharArray();
            string strrandom = string.Empty;
            Random objran = new Random();
            for (int i = 0; i < 4; i++)
            {
                //It will not allow Repetation of Characters
                int pos = objran.Next(1, charArr.Length);
                if (!strrandom.Contains(charArr.GetValue(pos).ToString())) strrandom += charArr.GetValue(pos);
                else i--;
            }
            return strrandom;
        }
        public string ForgetPassword(int OrganisationId, string Email, string user)
        {
            string result = string.Empty;
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerRegister.FirstOrDefault(o => o.OrgId == OrganisationId && o.EmailId == Email);
                if (_data != null)
                {
                    string password = System.Web.Security.Membership.GeneratePassword(8, 1);

                    if (!string.IsNullOrEmpty(password))
                    {
                        _data.Password = GetEncodedvalue(password);

                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        string value = sendemailtoCustomer(OrganisationId, Email, user, password);
                        if (value == "Success")
                            result = PASS;
                        else
                            result = FAIL;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CUSTOMER, OrganisationId);
            }
            return result;
        }
        public string sendemailtoCustomer(int organisationid, string email, string user, string password)
        {
            string result = string.Empty;
            try
            {
                var companydetails = ERPMASTERDatabase().Master_Organization.FirstOrDefault(o => o.OrgId == organisationid);
                var customer = ERPMASTERDatabase().B2C_CustomerRegister.First(o => o.OrgId == organisationid && o.EmailId == email);
                if (customer != null)
                {
                    string customername = customer.B2CCustomerName;
                    string to = string.Empty;
                    if (!string.IsNullOrEmpty(email))
                    {
                        to = email.ToString();
                    }

                    //string from = emailsettings.From_email; //From address    
                    MailMessage message = new MailMessage();
                    message.From = new MailAddress("appxpertmail@gmail.com");
                    message.To.Add(to);

                    string mailbody = "Company Name : " + companydetails.OrgName + "<br/>" +
                               "Customer Name:" + customer.B2CCustomerName + "<br>" +
                               "Your New Password is: " + "<b>" + password + "</b>";
                    message.Subject = "New Password";
                    message.Body = mailbody;
                    message.BodyEncoding = Encoding.UTF8;
                    message.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtp.Credentials = new System.Net.NetworkCredential("appxpertmail@gmail.com", "qplldsxjcpqfypjm");
                        smtp.EnableSsl = true;
                        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtp.Send(message);
                    }                    
                    result = "Success";
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, B2CCUSTOMER, organisationid);
            }
            return result;
        }
        public string GetEncodedvalue(string code)
        {
            return (Encrypt.Get(code));
        }
        public string GetDeCodedvalue(string code)
        {
            return (Decrypt.Get(code));
        }
    }
}
