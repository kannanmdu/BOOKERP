﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class CustomerWishListDA : CommonDA
    {
        // Get All
        public List<GE::CustomerWishList> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::CustomerWishList> _list = new List<GE.CustomerWishList>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerWishList.Where(o => o.OrgId == inputdata.OrganisationId).OrderBy(o => o.ProductName).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.CustomerWishList
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,


                        });
                    });

                }

            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::CustomerWishList> GetAllActive(GE::ERPInputmodel inputdata)
        {
            List<GE::CustomerWishList> _list = new List<GE.CustomerWishList>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerWishList.Where(o => o.IsActive == true && o.OrgId == inputdata.OrganisationId).OrderBy(o => o.ProductName).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.CustomerWishList
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,


                        });
                    });

                }

            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get All
        public List<GE::CustomerWishList> GetByCustomer(GE::ERPInputmodel inputdata)
        {
            List<GE::CustomerWishList> _list = new List<GE.CustomerWishList>();
            try
            {
                var _data = ERPMASTERDatabase().B2C_CustomerWishList.Where(o => o.OrgId == inputdata.OrganisationId && o.CustomerId == inputdata.CustomerCode).OrderBy(o => o.ProductName).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.CustomerWishList
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ProductImage = item.ProductImage,
                            SellingPrice = item.SellingPrice


                        });
                    });

                }

            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::CustomerWishList GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::CustomerWishList _data = new GE.CustomerWishList();
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerWishList.FirstOrDefault(o => o.CustomerId == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.CustomerWishList
                    {
                        OrgId = item.OrgId,
                        CustomerId = item.CustomerId,
                        ProductCode = item.ProductCode,
                        ProductName = item.ProductName,
                        IsActive = item.IsActive,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ProductImage = item.ProductImage,
                        SellingPrice = item.SellingPrice
                    });
                }
            }
            catch (Exception ex)
            {
                // new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return _data;
        }

        public string Save(GE::CustomerWishList item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().B2C_CustomerWishList.FirstOrDefault(o => o.CustomerId == item.CustomerId && o.ProductCode == item.ProductCode && o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.OrgId = item.OrgId;
                        _data.CustomerId = item.CustomerId;
                        _data.ProductCode = item.ProductCode;
                        _data.ProductCode = item.ProductCode;
                        _data.IsActive = item.IsActive;
                        _data.CreatedOn = DateTime.Now;
                        _data.CreatedBy = user;


                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {

                        B2C_CustomerWishList _WisList = new B2C_CustomerWishList()
                        {
                            OrgId = item.OrgId,
                            CustomerId = item.CustomerId,
                            ProductCode = item.ProductCode,
                            ProductName = item.ProductName,
                            IsActive = item.IsActive,

                            CreatedOn = DateTime.Now,
                            CreatedBy = user,

                        };
                        ERPMASTERDatabase().B2C_CustomerWishList.Add(_WisList);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, user, BRANCH, OrganizationId);
            }

            return result;
        }
        //Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerWishList.FirstOrDefault(o => o.CustomerId == inputdata.CustomerCode && o.ProductCode == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {

                    ERPMASTERDatabase().B2C_CustomerWishList.Remove(item);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return result;
        }

        //Delete
        public string ActiveInActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerWishList.FirstOrDefault(o => o.CustomerId == inputdata.CustomerCode && o.ProductCode == inputdata.TransactionNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = inputdata.IsActive;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                //new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BRANCH, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
