﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class B2CCustomerOrderDA : CommonDA
    {
        // Get All
        public List<GE::B2CCustomerOrder> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CCustomerOrder> _list = new List<GE.B2CCustomerOrder>();
            try
            {
                var query = "SP_GetB2CCustomerOrder";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@CustomerCode", inputdata.CustomerCode);
                var list = SqlMapper.Query<GE.B2CCustomerOrder>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                _list = list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMERORDER, inputdata.OrganisationId);
            }
            return _list;
        }
        public List<GE::B2CCustomerOrder> GetOrderbyCode(GE::ERPInputmodel inputdata, string CustomerCode)
        {
            List<GE::B2CCustomerOrder> _list = new List<GE.B2CCustomerOrder>();
            try
            {
                var query = "SP_GetB2CCustomerOrder";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@CustomerCode", CustomerCode);
                var list = SqlMapper.Query<GE.B2CCustomerOrder>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                _list = list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMERORDER, inputdata.OrganisationId);
            }
            return _list;
        }

        public List<GE::B2CCustomerOrder> GetHeaderbySearch(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CCustomerOrder> _list = new List<GE.B2CCustomerOrder>();
            try
            {
                var query = "SP_GetB2CCustomerOrder";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@CustomerCode", inputdata.CustomerCode);
                var list = SqlMapper.Query<GE.B2CCustomerOrder>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                _list = list.ToList();
                if (!string.IsNullOrEmpty(inputdata.FromDateString) && !string.IsNullOrEmpty(inputdata.ToDateString))
                {
                    DateTime? _Fromdate = !string.IsNullOrEmpty(inputdata.FromDateString) ? inputdata.FromDateString.GetERPDateFormat() : DateTime.Now;
                    DateTime? _Todate = !string.IsNullOrEmpty(inputdata.ToDateString) ? inputdata.ToDateString.GetERPDateFormat() : DateTime.Now;
                    _list = _list.Where(o => o.OrderDate >= _Fromdate && o.OrderDate <= _Todate).ToList();
                }
                GetConnection.Close();      
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMERORDER, inputdata.OrganisationId);
            }
            return _list;
        }

        public string Save(GE::B2CCustomerOrder header, List<GE::B2CCustomerOrderDetail> details, string user)
        {
            string Result = string.Empty;
            try
            {               
                if (string.IsNullOrEmpty(header.OrderNo))
                    header.OrderNo = GetTransactionNumber("B2COrder", header.BranchCode, header.OrgId);
                using (var connection = GetConnection)
                {
                    ListtoDataTableConverter converter = new ListtoDataTableConverter();
                    DataTable dt = converter.ToDataTable(details);
                    dt.Columns.Remove("OrgId");
                    dt.Columns.Remove("OrderNo");
                    dt.Columns.Remove("CreatedBy");
                    dt.Columns.Remove("CreatedOn");
                    dt.Columns.Remove("ChangedOn");
                    dt.Columns.Remove("ChangedBy");

                    string TranNo = Save(header, user, dt);
                    Result = TranNo;
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, B2CCUSTOMERORDER, header.OrgId);
            }
            return Result;
        }
        public string Save(GE::B2CCustomerOrder item, string user, DataTable details)
        {
            string result = string.Empty;
            try
            {
                var query = "SP_SaveB2CustomerOrder";
                var param = new DynamicParameters();
                param.Add("@OrgId", item.OrgId);
                param.Add("@BranchCode", item.BranchCode);
                param.Add("@OrderNo", item.OrderNo);
                param.Add("@OrderDate", item.OrderDate);
                param.Add("@CustomerId", item.CustomerId);
                param.Add("@CustomerName", item.CustomerName);
                param.Add("@CustomerAddress", item.CustomerAddress);
                param.Add("@PostalCode", item.PostalCode);
                param.Add("@TaxCode", item.TaxCode);
                param.Add("@TaxType", item.TaxType);
                param.Add("@TaxPerc", item.TaxPerc);
                param.Add("@CurrencyCode", item.CurrencyCode);
                param.Add("@CurrencyRate", item.CurrencyRate);
                param.Add("@Total", item.Total);
                param.Add("@BillDiscount", item.BillDiscount);
                param.Add("@BillDiscountPerc", item.BillDiscountPerc);
                param.Add("@SubTotal", item.SubTotal);
                param.Add("@Tax", item.Tax);
                param.Add("@NetTotal", item.NetTotal);
                param.Add("@PaymentType", item.PaymentType);
                param.Add("@PaidAmount", item.PaidAmount);
                param.Add("@Remarks", item.Remarks);
                param.Add("@IsActive", item.IsActive);
                param.Add("@Status", item.Status);
                param.Add("@CustomerShipToId", item.CustomerShipToId);
                param.Add("@CustomerShipToAddress", item.CustomerShipToAddress);
                param.Add("@Latitude", item.Latitude);
                param.Add("@Longitude", item.Longitude);
                param.Add("@Signatureimage", item.Signatureimage);
                param.Add("@Cameraimage", item.Cameraimage);
                param.Add("@CreatedFrom", item.CreatedFrom);
                param.Add("@DeliveryAmount", item.DeliveryAmount);
                param.Add("@User", user);
                param.Add("@Detail", details, DbType.Object);

                var list = SqlMapper.ExecuteScalar(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (list != null)
                {
                    result = list.ToString();
                }
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, B2CCUSTOMERORDER, item.OrgId);
                GetConnection.Close();
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMERORDER, inputdata.OrganisationId);
            }
            return result;
        }
        public GE::B2CCustomerOrder GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::B2CCustomerOrder _data = new GE.B2CCustomerOrder();
            List<GE::B2CCustomerOrderDetail> _list = new List<GE.B2CCustomerOrderDetail>();
            try
            {
                var Header = "SP_GetEditB2CCustomerOrder";
                var Detail = "SP_GetEditB2CCustomerOrderDetail";
                var headerParam = new DynamicParameters();

                headerParam.Add("@OrgId", inputdata.OrganisationId);
                headerParam.Add("@OrderNo", inputdata.TranNo);

                _data = SqlMapper.QueryFirst<GE.B2CCustomerOrder>(GetConnection, Header, headerParam, commandType: CommandType.StoredProcedure);
                var detailList = SqlMapper.Query<GE::B2CCustomerOrderDetail>(GetConnection, Detail, headerParam, commandType: CommandType.StoredProcedure);
                _data.OrderDetail = detailList.ToList();                
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMERORDER, inputdata.OrganisationId);
            }
            return _data;
        }
        public List<GE::B2CCustomerOrder> GetSearchData(GE::ERPInputmodel inputdata)
        {
            List<GE::B2CCustomerOrder> _list = new List<GE.B2CCustomerOrder>();
            try
            {
                var query = "SP_GetB2CCustomerOrder";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@CustomerCode", inputdata.CustomerCode);
                var list = SqlMapper.Query<GE.B2CCustomerOrder>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::B2CCustomerOrder GetB2CCustomerOrderCode(string tranNo)
        {
            GE::B2CCustomerOrder _list = new GE.B2CCustomerOrder();
            try
            {
                var _data = (from a in ERPMASTERDatabase().B2C_CustomerOrder.Where(o => o.IsActive == true)
                             join b in ERPMASTERDatabase().B2C_CustomerRegister
                             on a.CustomerId equals b.B2CCustomerId
                             where a.OrderNo == tranNo
                             select new { a.OrderNo, a.OrderDate, a.OrgId, a.CreatedBy, b.B2CCustomerId, b.B2CCustomerName, a.CustomerAddress, b.EmailId }).FirstOrDefault();

                if (_data != null)
                {
                    _list.OrderNo = _data.OrderNo;
                    _list.OrderDate = _data.OrderDate;
                    _list.CustomerId = _data.B2CCustomerId;
                    _list.CustomerName = _data.B2CCustomerName;
                    _list.CustomerAddress = _data.CustomerAddress;
                    _list.OrgId = _data.OrgId;
                    _list.CreatedBy = _data.CreatedBy;
                    _list.CustomerEmail = _data.EmailId;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, B2CCUSTOMER, 0);
            }
            return _list;
        }
        public string UpdateB2CStatus(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            GE::B2CCustomerOrder _data = new GE.B2CCustomerOrder();
            try
            {
                var item = ERPMASTERDatabase().B2C_CustomerOrder.FirstOrDefault(o => o.OrderNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.Status = Convert.ToInt32(inputdata.Status);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, B2CCUSTOMER, inputdata.OrganisationId);
            }
            return result;
        }
        public string GetStringfrombyte(byte[] ImageArray)
        {
            string imgDataURL = string.Empty;
            if (ImageArray != null)
            {
                string imreBase64Data = Convert.ToBase64String(ImageArray);
                imgDataURL = string.Format("data:image/png;base64,{0}", imreBase64Data);
            }
            return imgDataURL;
        }  
    }
}
