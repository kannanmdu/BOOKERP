﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class EmployeeDA : CommonDA
    {

        public static string strFilepath = System.Configuration.ConfigurationSettings.AppSettings["Filepath"].ToString().Trim();
        public static string IP_FilePath = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath"].ToString().Trim();

        public static string strFilepath2 = System.Configuration.ConfigurationSettings.AppSettings["Filepath2"].ToString().Trim();
        public static string IP_FilePath2 = System.Configuration.ConfigurationSettings.AppSettings["IP_FilePath2"].ToString().Trim();

        public static string strFileHosted = System.Configuration.ConfigurationSettings.AppSettings["IP_FileHosted"].ToString().Trim();
        public static string localImageFilePath = System.Configuration.ConfigurationSettings.AppSettings["LocalImageFilePath"].ToString().Trim();

        // Get the branch details
        public List<GE::HRMSEmployee> GetAll(GE::ERPInputmodel inputData)
        {
            List<GE::HRMSEmployee> _list = new List<GE.HRMSEmployee>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Employee.Where(o => o.OrgId == inputData.OrganisationId && o.IsActive == inputData.IsActive).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSEmployee
                        {
                            OrgId = item.OrgId,
                            EmployeeCode = item.EmployeeCode,
                            EmployeeName = item.EmployeeName,
                            AddressLine1 = item.AddressLine1,
                            AddressLine2 = item.AddressLine2,
                            AddressLine3 = item.AddressLine3,
                            Country = item.Country,
                            PostalCode = item.PostalCode,
                            PhoneNo = item.PhoneNo,
                            MobileNo = item.MobileNo,
                            Fax = item.Fax,
                            Email = item.Email,
                            DOB = item.DOB,
                            Gender = item.Gender,
                            HireDate = item.HireDate,
                            Salary = item.Salary,
                            OTRate = item.OTRate,
                            EmployeeImage = item.EmployeeImage,
                            UserName = item.UserName,
                            Password = item.Password,
                            Roles = item.Roles,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            DOBString = item.DOB.HasValue?item.DOB.Value.ToString("dd/MM/yyyy"):string.Empty,
                            HireDateString = item.HireDate.HasValue ? item.HireDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                            DesignationCode = item.DesignationCode,
                            DepartmentCode = item.DepartmentCode
                            
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return _list;
        }
        //Save and update the branch details
        public string Save(GE::HRMSEmployee item, string user, int organizationId)
        {
            string result = string.Empty;
            string Img_path = string.Empty;
            string URL_ImgPath = string.Empty;
            try
            {
                if (item != null)
                {
                    //Create Physical Image from Byte
                    if (strFileHosted == "IIS")
                    {
                        if (item.EmpImage != null && !string.IsNullOrEmpty(item.FileName))
                        {
                            byte[] byteImg = item.EmpImage;
                            Img_path = WriteFile(strFilepath + "EMPLOYEEIMAGES", item.FileName, byteImg);
                            if (!string.IsNullOrEmpty(Img_path))
                            {
                                URL_ImgPath = Img_path.Replace("C:\\", IP_FilePath).Replace(@"\", "//");
                            }
                        }
                    }

                    if (strFileHosted == "P")
                    {
                        //Create Physical Image from Byte
                        if (item.FileName != null && !string.IsNullOrEmpty(item.Base64String))
                        {

                            byte[] byteImg = System.Convert.FromBase64String(item.Base64String);
                            string aa = strFilepath2;

                            //Img_path = strFilepath2 + "BANNERIMAGES\\" + item.BannerImageFileName;
                            Img_path = WriteFile(strFilepath2 + "EMPLOYEEIMAGES", item.FileName, byteImg);
                            if (!string.IsNullOrEmpty(Img_path))
                            {
                                URL_ImgPath = Img_path.Replace(localImageFilePath, IP_FilePath2).Replace(@"\", "//");
                            }
                        }
                    }

                    var _data = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == item.EmployeeCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.EmployeeName = item.EmployeeName;
                        _data.AddressLine1 = item.AddressLine1;
                        _data.AddressLine2 = item.AddressLine2;
                        _data.AddressLine3 = item.AddressLine3;
                        _data.Country = item.Country;
                        _data.PostalCode = item.PostalCode;
                        _data.MobileNo = item.MobileNo;
                        _data.PhoneNo = item.PhoneNo;
                        _data.Fax = item.Fax;
                        _data.Email = item.Email;
                        _data.DOB = item.DOB;
                        _data.Gender = item.Gender;
                        _data.HireDate = item.HireDate;
                        _data.Salary = item.Salary;
                        _data.OTRate = item.OTRate;
                        _data.EmployeeImage = item.EmployeeImage;
                        _data.UserName = item.UserName;
                        _data.Password = item.Password;
                        _data.Roles = item.Roles;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        _data.DesignationCode = item.DesignationCode;
                        _data.DepartmentCode = item.DepartmentCode;


                        if (item.EmpImage != null && !string.IsNullOrEmpty(item.FileName))
                        {
                            //_data.FileName = item.FileName == null ? "" : item.FileName;
                            _data.EmployeeImage = URL_ImgPath == null ? string.Empty : URL_ImgPath;

                        }
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.EmployeeCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, EMPLOYEE);
                            item.EmployeeCode = autoCode;
                        }
                        HRMS_Employee emp = new HRMS_Employee()
                        {
                            OrgId = organizationId,
                            EmployeeName = item.EmployeeName,
                            EmployeeCode = item.EmployeeCode,
                            AddressLine1 = CheckNull(item.AddressLine1),
                            AddressLine2 = CheckNull(item.AddressLine2),
                            AddressLine3 = CheckNull(item.AddressLine3),
                            Country = item.Country,
                            PostalCode = item.PostalCode,
                            MobileNo = item.MobileNo,
                            PhoneNo = item.PhoneNo,
                            Fax = item.Fax,
                            Email = item.Email,
                            DOB = item.DOB,
                            Gender = item.Gender,
                            HireDate = item.HireDate,
                            Salary = item.Salary,
                            OTRate = item.OTRate,
                            EmployeeImage = item.EmployeeImage,
                            UserName = item.UserName,
                            Password = item.Password,
                            Roles = item.Roles,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                            DesignationCode = item.DesignationCode,
                            DepartmentCode=item.DepartmentCode

                        };
                        ERPMASTERDatabase().HRMS_Employee.Add(emp);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, EMPLOYEE, organizationId);
            }

            return result;
        }
        //Edit the branch details
        public GE::HRMSEmployee GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::HRMSEmployee _data = new GE.HRMSEmployee();
            try
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.EmployeeCode == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.HRMSEmployee
                    {
                        OrgId = item.OrgId,
                        EmployeeName = item.EmployeeName,
                        EmployeeCode = item.EmployeeCode,
                        AddressLine1 = CheckNull(item.AddressLine1),
                        AddressLine2 = CheckNull(item.AddressLine2),
                        AddressLine3 = CheckNull(item.AddressLine3),
                        Country = item.Country,
                        PostalCode = item.PostalCode,
                        MobileNo = item.MobileNo,
                        PhoneNo = item.PhoneNo,
                        Fax = item.Fax,
                        Email = item.Email,
                        DOB = item.DOB,
                        Gender = item.Gender,
                        HireDate = item.HireDate,
                        Salary = item.Salary,
                        OTRate = item.OTRate,
                        EmployeeImage = item.EmployeeImage,
                        UserName = item.UserName,
                        Password = item.Password,
                        Roles = item.Roles,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        DOBString = item.DOB.HasValue ? item.DOB.Value.ToString("dd/MM/yyyy") : string.Empty,
                        HireDateString = item.HireDate.HasValue ? item.HireDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                        DepartmentCode = item.DepartmentCode,
                        DesignationCode = item.DesignationCode,
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, EMPLOYEE, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the branch details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, EMPLOYEE, inputdata.OrganisationId);
            }
            return result;
        }
        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputData)
        {
            List<GE::Country> _list = new List<GE.Country>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Countries.Where(o => o.IsActive == inputData.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Country
                        {
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return _list;
        }
        //To active the branch details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return result;
        }


        public List<GE::HRMSDepartment> GetAllDepart(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSDepartment> _list = new List<GE.HRMSDepartment>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Department.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSDepartment
                        {
                            OrgId = item.OrgId,
                            DepartmentCode = item.DepartmentCode,
                            DepartmentName = item.DepartmentName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DEPARTMENT, inputdata.OrganisationId);
            }
            return _list;
        }


        public List<GE::HRMSDesignation> GetDesignationByDepartmentCode(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSDesignation> _list = new List<GE.HRMSDesignation>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Designation.Where(o => o.IsActive == inputdata.IsActive && o.DepartmentCode == inputdata.DepartmentCode).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSDesignation
                        {
                            OrgId = item.OrgId,
                            DesignationCode = item.DesignationCode,
                            DesignationName = item.DesignationName,
                            DepartmentCode = item.DepartmentCode,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DESIGNATIONS, inputdata.OrganisationId);
            }
            return _list;
        }

    }
}
