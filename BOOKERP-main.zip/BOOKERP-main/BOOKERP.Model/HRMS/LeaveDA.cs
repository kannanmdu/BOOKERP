﻿using BOOKERP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
   public class LeaveDA: CommonDA
    {
        // Get All

        public List<GE::HRMSLeave> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSLeave> _list = new List<GE.HRMSLeave>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Leave.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.OrgId).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSLeave
                        {
                            OrgId = item.OrgId,
                            LeaveCode = item.LeaveCode,
                            LeaveName = item.LeaveName,
                            IsActive = item.IsActive,

                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, LEAVE, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::HRMSLeave item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().HRMS_Leave.FirstOrDefault(o => o.LeaveCode == item.LeaveCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.LeaveCode = item.LeaveCode;
                        _data.LeaveName = item.LeaveName;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.LeaveCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, LEAVE);
                            item.LeaveCode = autoCode;
                        }
                        HRMS_Leave leave = new HRMS_Leave()
                        {
                            OrgId = organizationId,
                            LeaveCode = item.LeaveCode,
                            LeaveName = item.LeaveName,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy=user
                            
                           
                        };
                        ERPMASTERDatabase().HRMS_Leave.Add(leave);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, LEAVE, organizationId);
            }

            return result;
        }

        //Edit the bank details
        public GE::HRMSLeave GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::HRMSLeave _data = new GE.HRMSLeave();
            try
            {
                var item = ERPMASTERDatabase().HRMS_Leave.FirstOrDefault(o => o.LeaveCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.HRMSLeave
                    {
                        OrgId = item.OrgId,
                        LeaveCode = item.LeaveCode,
                        LeaveName = item.LeaveName,
                        IsActive = item.IsActive,
                       
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, LEAVE, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the bank details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Leave.FirstOrDefault(o => o.LeaveCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, LEAVE, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the bank details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Leave.FirstOrDefault(o => o.LeaveCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BANK, inputData.OrganisationId);
            }
            return result;
        }

        public List<GE::HRMSLeave> GetAllLeave(GE::ERPInputmodel inputData)
        {
            List<GE::HRMSLeave> _list = new List<GE.HRMSLeave>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Leave.Where(o => o.IsActive == inputData.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSLeave
                        {
                            LeaveCode = item.LeaveCode,
                            LeaveName = item.LeaveName,
                            IsActive = item.IsActive,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, LEAVE, inputData.OrganisationId);
            }
            return _list;
        }
    }
}
