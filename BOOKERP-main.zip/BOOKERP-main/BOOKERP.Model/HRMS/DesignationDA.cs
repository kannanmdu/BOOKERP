﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class DesignationDA : CommonDA
    {
        // Get All

        public List<GE::HRMSDesignation> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSDesignation> _list = new List<GE.HRMSDesignation>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Designation.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSDesignation
                        {
                            OrgId = item.OrgId,
                            DesignationCode = item.DesignationCode,
                            DesignationName = item.DesignationName,
                            DepartmentCode = item.DepartmentCode,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DESIGNATIONS, inputdata.OrganisationId);
            }
            return _list;
        }
        
        public string Save(GE::HRMSDesignation item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().HRMS_Designation.FirstOrDefault(o => o.DesignationCode == item.DesignationCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.DesignationCode = item.DesignationCode;
                        _data.DesignationName = item.DesignationName;
                        _data.DepartmentCode = item.DepartmentCode;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.DesignationCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, DESIGNATIONS);
                            item.DesignationCode = autoCode;
                            
                        }
                        HRMS_Designation bank = new HRMS_Designation()
                        {
                            OrgId = organizationId,
                            DesignationCode = item.DesignationCode,
                            DesignationName = item.DesignationName,
                            DepartmentCode = item.DepartmentCode,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().HRMS_Designation.Add(bank);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, DESIGNATIONS, organizationId);
            }

            return result;
        }

        public List<GE::HRMSDepartment> GetDepartment(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSDepartment> _list = new List<GE.HRMSDepartment>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Department.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSDepartment
                        {
                            OrgId = item.OrgId,
                            DepartmentCode = item.DepartmentCode,
                            DepartmentName = item.DepartmentName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DESIGNATIONS, inputdata.OrganisationId);
            }
            return _list;
        }

        //Edit the bank details
        public GE::HRMSDesignation GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::HRMSDesignation _data = new GE.HRMSDesignation();
            try
            {
                var item = ERPMASTERDatabase().HRMS_Designation.FirstOrDefault(o => o.DesignationCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.HRMSDesignation
                    {
                        OrgId = item.OrgId,
                        DesignationCode = item.DesignationCode,
                        DesignationName = item.DesignationName,
                        DepartmentCode = item.DepartmentCode,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DESIGNATIONS, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the bank details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Designation.FirstOrDefault(o => o.DesignationCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DESIGNATIONS, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the bank details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Designation.FirstOrDefault(o => o.DesignationCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BANK, inputData.OrganisationId);
            }
            return result;
        }
    }
}
