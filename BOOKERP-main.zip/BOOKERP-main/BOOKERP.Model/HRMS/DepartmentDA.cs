﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
   public class DepartmentDA: CommonDA
    {
        // Get All

        public List<GE::HRMSDepartment> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::HRMSDepartment> _list = new List<GE.HRMSDepartment>();
            try
            {
                var _data = ERPMASTERDatabase().HRMS_Department.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSDepartment
                        {
                            OrgId = item.OrgId,
                            DepartmentCode = item.DepartmentCode,
                            DepartmentName = item.DepartmentName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DEPARTMENT, inputdata.OrganisationId);
            }
            return _list;
        }
        // save and update
        public string Save(GE::HRMSDepartment item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().HRMS_Department.FirstOrDefault(o => o.DepartmentCode == item.DepartmentCode && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.DepartmentCode = item.DepartmentCode;
                        _data.DepartmentName = item.DepartmentName;
                        _data.IsActive = item.IsActive;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.DepartmentCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, DEPARTMENT);
                            item.DepartmentCode = autoCode;
                        }
                        HRMS_Department bank = new HRMS_Department()
                        {
                            OrgId = organizationId,
                            DepartmentCode = item.DepartmentCode,
                            DepartmentName = item.DepartmentName,
                            IsActive = item.IsActive,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user
                        };
                        ERPMASTERDatabase().HRMS_Department.Add(bank);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, DEPARTMENT, organizationId);
            }

            return result;
        }

        //Edit the bank details
        public GE::HRMSDepartment GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::HRMSDepartment _data = new GE.HRMSDepartment();
            try
            {
                var item = ERPMASTERDatabase().HRMS_Department.FirstOrDefault(o => o.DepartmentCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    _data = (new GE.HRMSDepartment
                    {
                        OrgId = item.OrgId,
                        DepartmentCode = item.DepartmentCode,
                        DepartmentName = item.DepartmentName,                        
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DEPARTMENT, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the bank details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Department.FirstOrDefault(o => o.DepartmentCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, DEPARTMENT, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the bank details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Department.FirstOrDefault(o => o.DepartmentCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, BANK, inputData.OrganisationId);
            }
            return result;
        }
    }
}
