﻿using BOOKERP.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class AttendanceDA : CommonDA
    {
        // Get the branch details
        public GE::HRMSAttendance GetAll(GE::ERPInputmodel inputData)
        {
            GE::HRMSAttendance _Attendance = new GE.HRMSAttendance();
            List<GE::HRMSAttendance> _list = new List<GE.HRMSAttendance>();
            List<GE::HRMSEmployee> _Employeelist = new List<GE.HRMSEmployee>();
            try
            {
                var myDate = DateTime.Now;
                var startOfMonth = new DateTime(myDate.Year, myDate.Month, 1);
                var endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

                if (inputData.Month>0 && inputData.Year>0)
                {
                    startOfMonth= new DateTime(inputData.Year, inputData.Month, 1);
                    endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);
                }
               
                
                var _data = ERPMASTERDatabase().HRMS_Attendance.Where(o => o.OrgId == inputData.OrganisationId && o.CreatedOn >= startOfMonth && o.CreatedOn <= endOfMonth).OrderBy(o => o.CreatedOn).ToList();

                var _Emplyeee = ERPMASTERDatabase().HRMS_Employee.Where(o => o.OrgId == inputData.OrganisationId).OrderBy(o => o.CreatedOn).ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.HRMSAttendance
                        {
                            OrgId = item.OrgId,
                            EmployeeCode = item.EmployeeCode,
                            Status = item.StatusType,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            DateString = item.Date!=null? item.Date.ToString("yyyy-MM-dd") : string.Empty,
                            
                        });
                    });
                }
                if (_Emplyeee != null && _Emplyeee.Count() > 0)
                {
                    _Emplyeee.ForEach(item =>
                    {
                        _Employeelist.Add(new GE.HRMSEmployee
                        {
                            OrgId = item.OrgId,
                            EmployeeCode = item.EmployeeCode,
                            EmployeeName = item.EmployeeName,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                           

                        });
                    });
                }
                _Attendance.Employeelistval = _Employeelist;
                _Attendance.Attendanceval = _list;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return _Attendance;
        }
        public string Save(List<GE::HRMSAttendance> item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null && item.Count > 0)
                {


                    item.ForEach(items =>
                   {
                       items.OrgId = organizationId;
                       items.CreatedBy = user;
                       result = new AttendanceDA().SaveAttendance(items, user, organizationId);
                       ERPMASTERDatabase().SaveChanges();

                   });


                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, EMPLOYEE, organizationId);
            }

            return result;
        }

        //Save and update the branch details
        public string SaveAttendance(GE::HRMSAttendance item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {

                    var _data = ERPMASTERDatabase().HRMS_Attendance.FirstOrDefault(o => o.EmployeeCode == item.EmployeeCode && o.Date == item.Date && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.EmployeeCode = item.EmployeeCode;
                        _data.Date = item.Date;
                        _data.InTime = item.InTime;
                        _data.OutTime = item.OutTime;
                        _data.TotalHrs = item.TotalHrs;
                        _data.OverTimeHrs = item.OverTimeHrs;
                        _data.WorkMode = item.WorkingFrom;
                        _data.StatusType = item.Status;
                        _data.DepartmentCode = item.DepartmentCode;
                        _data.Remarks = item.Remarks;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.AttendanceCode))
                        {
                            var autoCode = GetMasterNextNo(organizationId, ATTENDANCE);
                            item.AttendanceCode = autoCode;
                        }
                        HRMS_Attendance atnd = new HRMS_Attendance()
                        {
                            OrgId = organizationId,
                            AttendanceCode = item.AttendanceCode,
                            EmployeeCode = item.EmployeeCode,
                            Date = item.Date,
                            InTime = item.InTime,
                            OutTime = item.OutTime,
                            TotalHrs = item.TotalHrs,
                            OverTimeHrs = item.OverTimeHrs,
                            Leave = item.Leave,
                            LeaveType = item.LeaveType,
                            WorkMode = item.WorkingFrom,
                            StatusType = item.Status,
                            DepartmentCode = item.DepartmentCode,
                            Remarks = item.Remarks,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now,
                        };
                        ERPMASTERDatabase().HRMS_Attendance.Add(atnd);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, EMPLOYEE, organizationId);
            }

            return result;
        }
        //Edit the branch details
        public GE::HRMSAttendance GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::HRMSAttendance _data = new GE.HRMSAttendance();
            try
            {

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, EMPLOYEE, inputdata.OrganisationId);
            }
            return _data;
        }
        //Delete the branch details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, EMPLOYEE, inputdata.OrganisationId);
            }
            return result;
        }
        public List<GE::Country> GetAllCountries(GE::ERPInputmodel inputData)
        {
            List<GE::Country> _list = new List<GE.Country>();
            try
            {
                var _data = ERPMASTERDatabase().Master_Countries.Where(o => o.IsActive == inputData.IsActive).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Country
                        {
                            CountryCode = item.CountryCode,
                            CountryName = item.CountryName,
                            IsActive = item.IsActive,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return _list;
        }
        //To active the branch details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().HRMS_Employee.FirstOrDefault(o => o.EmployeeCode == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, EMPLOYEE, inputData.OrganisationId);
            }
            return result;
        }
    }
}
