﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
  public  class CashInOutDA: CommonDA
    {
        public List<GE::POSCashInOut> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::POSCashInOut> _list = new List<GE.POSCashInOut>();
            try
            {
                var query = "SP_GetPOSCashInOutHeaderDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                var list = SqlMapper.Query<GE.POSCashInOut>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                return list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CASHINOUT, inputdata.OrganisationId);
            }
            return _list;
        }      
        // Get by Code
        public GE::POSCashInOut GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::POSCashInOut _data = new GE.POSCashInOut();
            try
            {
                var Header = "SP_GetPOSCashInOutEditDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@TranNo", inputdata.TranNo);
                _data = SqlMapper.QueryFirst<GE.POSCashInOut>(GetConnection, Header, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CASHINOUT, inputdata.OrganisationId);
            }

            return _data;
        }
        // Create or Update
        public string Save(GE::POSCashInOut item, string User)
        {
            string result = string.Empty;
            using (var dBEntities = new BOOKMERCHANT_DEVEntities())
            {
                try
                {
                    if (string.IsNullOrEmpty(item.TranNo))
                        item.TranNo = GetTransactionNumber(item.ModuleName, item.BranchCode, item.OrgId);
                    var data = dBEntities.SavePOSCashInCashOut(item.OrgId, item.BranchCode, item.CashRegisterCode, item.TranNo, item.TranDate, item.Amount,
                        item.ReferenceNo, item.Remarks, User, item.SettlementNo, item.TranType, item.CustomerSupplierId, item.CustomerSupplierName, item.ContactType).FirstOrDefault();
                    if (data != null)
                    {
                        result = data.Result;
                    }
                }
                catch (Exception ex)
                {
                    new ExceptionDA().Save(ex.Message, User, CASHINOUT, item.OrgId);
                }
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var data = ERPMASTERDatabase().SP_DeletePOSCashInCashOut(inputdata.OrganisationId, inputdata.TranNo).FirstOrDefault();
                if (data != null)
                {
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, CASHINOUT, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
