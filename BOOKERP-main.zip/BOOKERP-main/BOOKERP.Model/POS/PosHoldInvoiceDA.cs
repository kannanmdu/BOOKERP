﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class PosHoldInvoiceDA : CommonDA
    {
        public List<GE::POSInvoiceHeadersHoldInfo> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::POSInvoiceHeadersHoldInfo> _list = new List<GE.POSInvoiceHeadersHoldInfo>();
            try
            {
                var query = "SP_GetPOSInvoiceHeaders_Hold";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                var list = SqlMapper.Query<GE.POSInvoiceHeadersHoldInfo>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                return list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSHOLDINVOICE, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::POSInvoiceHeadersHoldInfo GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            string sQuery = string.Empty;
            GE::POSInvoiceHeadersHoldInfo _data = new GE.POSInvoiceHeadersHoldInfo();
            List<GE::POSInvoiceDetailHoldInfo> _list = new List<GE.POSInvoiceDetailHoldInfo>();
            try
            {
                var item = ERPMASTERDatabase().POSInvoiceHeaders_Hold.FirstOrDefault(o => o.OrderNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                var detailitem = ERPMASTERDatabase().POSInvoiceDetail_Hold.Where(o => o.OrgId == inputdata.OrganisationId && o.OrderNo == inputdata.TranNo).ToList();
                var cashData = ERPMASTERDatabase().POSCashRegisters.Where(x => x.OrgId == inputdata.OrganisationId && x.IsActive == true && x.CashRegisterCode == item.CashRegisterCode && x.BranchCode == inputdata.BranchCode).FirstOrDefault();
                string terminalName = string.Empty;
                if (cashData != null)
                {
                    terminalName = (!string.IsNullOrEmpty(cashData.TerminalName)) ? cashData.TerminalName : string.Empty;
                }              
                if (item != null)
                {
                    _data = (new GE.POSInvoiceHeadersHoldInfo
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        TerminalName = terminalName,
                        CashRegisterCode = item.CashRegisterCode,
                        OrderNo = item.OrderNo,
                        OrderDate = item.OrderDate,
                        CustomerId = item.CustomerId,
                        CustomerName = item.CustomerName,
                        TaxCode = item.TaxCode,
                        TaxType = item.TaxType,
                        TaxPerc = item.TaxPerc,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        Total = item.Total,
                        BillDiscount = item.BillDiscount,
                        BillDiscountPerc = item.BillDiscountPerc,
                        SubTotal = item.SubTotal,
                        Tax = item.Tax,
                        NetTotal = item.NetTotal,
                        Remarks = item.Remarks,
                        IsActive = item.IsActive,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn
                    });
                }

                if (detailitem != null && detailitem.Count > 0)
                {                    
                    detailitem.ForEach(ditem =>
                    {                        
                        _list.Add(new GE.POSInvoiceDetailHoldInfo
                        {
                            OrgId = ditem.OrgId,
                            OrderNo = ditem.OrderNo,
                            SlNo = ditem.SlNo,
                            ProductCode = ditem.ProductCode,
                            ProductName = ditem.ProductName,
                            Qty = ditem.Qty,
                            Foc = ditem.Foc,
                            Price = ditem.Price,
                            Total = ditem.Total,
                            ItemDiscount = ditem.ItemDiscount,
                            ItemDiscountPerc = ditem.ItemDiscountPerc,
                            SubTotal = ditem.SubTotal,
                            Tax = ditem.Tax,
                            NetTotal = ditem.NetTotal,
                            TaxCode = ditem.TaxCode,
                            TaxType = ditem.TaxType,
                            TaxPerc = ditem.TaxPerc,
                            Remarks = ditem.Remarks,
                            Weight = ditem.Weight,
                            CreatedBy = ditem.CreatedBy,
                            CreatedOn = ditem.CreatedOn,
                            ChangedBy = ditem.ChangedBy,
                            ChangedOn = ditem.ChangedOn,
                            UOMName = ditem.UOMName,
                            IsSR = ditem.IsSR
                        });
                    });
                }
                _data.POSInvoiceDetail = _list;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSHOLDINVOICE, inputdata.OrganisationId);
            }
            return _data;
        }
        public string Save(GE::POSInvoiceHeadersHoldInfo header, List<GE::POSInvoiceDetailHoldInfo> details, string user)
        {
            string Result = string.Empty;
            ListtoDataTableConverter converter = new ListtoDataTableConverter();
            try
            {
                if (string.IsNullOrEmpty(header.OrderNo))
                    header.OrderNo = GetTransactionNumber("POSInvoiceHold", header.BranchCode, header.OrgId);

                using (var Connection = GetConnection)
                {
                    DataTable dt = converter.ToDataTable(details);
                    dt.Columns.Remove("OrgId");
                    dt.Columns.Remove("OrderNo");
                    dt.Columns.Remove("CreatedBy");
                    dt.Columns.Remove("CreatedOn");
                    dt.Columns.Remove("ChangedOn");
                    dt.Columns.Remove("ChangedBy");

                    string TranNo = HoldSave(header, user, dt);
                    Result = TranNo;
                    Connection.Close();
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSHOLDINVOICE, header.OrgId);
                GetConnection.Close();
            }
            return Result;

        }
        public string HoldSave(GE::POSInvoiceHeadersHoldInfo item, string user, DataTable details)
        {
            string result = string.Empty;
            try
            {
                var query = "SavePOSInvoiceHeader_Hold";
                var param = new DynamicParameters();
                param.Add("@OrgId", item.OrgId);
                param.Add("@BranchCode", item.BranchCode);
                param.Add("@CashRegisterCode", item.CashRegisterCode);
                param.Add("@OrderNo", item.OrderNo);
                param.Add("@OrderDate", item.OrderDate);
                param.Add("@CustomerId", item.CustomerId);
                param.Add("@CustomerName", item.CustomerName);
                param.Add("@TaxCode", item.TaxCode);
                param.Add("@TaxType", item.TaxType);
                param.Add("@TaxPerc", item.TaxPerc);
                param.Add("@CurrencyCode", item.CurrencyCode);
                param.Add("@CurrencyRate", item.CurrencyRate);

                param.Add("@Total", item.Total);
                param.Add("@BillDiscount", item.BillDiscount);
                param.Add("@BillDiscountPerc", item.BillDiscountPerc);
                param.Add("@SubTotal", item.SubTotal);
                param.Add("@Tax", item.Tax);
                param.Add("@NetTotal", item.NetTotal);
                param.Add("@Remarks", item.Remarks);
                param.Add("@IsActive", item.IsActive);
                param.Add("@PayableAmount", 0);
                param.Add("@BalanceAmount", 0);
                param.Add("@User", user);
                param.Add("@Detail", details, DbType.Object);

                var list = SqlMapper.ExecuteScalar(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (list != null)
                {
                    result = list.ToString();
                }
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSHOLDINVOICE, item.OrgId);
                GetConnection.Close();
            }
            return result;
        }
        public string RemovePosHoldbyCode(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var query = "Sp_SavePOSInvoiceHold_Deleted";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@TranNo", inputdata.TranNo);
                var data = SqlMapper.Query<GE.POSInvoiceHeadersHoldInfo>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (data != null)
                {
                    result = PASS;
                }
                GetConnection.Close();             
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, INVOICE, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
