﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using DA = BOOKERP.Model;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class SalesPOSDA : CommonDA
    {
        public List<GE::POSInvoice_Header> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::POSInvoice_Header> _list = new List<GE.POSInvoice_Header>();
            try
            {
                var query = "SP_GetPOSInvoiceHeaderDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                var list = SqlMapper.Query<GE.POSInvoice_Header>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();                     
                return list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSINVOICE, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::POSInvoice_Header GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            string sQuery = string.Empty;
            string cashregistername = string.Empty;
            GE::POSInvoice_Header _data = new GE.POSInvoice_Header();
            try
            {
                var cashregcode = string.Empty;
                var Header = "SP_GetEditPOSInvoiceHeader";
                var Detail = "SP_GetEditPOSInvoiceDetail";
                var Paymode = "SP_GetEditPOSReceipt";
                var headerParam = new DynamicParameters();

                headerParam.Add("@OrgId", inputdata.OrganisationId);
                headerParam.Add("@OrderNo", inputdata.TranNo);
                _data = SqlMapper.QueryFirst<GE.POSInvoice_Header>(GetConnection, Header, headerParam, commandType: CommandType.StoredProcedure);
                var cachRegister = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.CashRegisterCode == _data.CashRegisterCode);
                if (cachRegister != null)
                {
                    cashregistername = cachRegister.CashierName;
                }
                if (_data != null)
                {
                    _data.CashRegisterName = cashregistername;
                }

                 var detailList = SqlMapper.Query<GE.POSInvoice_Detail>(GetConnection, Detail, headerParam, commandType: CommandType.StoredProcedure);
                _data.POSInvoiceDetail = detailList.ToList();

                var PaymodeList = SqlMapper.Query<GE.PosPayment>(GetConnection, Paymode, headerParam, commandType: CommandType.StoredProcedure);
                _data.PosPaymentDetail = PaymodeList.ToList();                 
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSINVOICE, inputdata.OrganisationId);
            }
            return _data;
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var query = "SavePOSInvoice_Deleted";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@TranNo", inputdata.TranNo);
                param.Add("@User", inputdata.LoginUser);
                var data = SqlMapper.Query<GE.POSInvoice_Header>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (data != null)
                {
                    result = PASS;
                }
                GetConnection.Close();                 
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSINVOICE, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
