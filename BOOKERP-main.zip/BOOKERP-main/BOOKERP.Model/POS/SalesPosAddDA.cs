﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BOOKERP.Model
{
    public class  SalesPosAddDA : CommonDA
    {
        public List<GE::Paymode> GetAllPaymodes(GE::ERPInputmodel inputdata)
        {
            List<GE::Paymode> _list = new List<GE.Paymode>();
            try
            {
                var _data = ERPMASTERDatabase().Master_PayModes.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Paymode
                        {
                            Code = item.Code,
                            Name = item.Name,
                            DisplayOrder = item.DisplayOrder,
                            IsActive = item.IsActive,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            OrgId = item.OrgId
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PAYMODE, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::ProductpriceforTransaction GetProductPriceforTransaction(GE::ERPInputmodel inputdata)
        {            
            GE::ProductpriceforTransaction _data = new GE.ProductpriceforTransaction();
            try
            {
                var query = "Sp_GetProductPriceNew";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@BranchCode", inputdata.BranchCode);
                param.Add("@MenuName", inputdata.ModuleName);
                param.Add("@CustomerCode", inputdata.CustomerCode);
                param.Add("@PriceSettingId", inputdata.TranNo1);
                param.Add("@ProductCode", inputdata.TranNo);
                var list = SqlMapper.Query<GE.ProductpriceforTransaction>(GetConnection, query, param, commandType: CommandType.StoredProcedure).FirstOrDefault();
                GetConnection.Close();
                _data = list;               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PRODUCT, inputdata.OrganisationId);
            }
            return _data;
        }
        public GE::CashRegister CheckOpeningBalance(GE::ERPInputmodel inputdata)
        {
            GE::CashRegister _data = new GE.CashRegister();
            try
            {
                var cashreg = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.BranchCode == inputdata.BranchCode && o.CashRegisterCode == inputdata.TranNo && o.CreatedBy == inputdata.LoginUser && o.CashierName == "" && o.OBstatus == false);
                if (cashreg != null)
                {
                    _data.OrgId = cashreg.OrgId;
                    _data.BranchCode = cashreg.BranchCode;
                    _data.CashRegisterCode = cashreg.CashRegisterCode;
                    _data.TerminalName = cashreg.TerminalName;
                    _data.DepositAmount = cashreg.DepositAmount;
                    _data.CashierName = cashreg.CashierName;
                    _data.IsActive = cashreg.IsActive;
                    _data.OBstatus = cashreg.OBstatus;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSINVOICE, inputdata.OrganisationId);
            }
            return _data;
        }
        public string SaveOpeningBalance(GE::POSCashRegisterOpeningBalance header, string user)
        {
            string result = string.Empty;
            try
            {
                if (header != null)
                {
                    POSCashRegisterOpeningBalance balance = new POSCashRegisterOpeningBalance()
                    {
                        OrgId = header.OrgId,
                        BranchCode = header.BranchCode,
                        CashRegisterCode = header.CashRegisterCode,
                        TranDate = header.TranDate,
                        OpeningAmount = header.OpeningAmount,
                        CashierName = user,
                        IsActive = true,
                        CreatedBy = user,
                        CreatedOn = DateTime.Now,
                        ChangedBy = user,
                        ChangedOn = DateTime.Now,
                        SettlementNo = string.Empty,
                    };
                    ERPMASTERDatabase().POSCashRegisterOpeningBalances.Add(balance);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;

                    if (result == "pass")
                    {
                        var cashreg = ERPMASTERDatabase().POSCashRegisters.FirstOrDefault(o => o.OrgId == header.OrgId && o.BranchCode == header.BranchCode && o.CashRegisterCode == header.CashRegisterCode);
                        if (cashreg != null)
                        {
                            cashreg.DepositAmount = header.OpeningAmount;
                            cashreg.CashierName = user;
                            cashreg.OBstatus = true;
                            ERPMASTERDatabase().SaveChanges();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSINVOICE, header.OrgId);
            }
            return result;
        }
        public string Save(GE::POSInvoice_Header header, List<GE::POSInvoice_Detail> details, List<GE::PosPayment> _PosPayment, string user)
        {
            string Result = string.Empty;
            string TranNo = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (!header.IsCredit)
                        {
                            if (string.IsNullOrEmpty(header.OrderNo))
                                header.OrderNo = GetTransactionNumber("POSInvoice", header.BrachCode, header.OrgId);
                        }
                       
                        if (header != null && header.OrderNo != null)
                        {
                            TranNo = PosInvoiceHeaderSave(header, user, context);
                            if (!string.IsNullOrEmpty(TranNo))
                            {
                                context.SaveChanges();
                                if (header.PayableAmount != null && header.PayableAmount > 0)
                                {
                                    if (_PosPayment.Count > 0)
                                    {
                                        _PosPayment.ForEach(PosPayment =>
                                        {
                                            PosPayment.OrderNo = TranNo;
                                            PosPayment.OrgId = header.OrgId;
                                            PosPayment.CashRegisterCode = header.CashRegisterCode;
                                            PosPayment.BranchCode = header.BrachCode;
                                            PosPayment.IsCredit = header.IsCredit;
                                            PosPayment.OrderDate = header.OrderDate;
                                            TranNo = SavePaymode(PosPayment, user, context);
                                        });
                                    }
                                }
                                if (!string.IsNullOrEmpty(TranNo))
                                {
                                    context.SaveChanges();
                                    details.ForEach(_details =>
                                    {
                                        _details.OrderNo = TranNo;
                                        _details.OrgId = header.OrgId;
                                        _details.IsCredit = header.IsCredit;
                                        string res = PosInvoiceDetailSave(_details, user, context);
                                        if (res == TranNo)
                                            listcount = listcount + 1;
                                    });
                                    if (listcount == details.Count)
                                    {
                                        if (header.IsUpdate == true)
                                        {
                                            var _data = context.TransactionAutoIds.FirstOrDefault(o => o.OrgId == header.OrgId && o.BranchCode == header.BrachCode && o.MenuName == "Invoice" && o.Year == DateTime.Now.Year);
                                            if (_data != null)
                                            {
                                                _data.NextNo = _data.NextNo + 1;
                                                Result = TranNo;
                                                context.SaveChanges();
                                                dbContextTransaction.Commit();
                                            }
                                            else
                                                dbContextTransaction.Rollback();
                                        }
                                        else
                                        {
                                            Result = TranNo;
                                            context.SaveChanges();
                                            dbContextTransaction.Commit();
                                        }
                                    }
                                    else
                                        dbContextTransaction.Rollback();
                                }
                                else
                                    dbContextTransaction.Rollback();
                            }
                            else
                                dbContextTransaction.Rollback();
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, INVOICE, header.OrgId);
            }
            return Result;

        }
        public string PosInvoiceHeaderSave(GE::POSInvoice_Header item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.SavePOSInvoiceHeader(item.OrgId, item.BrachCode, item.CashRegisterCode, item.OrderNo, item.OrderDate,
                    item.CustomerId, item.CustomerName, item.TaxCode, item.TaxType, item.TaxPerc, item.CurrencyCode, item.CurrencyRate,
                    item.Total, item.BillDiscount, item.BillDiscountPerc, item.SubTotal, item.Tax, item.NetTotal,
                    item.Remarks, item.IsActive, item.PayableAmount, item.BalanceAmount, item.IsCredit, user, item.OrderNoHold, 0).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSINVOICE, item.OrgId);
            }
            return result;
        }
        public string PosInvoiceDetailSave(GE::POSInvoice_Detail item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.SavePOSInvoiceDetail(item.OrgId, item.OrderNo, item.SlNo, item.ProductCode, item.ProductName, item.Qty,
                    item.Price, item.Foc = 0, item.Total, item.ItemDiscount, item.ItemDiscountPerc, item.SubTotal = item.Total - item.ItemDiscount, item.Tax, item.NetTotal = item.SubTotal + item.Tax, item.TaxCode, item.TaxType,
                    item.TaxPerc, item.Remarks = string.Empty, item.Weight, item.UOMName, item.IsCredit, user, item.IsSR, 0, 0).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSINVOICE, item.OrgId);
            }
            return result;
        }
        public string SavePaymode(GE::PosPayment item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Save_POSReceipt(item.OrgId, item.SlNo, item.BranchCode,
                    item.CashRegisterCode, string.Empty, item.OrderNo, item.OrderDate, item.PaymodeName, item.PaymodeCode, item.Amount,
                  user, DateTime.Now, item.IsCredit).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }             
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSINVOICE, item.OrgId);
            }
            return result;
        }

        public string SaveReservation(GE::POSInvoice_Header header, List<GE::POSInvoice_Detail> details, List<GE::PosPayment> _PosPayment, string user)
        {
            string Result = string.Empty;
            string TranNo = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (!header.IsCredit)
                        {
                            if (string.IsNullOrEmpty(header.OrderNo))
                                header.OrderNo = GetTransactionNumber("POSInvoice", header.BrachCode, header.OrgId);
                        }

                        if (header != null && header.OrderNo != null)
                        {
                            TranNo = PosInvoiceHeaderSave(header, user, context);
                            if (!string.IsNullOrEmpty(TranNo))
                            {
                                context.SaveChanges();
                                if (header.PayableAmount != null && header.PayableAmount > 0)
                                {
                                    if (_PosPayment.Count > 0)
                                    {
                                        _PosPayment.ForEach(PosPayment =>
                                        {
                                            PosPayment.OrderNo = TranNo;
                                            PosPayment.OrgId = header.OrgId;
                                            PosPayment.CashRegisterCode = header.CashRegisterCode;
                                            PosPayment.BranchCode = header.BrachCode;
                                            PosPayment.IsCredit = header.IsCredit;
                                            PosPayment.OrderDate = header.OrderDate;
                                            TranNo = SavePaymode(PosPayment, user, context);
                                        });
                                    }
                                }
                                if (!string.IsNullOrEmpty(TranNo))
                                {
                                    context.SaveChanges();
                                    details.ForEach(_details =>
                                    {
                                        _details.OrderNo = TranNo;
                                        _details.OrgId = header.OrgId;
                                        _details.IsCredit = header.IsCredit;
                                        string res = PosInvoiceDetailSave(_details, user, context);
                                        if (res == TranNo)
                                            listcount = listcount + 1;
                                    });
                                    if (listcount == details.Count)
                                    {
                                        if (header.IsUpdate == true)
                                        {
                                            var _data = context.TransactionAutoIds.FirstOrDefault(o => o.OrgId == header.OrgId && o.BranchCode == header.BrachCode && o.MenuName == "Invoice" && o.Year == DateTime.Now.Year);
                                            if (_data != null)
                                            {
                                                _data.NextNo = _data.NextNo + 1;
                                                Result = TranNo;
                                                context.SaveChanges();
                                                dbContextTransaction.Commit();
                                            }
                                            else
                                                dbContextTransaction.Rollback();
                                        }
                                        else
                                        {
                                            Result = TranNo;
                                            context.SaveChanges();
                                            dbContextTransaction.Commit();
                                        }
                                    }
                                    else
                                        dbContextTransaction.Rollback();
                                }
                                else
                                    dbContextTransaction.Rollback();
                            }
                            else
                                dbContextTransaction.Rollback();
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, INVOICE, header.OrgId);
            }
            return Result;

        }

    }
}
