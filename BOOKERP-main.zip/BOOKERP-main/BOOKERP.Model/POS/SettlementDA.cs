﻿using System;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DA = BOOKERP.Model;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class POSSettlementDA : CommonDA
    {
        public List<GE::POSSettlementHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::POSSettlementHeaders> _list = new List<GE.POSSettlementHeaders>();
            try
            {
                var query = "SP_GetPOSSettlementHeaderDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                var list = SqlMapper.Query<GE.POSSettlementHeaders>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                return list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::POSSettlementDetails GetSettlementDetails(GE::ERPInputmodel inputdata)
        {
            GE::POSSettlementDetails posSettlement = new GE.POSSettlementDetails();
            List<GE::POSPaymode> _paymodeList = new List<GE.POSPaymode>();
            List<GE::POSCurrencyDenominationValue> _currencyList = new List<GE.POSCurrencyDenominationValue>();
            GE::POSSettlementHeaders poscashinout = new GE.POSSettlementHeaders();
            try
            {
                var _data = ERPMASTERDatabase().Master_CurrencyDenomination.Where(o => o.OrgId == inputdata.OrganisationId && o.IsActive == true).OrderByDescending(x => x.DenominationValue).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _currencyList.Add(new GE.POSCurrencyDenominationValue
                        {
                            OrgId = item.OrgId,
                            DenominationValue = item.DenominationValue,
                            IsActive = item.IsActive
                        });
                    });
                }
                var _cashinoutdata = ERPMASTERDatabase().POSCashInCashOuts.Where(o => o.OrgId == inputdata.OrganisationId && o.BranchCode == inputdata.BranchCode && o.CashRegisterCode == inputdata.CashRegisterCode && o.CreatedBy == inputdata.LoginUser && (string.IsNullOrEmpty(o.SettlementNo) || o.SettlementNo == string.Empty)).ToList();
                if (_data != null)
                {
                    posSettlement.CashInAmount = _cashinoutdata.Where(x => x.TranType.Trim() == "IN").Sum(x => x.Amount);
                    posSettlement.CashOutAmount = _cashinoutdata.Where(x => x.TranType.Trim() == "OUT").Sum(x => x.Amount);
                }
                var query = "Sp_GetPOSPaymodeDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@user", inputdata.LoginUser);
                param.Add("@CashRegisterCode", inputdata.CashRegisterCode);
                var data = SqlMapper.Query<GE.POSPaymode>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                _paymodeList = data.ToList();                
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            posSettlement.PosCurrencyDenomination = _currencyList;
            posSettlement.PosPaymode = _paymodeList;
            return posSettlement;
        }       
        public GE::POSSettlementHeaders GetTodayCashInOutDetails(GE::ERPInputmodel inputdata)
        {
            GE::POSSettlementHeaders posSettlement = new GE.POSSettlementHeaders();
            try
            {
                var _data = ERPMASTERDatabase().POSCashInCashOuts.Where(x => x.OrgId == inputdata.OrganisationId && x.BranchCode == inputdata.BranchCode && x.CreatedBy == inputdata.LoginUser && x.TranDate == DateTime.Today).ToList();
                if (_data != null)
                {
                    posSettlement.CashInAmount = _data.Where(x => x.TranType.Trim() == "IN").Sum(x => x.Amount);
                    posSettlement.CashOutAmount = _data.Where(x => x.TranType.Trim() == "OUT").Sum(x => x.Amount);
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            return posSettlement;
        }
        public List<GE::POSPaymode> GetTodaySettlementDetails(GE::ERPInputmodel inputdata)
        {
            List<GE::POSPaymode> _paymodeList = new List<GE.POSPaymode>();
            try
            {
                var query = "Sp_GetTotalPOSPaymodeDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@user", inputdata.LoginUser);
                param.Add("@CashRegisterCode", inputdata.CashRegisterCode);
                var data = SqlMapper.Query<GE.POSPaymode>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                _paymodeList = data.ToList();               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            return _paymodeList;
        }        
        public GE::POSSettlementHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::POSSettlementHeaders _data = new GE.POSSettlementHeaders();
            try
            {
                var cashregcode = string.Empty;
                var Header = "Sp_GetPOSSettlementHeaders";
                var Detail = "Sp_GetPOSSettlementDetails";
                var Paymode = "Sp_GetPOSPaymodeEditDetails";
                var headerParam = new DynamicParameters();
                var detailParam = new DynamicParameters();
                var paymodeParam = new DynamicParameters();

                headerParam.Add("@OrgId", inputdata.OrganisationId);
                headerParam.Add("@User", inputdata.LoginUser);
                headerParam.Add("@SettlementNo", inputdata.TranNo);
                headerParam.Add("@BranchCode", inputdata.BranchCode);
                _data = SqlMapper.QueryFirst<GE.POSSettlementHeaders>(GetConnection, Header, headerParam, commandType: CommandType.StoredProcedure);
                // _data.TranDateString = _data.TranDate != null ? _data.TranDate?.ToERPdate() : string.Empty;

                detailParam.Add("@OrgId", inputdata.OrganisationId);
                detailParam.Add("@SettlementNo", inputdata.TranNo);
                var detailList = SqlMapper.Query<GE::POSSettlementDetails>(GetConnection, Detail, detailParam, commandType: CommandType.StoredProcedure);
                _data.POSSettlementDetails = detailList.ToList();

                if(_data != null)
                {
                    cashregcode = _data.CashRegisterCode;
                }
                paymodeParam.Add("@OrgId", inputdata.OrganisationId);
                paymodeParam.Add("@user", inputdata.LoginUser);
                paymodeParam.Add("@SettlementNo", inputdata.TranNo);
                paymodeParam.Add("@CashRegisterCode", cashregcode);
                var PaymodeList = SqlMapper.Query<GE::POSPaymode>(GetConnection, Paymode, paymodeParam, commandType: CommandType.StoredProcedure);
                _data.POSPaymode = PaymodeList.ToList();

                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            return _data;
        }
        public string Save(GE::POSSettlementHeaders header, List<GE::POSSettlementDetail> details, string user)
        {
            string Result = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(header.SettlementNo))
                    header.SettlementNo = GetTransactionNumber("Pos Settlement", header.BranchCode, header.OrgId);
                using (var connection = GetConnection)
                {
                    ListtoDataTableConverter converter = new ListtoDataTableConverter();
                    DataTable dt = converter.ToDataTable(details);
                    string TranNo = Save(header, user, dt);
                    Result = TranNo;
                    connection.Close();
                }                
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSSETTLEMENT, header.OrgId);
            }
            return Result;
        }
        public string Save(GE::POSSettlementHeaders item, string user, DataTable details)
        {
            string result = string.Empty;
            try
            {
                var query = "SP_SavePOSSettlement";
                var param = new DynamicParameters();
                param.Add("@OrgId", item.OrgId);
                param.Add("@BranchCode", item.BranchCode);
                param.Add("@CashRegisterCode", item.CashRegisterCode);
                param.Add("@SettlementNo", item.SettlementNo);

                param.Add("@SettlementDate", item.SettlementDate);
                param.Add("@TotalCashAmount", item.TotalCashAmount);
                param.Add("@CashInAmount", item.CashInAmount);
                param.Add("@CashOutAmount", item.CashOutAmount);
                param.Add("@ShortageAmount", item.ShortageAmount);
                param.Add("@ExcessAmount", item.ExcessAmount);
                param.Add("@SettlementBy", item.SettlementBy);
                param.Add("@IsActive", item.IsActive);
                param.Add("@User", user);              
                param.Add("@Detail", details, DbType.Object);

                var list = SqlMapper.ExecuteScalar(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (list != null)
                {
                    result = list.ToString();
                }
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSSETTLEMENT, item.OrgId);
                GetConnection.Close();
            }
            return result;
        }        
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var query = "Sp_SavePOSSettlement_Deleted";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@TranNo", inputdata.TranNo);
                var data = SqlMapper.Query<GE.POSSettlementHeaders>(GetConnection, query, param, commandType: CommandType.StoredProcedure);                             
                if (data != null)
                {
                    result = PASS;
                }
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSSETTLEMENT, inputdata.OrganisationId);
            }
            return result;
        }
      
    }
}
