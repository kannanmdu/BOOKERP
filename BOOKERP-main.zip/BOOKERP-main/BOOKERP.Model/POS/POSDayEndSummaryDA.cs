﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dapper;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;
using DA = BOOKERP.Model;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class POSDayEndSummaryDA : CommonDA
    {
        public List<GE::POSDayEndSummary> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::POSDayEndSummary> _list = new List<GE.POSDayEndSummary>();
            try
            {
                var query = "SP_GetPOSDayEndSummaryList";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                var data = SqlMapper.Query<GE.POSDayEndSummary>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                _list = data.ToList();
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSDAYENDSUMMARY, inputdata.OrganisationId);
            }
            return _list;
        }              
        public List<GE::POSDayEndSummaryDetails> GetDayEndSummaryDetails(GE::ERPInputmodel inputdata)
        {
            List<GE::POSDayEndSummaryDetails> _list = new List<GE.POSDayEndSummaryDetails>();
            try
            {
                var query = "SP_GetPOSDayEndSummaryDetails";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@DayEndDate", inputdata.TranDate);
                param.Add("@CashRegisterCode", inputdata.CashRegisterCode);
                var data = SqlMapper.Query<GE.POSDayEndSummaryDetails>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                _list = data.ToList();
                GetConnection.Close();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, POSDAYENDSUMMARY, inputdata.OrganisationId);
            }
            return _list;
        }
        public string Save(GE::POSDayEndSummary item, string user)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    if (string.IsNullOrEmpty(item.TranNo))
                    {
                        item.TranNo = AutoTranNo(item.OrgId, item.BranchCode, "POS Day End Summary");
                    }
                    var query = "SavePOSDayEndSummary";
                    var param = new DynamicParameters();
                    param.Add("@OrgId", item.OrgId);
                    param.Add("@BranchCode", item.BranchCode);
                    param.Add("@TranNo", item.TranNo);
                    param.Add("@TranDate", item.TranDate);
                    param.Add("@DayEndSummaryBy", item.DayEndSummaryBy);
                    param.Add("@TotalCashSales", item.TotalCashSales);
                    param.Add("@TotalCashInHand", item.TotalCashInHand);
                    param.Add("@Shortage", item.Shortage);
                    param.Add("@Excess", item.Excess);
                    param.Add("@IsActive", item.IsActive);
                    param.Add("@SettlementNo", item.SettlementNo);
                    param.Add("@User", user);

                    var list = SqlMapper.ExecuteScalar(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                    if (list != null)
                    {
                        result = list.ToString();
                    }
                    GetConnection.Close();
                }                           
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, POSSETTLEMENT, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var query = "DeletePOSDayEndSummary";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId);
                param.Add("@TranNo", inputdata.TranNo);
                var data = SqlMapper.Query<string>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                if (data != null)
                {
                    result = PASS;
                }
                GetConnection.Close();               
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, POSDAYENDSUMMARY, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
