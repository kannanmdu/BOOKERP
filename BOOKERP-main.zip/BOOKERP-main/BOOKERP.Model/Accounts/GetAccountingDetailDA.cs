﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class  GetAccountingDetailDA:CommonDA
    {
        // Get All
        #region GENERALLEDGER

        public List<GE::GetAccountingDetail> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::GetAccountingDetail> _list = new List<GE.GetAccountingDetail>();
            try
            {
                inputdata.FromDate = DateTime.Now.Date;
                inputdata.ToDate = DateTime.Now.Date;

                if (!string.IsNullOrEmpty(inputdata.FromDateString))
                {
                    inputdata.FromDate = !string.IsNullOrEmpty(inputdata.FromDateString) ? inputdata.FromDateString.GetERPDateFormat() : DateTime.Now;
                    inputdata.FinacialYear = DateTime.Parse(inputdata.FromDateString).Year;
                }

                if (!string.IsNullOrEmpty(inputdata.ToDateString))
                {
                    inputdata.ToDate = !string.IsNullOrEmpty(inputdata.ToDateString) ? inputdata.ToDateString.GetERPDateFormat() : DateTime.Now;
                }

                var _data = ERPMASTERDatabase().Sp_Account_GetCoaTransaction(inputdata.OrganisationId, inputdata.FinacialYear, inputdata.FromDate, inputdata.ToDate, inputdata.LoginUser).OrderBy(o => o.RowId).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    if (!string.IsNullOrEmpty(inputdata.AccountNo))
                    {
                        _data = _data.FindAll(o => o.AccountNo != null && o.AccountNo == inputdata.AccountNo).OrderBy(o => o.RowId).ToList();
                    }


                    _data.ForEach(item =>
                    {

                        _list.Add(new GE.GetAccountingDetail
                        {

                            RowId = item.RowId,
                            OrgId = item.OrgId,
                            SortOrder = Convert.ToInt32(item.SortOrder),
                            AccountType = item.AccountType,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            ParentAccountNo = item.ParentAccountNo,
                            Transactiontype = item.TransactionType,
                            TranNo = item.TranNo,
                            Slno = Convert.ToInt32(item.SLNo),
                            TranDate = item.TranDate,
                            RefNo = item.RefNo,
                            RefName = item.RefName,
                            Debit = item.Debit,
                            Credit = item.Credit,
                            FDebit = item.FDebit,
                            FCredit = item.FCredit,
                            ReportType = item.ReportType,
                            CurrencyCode = item.CurrencyCode,
                            GLType = item.GLType,
                            CreatedBy = item.CreatedBy,
                            CreatedDate = item.CreatedDate,
                            TranDateString = item.TranDate.HasValue ? item.TranDate.Value.ToString("dd/MM/yyyy") : string.Empty,

                        });
                    });

                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, GENERALLEDGER, inputdata.OrganisationId);
            }
            return _list;
        }

        #endregion

        #region PROFITLOSS

        public List<GE::GetAccountingDetail> GetAllProfitLoss(GE::ERPInputmodel inputdata)
        {
            decimal? OtherIncome = 0;
            decimal? Expanse = 0;
            decimal? Income = 0;
            decimal? OtherExpanse = 0;
            List<GE::GetAccountingDetail> _list = new List<GE.GetAccountingDetail>();
            try
            {
                inputdata.FromDate = DateTime.Now.Date;
                inputdata.ToDate = DateTime.Now.Date;
                if (string.IsNullOrEmpty(inputdata.AccountNo))
                {
                    inputdata.AccountNo = string.Empty;
                }
                if (!string.IsNullOrEmpty(inputdata.FromDateString))
                    inputdata.FromDate = Convert.ToDateTime(inputdata.FromDateString);
                if (!string.IsNullOrEmpty(inputdata.ToDateString))
                    inputdata.ToDate = Convert.ToDateTime(inputdata.ToDateString);
                var _data = ERPMASTERDatabase().Sp_Account_GetCoaTransaction(inputdata.OrganisationId, inputdata.FinacialYear, inputdata.FromDate, inputdata.ToDate, inputdata.LoginUser).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    var _PLdata = ERPMASTERDatabase().Account_GetProfitLoss().ToList();
                    int Sortorder = 0;
                    _PLdata.ForEach(item =>
                    {
                        decimal? balance = item.Debit != null && item.Debit > 0 ? item.Debit - item.Credit : item.Credit - item.Debit;

                        if (item.GLType == "DI")
                        {
                            Income = Income + balance;//(item.Credit - item.Debit);
                            Sortorder = 1;
                            //balance = (item.Credit - item.Debit);
                        }
                        if (item.GLType == "DE")
                        {
                            Expanse = Expanse + balance;//(item.Debit - item.Credit);
                            Sortorder = 2;
                            //balance = (item.Debit - item.Credit);
                        }
                        if (item.GLType == "II")
                        {
                            OtherIncome = OtherIncome + balance;//(item.Credit - item.Debit);
                            Sortorder = 3;
                            //balance = (item.Credit - item.Debit);
                        }
                        if (item.GLType == "IE")
                        {
                            OtherExpanse = OtherExpanse + balance;//(item.Debit - item.Credit);
                            Sortorder = 4;
                            //balance = (item.Debit - item.Credit);
                        }

                        _list.Add(new GE.GetAccountingDetail
                        {
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            Debit = (item.Debit != null) ? item.Debit.Value : 0,
                            Credit = (item.Credit != null) ? item.Credit.Value : 0,
                            Balance = balance,
                            AccountType = item.GLType,
                            SortOrder = Sortorder,
                        });
                        _list = _list.OrderBy(o => o.SortOrder).ThenBy(o => o.AccountNo).ToList();
                        _list[0].SumOfIncome = Income;
                        _list[0].SumOfExpense = Expanse;
                        _list[0].SumOfOtherincome = OtherIncome;
                        _list[0].SumOfOtherExpense = OtherExpanse;
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, PROFITLOSS, inputdata.OrganisationId);
            }
            return _list;
        }
        #endregion

        #region TRIALBALANCE
        public List<GE::GetAccountingDetail> GetAllTrialBalance(GE::ERPInputmodel inputdata)
        {
            List<GE::GetAccountingDetail> _list = new List<GE.GetAccountingDetail>();
            try
            {
                inputdata.FromDate = DateTime.Now.Date;
                inputdata.ToDate = DateTime.Now.Date;
                if (!string.IsNullOrEmpty(inputdata.FromDateString))
                {
                    inputdata.FromDate = !string.IsNullOrEmpty(inputdata.FromDateString) ? inputdata.FromDateString.GetERPDateFormat() : DateTime.Now;
                    inputdata.FinacialYear = DateTime.Parse(inputdata.FromDateString).Year;
                }

                if (!string.IsNullOrEmpty(inputdata.ToDateString))
                {
                    inputdata.ToDate = !string.IsNullOrEmpty(inputdata.ToDateString) ? inputdata.ToDateString.GetERPDateFormat() : DateTime.Now;
                }
                var _data = ERPMASTERDatabase().Sp_Account_GetCoaTransaction(inputdata.OrganisationId, inputdata.FinacialYear, inputdata.FromDate, inputdata.ToDate, inputdata.LoginUser).ToList();
                var _accountData = ERPMASTERDatabase().Account_COAList.Where(x => x.OrgId == inputdata.OrganisationId && x.G1GroupName != "EXPENSES" && x.G1GroupName != "INCOME").ToList();

                if (_data != null && _data.Count() > 0)
                {
                    var _Traildata = ERPMASTERDatabase().Account_GetTrailBalance().ToList();
                    decimal _bal = 0;
                    _Traildata.ForEach(item =>
                    {
                        var groupLevel = _accountData.Where(x => x.G3GroupNo == item.AccountNo).Select(x => x.G2GroupName).FirstOrDefault();

                        _list.Add(new GE.GetAccountingDetail
                        {
                            AccountType = item.AccountType,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            Balance = item.Debit != null && item.Debit > 0 ? (_bal + item.Debit) : (_bal - item.Credit),
                            GroupLevel = item.GroupLevel,
                            GroupLevelName = groupLevel
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, TRIALBALANCE, inputdata.OrganisationId);
            }
            return _list;
        }

        #endregion

        #region BALANCESHEET
        public List<GE::GetAccountingDetail> GetAllBalanceSheet(GE::ERPInputmodel inputdata)
        {
            decimal? Asset = 0;
            decimal? Liabilities = 0;
            decimal? Equity = 0;
            decimal? ProfitLoss = 0;

            List<GE::GetAccountingDetail> _list = new List<GE.GetAccountingDetail>();
            try
            {
                //inputdata.FromDate = DateTime.Now.Date;
                inputdata.FromDate = DateTime.Now.Date.AddDays(-30);
                inputdata.ToDate = DateTime.Now.Date;
                if (string.IsNullOrEmpty(inputdata.AccountNo))
                {
                    inputdata.AccountNo = string.Empty;
                }
                if (!string.IsNullOrEmpty(inputdata.FromDateString))
                    inputdata.FromDate = Convert.ToDateTime(inputdata.FromDateString);
                if (!string.IsNullOrEmpty(inputdata.ToDateString))
                    inputdata.ToDate = Convert.ToDateTime(inputdata.ToDateString);
                var _data = ERPMASTERDatabase().Sp_Account_GetCoaTransaction(inputdata.OrganisationId, inputdata.FinacialYear, inputdata.FromDate, inputdata.ToDate, inputdata.LoginUser).ToList();
                var _accountData = ERPMASTERDatabase().Account_COAList.Where(x => x.OrgId == inputdata.OrganisationId && x.G1GroupName != "EXPENSES" && x.G1GroupName != "INCOME").ToList();

                if (_data != null && _data.Count > 0)
                {
                    var _Balancedata = ERPMASTERDatabase().Account_GetBalanceSheet().ToList();
                    var AccountBalanceSheet = _Balancedata.FindAll(x => x.AccountType != "EXPENSES" && x.AccountType != "INCOME").OrderBy(o => o.AccountType).OrderBy(o => o.GroupLevel).ToList();
                    var AccountProfitLoss = _Balancedata.FindAll(x => x.AccountType == "EXPENSES" || x.AccountType == "INCOME");
                    if (AccountBalanceSheet != null && AccountBalanceSheet.Count() > 0)
                    {

                        AccountBalanceSheet.ForEach(item =>
                        {
                            var groupLevel = _accountData.Where(x => x.G3GroupNo == item.AccountNo).Select(x => x.G2GroupName).FirstOrDefault();

                            decimal? Balance = item.Debit != null && item.Debit > 0 ? item.Debit - item.Credit : item.Credit - item.Debit;
                            // decimal? PrevBalance = item.Debit != null && item.Debit  ? item.PrevDebit - item.PrevCredit : item.PrevCredit - item.PrevDebit;
                            // decimal? FBalance = item.Debit != null && item.Debit ? item.FDebit - item.FCredit : item.FCredit - item.FDebit;
                            // decimal? FPrevBalance = item.Debit != null && item.Debit ? item.PrevFDebit - item.PrevFCredit : item.PrevFCredit - item.PrevFDebit;
                            int Sortorder = 0;
                            if (item.AccountType == "ASSET")
                            {
                                item.AccountType = "Asset";
                                Sortorder = 1;
                                Asset += Balance;
                            }
                            if (item.AccountType == "LIABILITY")
                            {
                                item.AccountType = "Liability";
                                Sortorder = 2;
                                Liabilities += Balance;
                            }
                            if (item.AccountType == "EQUITY")
                            {
                                item.AccountType = "Equity";
                                Sortorder = 3;
                                Equity += Balance;
                            }
                            _list.Add(new GE.GetAccountingDetail
                            {
                                AccountNo = item.AccountNo,
                                AccountName = item.AccountName,
                                AccountType = item.AccountType,
                                SortOrder = Sortorder,
                                GroupLevel = item.GroupLevel,
                                GroupLevelName = groupLevel,
                                Debit = item.Debit,
                                Credit = item.Credit,
                                Balance = Balance,
                            });
                        });
                    }

                    if (AccountProfitLoss != null && AccountProfitLoss.Count > 0)
                    {
                        decimal? Sales = 0;
                        decimal? costofsales = 0;
                        decimal? otherincome = 0;
                        decimal? Expanse = 0;
                        decimal? GrossProfit = 0;
                        decimal? NetTotal = 0;

                        AccountProfitLoss.ForEach(item =>
                        {
                            decimal? balance = item.Debit != null && item.Debit > 0 ? item.Debit - item.Credit : item.Credit - item.Debit;
                            if (item.GLType == "DI")
                            {
                                item.AccountType = "Income";
                                Sales += balance;//(item.Credit - item.Debit);
                            }

                            if (item.GLType == "DE")
                            {
                                item.AccountType = "Expenses";
                                costofsales += balance;//(item.Debit - item.Credit);
                            }

                            if (item.GLType == "II")
                            {
                                item.AccountType = "OtherIncome";
                                otherincome += balance;//(item.Credit - item.Debit);
                            }

                            if (item.GLType == "IE")
                            {
                                item.AccountType = "OTHEREXPENSE";
                                Expanse += balance;//(item.Debit - item.Credit);
                            }
                        });

                        GrossProfit = Sales - costofsales;
                        if (GrossProfit > 0)
                        {
                            NetTotal = GrossProfit + otherincome;
                            //if (Expanse > NetTotal)
                            //    NetTotal = NetTotal - Expanse;
                            //else
                            //    NetTotal = Expanse - NetTotal;
                        }
                        else
                        {
                            NetTotal = GrossProfit + Expanse;
                            //if (otherincome > NetTotal)
                            //    NetTotal = otherincome - NetTotal;
                            //else
                            //    NetTotal = NetTotal - otherincome;
                        }

                        ProfitLoss += NetTotal;
                    }

                    if (_list != null && _list.Count > 0)
                    {
                        _list[0].SumOfAsset = Asset;
                        _list[0].SumOfLiabilities = Liabilities;
                        _list[0].SumOfEquity = Equity;
                        _list[0].SumOfProfitLoss = ProfitLoss;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BALANCESHEET, inputdata.OrganisationId);
            }
            return _list;
        }


        #endregion

        #region FINCIALSETTING
        public GE::FinancialSettings GetFinancialSetting(GE::ERPInputmodel inputdata)
        {
            GE::FinancialSettings ResponseList = new GE.FinancialSettings();

            var Source = (from FS in ERPMASTERDatabase().Account_FinancialSettings
                          where FS.OrgId == inputdata.OrganisationId
                          select FS).FirstOrDefault();

            if (Source != null)
            {
                ResponseList.OrgId = Source.OrgId;
                ResponseList.FinancialPeriodFrom = Source.FinancialPeriodFrom;
                ResponseList.FinancialPeriodTo = Source.FinancialPeriodTo;
                ResponseList.CurrentFinancialYear = Source.CurrentFinancialYear;
                ResponseList.CustomerAccountNo = Source.CustomerAccountNo;
                ResponseList.PurchaseAccountNo = Source.PurchaseAccountNo;
                ResponseList.SupplierAccountNo = Source.SupplierAccountNo;
                ResponseList.InventoryAccountNo = Source.InventoryAccountNo;
                ResponseList.TaxInAccountNo = Source.TaxInAccountNo;
                ResponseList.TaxOutAccountNo = Source.TaxOutAccountNo;
                ResponseList.SalesAccountNo = Source.SalesAccountNo;
                ResponseList.CostOfGoodsAccountNo = Source.CostOfGoodsAccountNo;
                ResponseList.ClosingStockAccountNo = Source.ClosingStockAccountNo;
                ResponseList.HaveCostofGoodsSold = Source.HaveCostofGoodsSold;
                ResponseList.FinancialPeriodFromString = Source.FinancialPeriodFrom.HasValue ? Source.FinancialPeriodFrom.Value.ToString("dd/MM/yyyy") : string.Empty;
                ResponseList.FinancialPeriodToString = Source.FinancialPeriodTo.HasValue ? Source.FinancialPeriodTo.Value.ToString("dd/MM/yyyy") : string.Empty;
                ResponseList.CurrentYearEarning = Source.CurrentYearEarning;
            }
            return ResponseList;
        }
        public string Save(GE::FinancialSettings item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Account_FinancialSettings.FirstOrDefault(o => o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.FinancialPeriodFrom = item.FinancialPeriodFrom;
                        _data.FinancialPeriodTo = item.FinancialPeriodTo;
                        _data.CurrentFinancialYear = item.CurrentFinancialYear;
                        _data.CustomerAccountNo = item.CustomerAccountNo;
                        _data.PurchaseAccountNo = item.PurchaseAccountNo;
                        _data.SupplierAccountNo = item.SupplierAccountNo;
                        _data.InventoryAccountNo = item.InventoryAccountNo;
                        _data.TaxInAccountNo = item.TaxInAccountNo;
                        _data.TaxOutAccountNo = item.TaxOutAccountNo;
                        _data.SalesAccountNo = item.SalesAccountNo;
                        _data.CostOfGoodsAccountNo = item.CostOfGoodsAccountNo;
                        _data.ClosingStockAccountNo = item.ClosingStockAccountNo;
                        _data.HaveCostofGoodsSold = item.HaveCostofGoodsSold;
                        _data.CurrentYearEarning = item.CurrentYearEarning;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        Account_FinancialSettings financialSetting = new Account_FinancialSettings();
                        financialSetting.OrgId = OrganizationId;
                        financialSetting.FinancialPeriodFrom = item.FinancialPeriodFrom;
                        financialSetting.FinancialPeriodTo = item.FinancialPeriodTo;
                        financialSetting.CurrentFinancialYear = item.CurrentFinancialYear;
                        financialSetting.CustomerAccountNo = item.CustomerAccountNo;
                        financialSetting.PurchaseAccountNo = item.PurchaseAccountNo;
                        financialSetting.SupplierAccountNo = item.SupplierAccountNo;
                        financialSetting.InventoryAccountNo = item.InventoryAccountNo;
                        financialSetting.TaxInAccountNo = item.TaxInAccountNo;
                        financialSetting.TaxOutAccountNo = item.TaxOutAccountNo;
                        financialSetting.SalesAccountNo = item.SalesAccountNo;
                        financialSetting.CostOfGoodsAccountNo = item.CostOfGoodsAccountNo;
                        financialSetting.ClosingStockAccountNo = item.ClosingStockAccountNo;
                        financialSetting.HaveCostofGoodsSold = item.HaveCostofGoodsSold;
                        financialSetting.CurrentYearEarning = item.CurrentYearEarning;
                        ERPMASTERDatabase().Account_FinancialSettings.Add(financialSetting);

                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, FINANCIALSETTINGS, OrganizationId);
            }
            return result;
        }
        #endregion
    }
}
