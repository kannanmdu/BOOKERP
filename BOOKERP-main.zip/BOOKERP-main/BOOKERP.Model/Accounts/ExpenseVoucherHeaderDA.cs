﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class ExpenseVoucherHeaderDA : CommonDA
    {
        // Get All
        public List<GE::AccountVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::AccountVoucherHeader> _list = new List<GE.AccountVoucherHeader>();
            try
            {
                var _data = ERPMASTERDatabase().Account_IncomeExpenseVoucherHeader.Where(o => o.TranType == "EXP" && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.AccountVoucherHeader
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                            TranType = item.TranType,
                            CustomerName = item.CustomerSupplierName,
                            SubTotal = item.SubTotal != null ? item.SubTotal : 0,
                            Tax = item.Tax != null ? item.Tax : 0,
                            NetTotal = item.NetTotal != null ? item.NetTotal : 0,
                            BalanceAmount = item.BalanceAmount != null ? item.BalanceAmount : 0,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            FBalanceAmount = item.FBalanceAmount,
                            Remarks = item.Remarks,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code

        // Create or Update
        public string Save(GE::AccountVoucherHeader item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {


                var data = dBEntities.Account_SaveIncomeExpenseVoucherHeader(item.OrgId, item.LocationCode, item.TranNo, item.TranDate, "EXP", item.CustomerCode
                    , item.CustomerName, item.RefNo, item.ReferenceDate, item.Remarks, item.Total, 0, 0, item.SubTotal, item.Tax, item.NetTotal, item.PaidAmount, 0, item.BalanceAmount
                    , item.CurrencyCode, item.CurrencyRate, item.CurrencyValue, item.FTotal, item.FSubTotal, item.FTax, item.FNetTotal, item.FPaidAmount, 0, item.FBalanceAmount, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, INCOME, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_IncomeExpenseVoucherHeader.FirstOrDefault(o => o.TranType == inputdata.TranType && o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                var ditem = ERPMASTERDatabase().Account_IncomeExpenseVoucherDetail.Where(o => o.TranType == inputdata.TranType && o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    ERPMASTERDatabase().Account_IncomeExpenseVoucherHeader.Remove(item);
                    ERPMASTERDatabase().Account_IncomeExpenseVoucherDetail.RemoveRange(ditem);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
                if (item != null)
                {
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return result;
        }
        public GE::AccountVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::AccountVoucherHeader _data = new GE.AccountVoucherHeader();
            List<GE::AccountVoucherDetail> _acclist = new List<GE.AccountVoucherDetail>();
            try
            {
                var item = ERPMASTERDatabase().Account_IncomeExpenseVoucherHeader.FirstOrDefault(o => o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType);
                var accountitem = ERPMASTERDatabase().Account_IncomeExpenseVoucherDetail.Where(o => o.OrgId == inputdata.OrganisationId && o.TranNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();

                if (item != null)
                {
                    _data = (new GE.AccountVoucherHeader
                    {
                        CustomerCode = item.CustomerSupplierCode,
                        OrgId = item.OrgId,
                        TranNo = item.TranNo,
                        TranDate = item.TranDate,
                        TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                        TranType = item.TranType,
                        RefNo = item.ReferenceNo,
                        ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                        SubTotal = item.SubTotal,
                        Tax = item.Tax,
                        NetTotal = item.NetTotal,
                        BalanceAmount = item.BalanceAmount,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        CurrencyValue = item.CurrencyValue,
                        FSubTotal = item.FSubTotal,
                        FTax = item.FTax,
                        FNetTotal = item.FNetTotal,
                        FBalanceAmount = item.FBalanceAmount,
                        Remarks = item.Remarks,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                    });
                }

                if (accountitem != null && accountitem.Count > 0)
                {
                    accountitem.ForEach(ditem =>
                    {
                        _acclist.Add(new GE.AccountVoucherDetail
                        {
                            OrgId = ditem.OrgId,
                            TranNo = ditem.TranNo,
                            TranType = ditem.TranType,
                            SlNo = ditem.SlNo,
                            AccountNo = ditem.GLCode,
                            AccountName = ditem.GLDescription,
                            Qty = ditem.Qty,
                            Price = ditem.Price,
                            SubTotal = ditem.SubTotal,
                            Tax = ditem.Tax,
                            NetTotal = ditem.NetTotal,
                            TaxCode = ditem.TaxCode,
                            TaxPerc = ditem.TaxPerc,
                            Remarks = ditem.ItemRemarks,
                            FPrice = ditem.FPrice,
                            FSubTotal = ditem.FSubTotal,
                            FTax = ditem.FTax,
                            FNetTotal = ditem.FNetTotal,
                            CreatedBy = ditem.CreatedBy,
                            CreatedOn = ditem.CreatedOn,
                            ChangedBy = ditem.ChangedBy,
                            ChangedOn = ditem.ChangedOn
                        });
                    });
                }

                _data.VoucherDetail = _acclist;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }


            return _data;
        }

        public List<GE::AccountVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            List<GE::AccountVoucherHeader> _list = new List<GE.AccountVoucherHeader>();
            try
            {
                var _data = ERPMASTERDatabase().Account_IncomeExpenseVoucherHeader.Where(o => o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.AccountVoucherHeader
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                            TranType = item.TranType,
                            CustomerCode = item.CustomerSupplierCode,
                            CustomerName = item.CustomerSupplierName,
                            SubTotal = item.SubTotal != null ? item.SubTotal : 0,
                            Tax = item.Tax != null ? item.Tax : 0,
                            NetTotal = item.NetTotal != null ? item.NetTotal : 0,
                            BalanceAmount = item.BalanceAmount != null ? item.BalanceAmount : 0,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            FBalanceAmount = item.FBalanceAmount,
                            Remarks = item.Remarks,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }
        public string GetStringfrombyte(byte[] ImageArray)
        {
            string imgDataURL = string.Empty;
            if (ImageArray != null)
            {
                string imreBase64Data = Convert.ToBase64String(ImageArray);
                imgDataURL = string.Format("data:image/png;base64,{0}", imreBase64Data);
            }
            return imgDataURL;
        }
    }
}
