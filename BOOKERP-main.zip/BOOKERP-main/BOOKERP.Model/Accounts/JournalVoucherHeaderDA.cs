﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class JournalVoucherHeaderDA : CommonDA
    {
        // Get All
        public List<GE::JournalVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::JournalVoucherHeader> _list = new List<GE.JournalVoucherHeader>();
            try
            {
                var _data = ERPMASTERDatabase().Account_JVHeader.Where(o => o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.JournalVoucherHeader
                        {
                            OrgId = item.OrgId,
                            LocationCode = item.LocationCode,
                            JVNo = item.JVNo,
                            JVDate = item.JVDate,
                            JVDateString = (item.JVDate.HasValue) ? item.JVDate.Value.ToERPdate() : string.Empty,
                            TotalDebit = item.TotalDebit,
                            TotalCredit = item.TotalCredit,
                            FTotalDebit = item.FTotalDebit,
                            FTotalCredit = item.FTotalCredit,
                            Remarks = item.Remarks,
                            Paymode = item.Paymode,
                            BankCode = item.BankCode,
                            BankInDate = item.BankInDate,
                            BankInDateString = (item.BankInDate.HasValue) ? item.BankInDate.Value.ToERPdate() : string.Empty,
                            ChequeNo = item.ChequeNo,
                            ChequeDate = item.ChequeDate,
                            ChequeDateString = (item.ChequeDate.HasValue) ? item.ChequeDate.Value.ToERPdate() : string.Empty,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            TranType = item.TranType,
                            ReferenceNo = item.ReferenceNo,
                            ReferenceDate = item.ReferenceDate,
                            ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }


        // Create or Update
        public string Save(GE::JournalVoucherHeader item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Account_SaveJVHeader(item.OrgId, item.LocationCode, item.JVNo, item.JVDate, item.ReferenceNo, item.ReferenceDate, item.TotalDebit, item.TotalCredit,
                           item.FTotalDebit, item.FTotalCredit, item.Remarks, item.Paymode, item.BankCode, item.BankInDate, item.ChequeNo, item.ChequeDate,
                           item.CurrencyCode, item.CurrencyRate, item.CurrencyValue, item.TranType, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, INCOME, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_JVHeader.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.JVNo == inputdata.TranNo && o.TranType == "JV");
                if (item != null)
                {
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return result;
        }

        // Get by Code
        public GE::JournalVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::JournalVoucherHeader _data = new GE.JournalVoucherHeader();
            List<GE::JournalVoucherDetail> _jvlist = new List<GE.JournalVoucherDetail>();
            try
            {

                var item = ERPMASTERDatabase().Account_JVHeader.FirstOrDefault(o => o.JVNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType);
                var jvitem = ERPMASTERDatabase().Account_JVDetail.Where(o => o.OrgId == inputdata.OrganisationId && o.JVNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();

                if (item != null)
                {
                    _data = (new GE.JournalVoucherHeader
                    {
                        OrgId = item.OrgId,
                        LocationCode = item.LocationCode,
                        JVNo = item.JVNo,
                        JVDate = item.JVDate,
                        JVDateString = (item.JVDate.HasValue) ? item.JVDate.Value.ToERPdate() : string.Empty,
                        TotalDebit = item.TotalDebit,
                        TotalCredit = item.TotalCredit,
                        FTotalDebit = item.FTotalDebit,
                        FTotalCredit = item.FTotalCredit,
                        Remarks = item.Remarks,
                        Paymode = item.Paymode,
                        BankCode = item.BankCode,
                        BankInDate = item.BankInDate,
                        BankInDateString = (item.BankInDate.HasValue) ? item.BankInDate.Value.ToERPdate() : string.Empty,
                        ChequeNo = item.ChequeNo,
                        ChequeDate = item.ChequeDate,
                        ChequeDateString = (item.ChequeDate.HasValue) ? item.ChequeDate.Value.ToERPdate() : string.Empty,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        CurrencyValue = item.CurrencyValue,
                        TranType = item.TranType,
                        ReferenceNo = item.ReferenceNo,
                        ReferenceDate = item.ReferenceDate,
                        ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn
                    });
                }

                if (jvitem != null && jvitem.Count > 0)
                {
                    jvitem.ForEach(ditem =>
                    {
                        _jvlist.Add(new GE.JournalVoucherDetail
                        {
                            OrgId = ditem.OrgId,
                            JVNo = ditem.JVNo,
                            SlNo = ditem.SlNo,
                            DrCr = ditem.DrCr,
                            AccountNo = ditem.AccountNo,
                            AccountName = ditem.AccountName,
                            Debit = ditem.Debit,
                            Credit = ditem.Credit,
                            FDebit = ditem.FDebit,
                            FCredit = ditem.FCredit,
                            CurrencyCode = ditem.CurrencyCode,
                            CurrencyRate = ditem.CurrencyRate,
                            Remarks = ditem.Remarks,
                            TranType = ditem.TranType,
                            CreatedBy = ditem.CreatedBy,
                            CreatedOn = ditem.CreatedOn,
                            ChangedBy = ditem.ChangedBy,
                            ChangedOn = ditem.ChangedOn
                        });
                    });
                }

                _data.JournalVoucherDetail = _jvlist;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }

            return _data;
        }

        // Get Search Data
        public List<GE::JournalVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            List<GE::JournalVoucherHeader> _list = new List<GE.JournalVoucherHeader>();
            try
            {
                var _data = ERPMASTERDatabase().Account_JVHeader.Where(o => o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.JournalVoucherHeader
                        {
                            OrgId = item.OrgId,
                            LocationCode = item.LocationCode,
                            JVNo = item.JVNo,
                            JVDate = item.JVDate,
                            JVDateString = (item.JVDate.HasValue) ? item.JVDate.Value.ToERPdate() : string.Empty,
                            TotalDebit = item.TotalDebit,
                            TotalCredit = item.TotalCredit,
                            FTotalDebit = item.FTotalDebit,
                            FTotalCredit = item.FTotalCredit,
                            Remarks = item.Remarks,
                            Paymode = item.Paymode,
                            BankCode = item.BankCode,
                            BankInDate = item.BankInDate,
                            BankInDateString = (item.BankInDate.HasValue) ? item.BankInDate.Value.ToERPdate() : string.Empty,
                            ChequeNo = item.ChequeNo,
                            ChequeDate = item.ChequeDate,
                            ChequeDateString = (item.ChequeDate.HasValue) ? item.ChequeDate.Value.ToERPdate() : string.Empty,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            TranType = item.TranType,
                            ReferenceNo = item.ReferenceNo,
                            ReferenceDate = item.ReferenceDate,
                            ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }
    }
}
