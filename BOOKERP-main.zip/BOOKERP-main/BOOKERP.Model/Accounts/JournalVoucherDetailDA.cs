﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class JournalVoucherDetailDA : CommonDA
    {
        // Get All
        public List<GE::JournalVoucherDetail> GetAllByCode(GE::ERPInputmodel inputdata)
        {
            List<GE::JournalVoucherDetail> _list = new List<GE.JournalVoucherDetail>();
            try
            {
                var _data = ERPMASTERDatabase().Account_JVDetail.Where(o => o.OrgId == inputdata.OrganisationId && o.JVNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.JournalVoucherDetail
                        {
                            OrgId = item.OrgId,
                            JVNo = item.JVNo,
                            SlNo = item.SlNo,
                            DrCr = item.DrCr,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            Debit = item.Debit,
                            Credit = item.Credit,
                            FDebit = item.FDebit,
                            FCredit = item.FCredit,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            Remarks = item.Remarks,
                            TranType = item.TranType,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }


        // Create or Update
        public string Save(GE::JournalVoucherDetail item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Account_SaveJVDetail(item.OrgId, item.JVNo, item.SlNo, item.DrCr, item.AccountNo, item.AccountName, item.Debit,
                    item.Credit, item.FDebit, item.FCredit, item.CurrencyCode, item.CurrencyRate, item.Remarks, item.TranType, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, item.OrgId);
            }
            return result;
        }
    }
}
