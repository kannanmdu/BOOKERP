﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class IncomeVoucherDetailDA : CommonDA
    {
        // Get All
        public List<GE::AccountVoucherDetail> GetAllByCode(GE::ERPInputmodel inputdata)
        {
            List<GE::AccountVoucherDetail> _list = new List<GE.AccountVoucherDetail>();
            try
            {
                var _data = ERPMASTERDatabase().Account_IncomeExpenseVoucherDetail.Where(o => o.TranType == "INC" && o.OrgId == inputdata.OrganisationId && o.TranNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.AccountVoucherDetail
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranType = item.TranType,
                            SlNo = item.SlNo,
                            AccountNo = item.GLCode,
                            AccountName = item.GLDescription,
                            Qty = item.Qty,
                            Price = item.Price,
                            SubTotal = item.SubTotal,
                            Tax = item.Tax,
                            NetTotal = item.NetTotal,
                            TaxCode = item.TaxCode,
                            TaxPerc = item.TaxPerc,
                            FPrice = item.FPrice,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }


        // Create or Update
        public string Save(GE::AccountVoucherDetail item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {

                var data = dBEntities.Account_SaveIncomeExpenseVoucherDetail(item.OrgId, item.TranNo, "INC", item.SlNo, item.AccountNo, item.AccountName, item.Qty, item.Price
                    , item.Total, 0, 0, item.SubTotal, item.Tax, item.NetTotal, item.TaxCode, item.TaxType, item.TaxPerc, item.FPrice, item.FTotal
                    , item.FSubTotal, item.FTax, item.FNetTotal, item.Remarks, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, item.OrgId);
            }
            return result;
        }
    }
}
