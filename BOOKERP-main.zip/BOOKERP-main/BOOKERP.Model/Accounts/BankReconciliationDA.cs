﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class BankReconciliationDA : CommonDA
    {
        public List<GE::GetAccountingDetail> GetAllReconciliationList(GE::ERPInputmodel inputdata)
        {
            List<GE::GetAccountingDetail> _list = new List<GE.GetAccountingDetail>();
            try
            {
                if (inputdata.TranDate != null)
                {
                    inputdata.TranDate = inputdata.TranDate != null ? inputdata.ToDateString.GetERPDateFormat() : null;
                }

                var _data = ERPMASTERDatabase().Account_GetReconciliation(inputdata.OrganisationId).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    var _Accdata = _data.FindAll(o => o.AccountNo != null && o.TranDate != null && o.AccountNo == inputdata.AccountNo && o.TranDate <= inputdata.TranDate).ToList();
                    if (_Accdata != null && _Accdata.Count > 0)
                    {
                        _data.ForEach(item =>
                        {

                            _list.Add(new GE.GetAccountingDetail
                            {
                                TranNo = item.TranNo,
                                TranDate = item.TranDate,
                                RefNo = item.RefNo,
                                RefName = item.RefName,
                                Type = item.Type,
                                PaidAmount = item.PaidAmount,
                                TranDateString = item.TranDate.HasValue ? item.TranDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                                AccountNo = item.AccountNo,
                                AccountName = item.AccountName,
                                Paymode = item.PayMode,
                                Bank = item.Bank,
                                ChequeNo = item.ChequeNo,
                                ChequeDateString = item.ChequeDate.HasValue ? item.ChequeDate.Value.ToString("dd/MM/yyyy") : item.TranDate.Value.ToString("dd/MM/yyyy"),
                                Remarks = item.Remarks
                            });
                        });
                    }

                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANKRECONCILIATION, inputdata.OrganisationId);
            }
            return _list;
        }
        public List<GE::BankReconciliation> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::BankReconciliation> _list = new List<GE.BankReconciliation>();
            try
            {
                string CurrencyName = string.Empty;
                var _data = ERPMASTERDatabase().Account_BankReconcileHeader.Where(o => o.OrgId == inputdata.OrganisationId).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.BankReconciliation
                        {
                            OrgId = item.OrgId,
                            BRNo = item.BRNo,
                            BRDate = item.BRDate,
                            BRDateString = item.BRDate.HasValue ? item.BRDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                            AccountNo = item.AccountNo,
                            OpeningBalance = item.OpeningBalance,
                            ClosingBalance = item.ClosingBalance,
                            DiferenceAmount = item.DiferenceAmount,
                            StatementEndDate = item.StatementEndDate,
                            StatementEndDateString = item.StatementEndDate.HasValue ? item.StatementEndDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                            OpeningAsperBook = item.OpeningAsperBook,
                            ClosingAsperBook = item.ClosingAsperBook,
                            DiferenceAsPerBook = item.DiferenceAsPerBook,
                            Status = item.Status,
                            TotalPayments = item.TotalPayments,
                            TotalReceipts = item.TotalReceipts,
                            CreateDate = item.CreateDate,
                            CreateUser = item.CreateUser,
                            ModifyDate = item.ModifyDate,
                            ModifyUser = item.ModifyUser
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANKRECONCILIATION, inputdata.OrganisationId);
            }
            return _list;
        }
        public GE::BankReconciliation GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::BankReconciliation _data = new GE.BankReconciliation();
            try
            {
                var item = ERPMASTERDatabase().Account_BankReconcileHeader.FirstOrDefault(o => o.BRNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);


                if (item != null)
                {
                    _data = (new GE.BankReconciliation
                    {
                        OrgId = item.OrgId,
                        BRNo = item.BRNo,
                        BRDate = item.BRDate,
                        BRDateString = item.BRDate.HasValue ? item.BRDate.Value.ToString("dd/MM/yyyy") : string.Empty,
                        AccountNo = item.AccountNo,
                        OpeningBalance = item.OpeningBalance,
                        ClosingBalance = item.ClosingBalance,
                        DiferenceAmount = item.DiferenceAmount,
                        StatementEndDate = item.StatementEndDate,
                        OpeningAsperBook = item.OpeningAsperBook,
                        ClosingAsperBook = item.ClosingAsperBook,
                        DiferenceAsPerBook = item.DiferenceAsPerBook,
                        Status = item.Status,
                        TotalPayments = item.TotalPayments,
                        TotalReceipts = item.TotalReceipts,
                        CreateDate = item.CreateDate,
                        CreateUser = item.CreateUser,
                        ModifyDate = item.ModifyDate,
                        ModifyUser = item.ModifyUser
                    });
                }


            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }


            return _data;
        }

        public string Save(GE::BankReconciliation header, List<GE::ERPInputmodel> list)
        {
            int listcount = 0;
            string Result = string.Empty;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (string.IsNullOrEmpty(header.BRNo))
                        {
                            header.BRNo = AutoTranNo(header.OrgId, header.BranchCode, "BankReconciliation");
                        }

                        string TranNo = SaveBRHeader(header, context);
                        if (!string.IsNullOrEmpty(TranNo))
                        {
                            if (list != null && list.Count > 0)
                            {
                                context.SaveChanges();
                                list.ForEach(_details =>
                                {
                                    _details.OrganisationId = header.OrgId;
                                    string res = UpdateBRNoToVoucher(_details, TranNo, header.CreateUser, context);
                                    if (res == TranNo)
                                        listcount = listcount + 1;
                                });
                                if (listcount == list.Count)
                                {

                                    Result = TranNo;
                                    context.SaveChanges();
                                    dbContextTransaction.Commit();

                                }
                            }

                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, header.CreateUser, BANKRECONCILIATION, header.OrgId);
            }
            return Result;
        }
        public string SaveBRHeader(GE::BankReconciliation item, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {


                var data = dBEntities.Account_SaveBankReconcilation(item.OrgId, item.BranchCode, item.BRNo, item.BRDate, item.AccountNo
                    , item.OpeningBalance, item.ClosingBalance, item.DiferenceAmount, item.StatementEndDate, item.OpeningAsperBook, item.ClosingAsperBook, item.DiferenceAsPerBook, item.Status, item.TotalPayments, item.TotalReceipts, item.CreateUser).FirstOrDefault();
                if (data != null)
                {
                    result = data.BRNo;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, item.CreateUser, INCOME, item.OrgId);
            }
            return result;
        }

        public string UpdateBRNoToVoucher(GE::ERPInputmodel item, string BRNo, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {

                var data = dBEntities.Account_UpdateBRToVoucher(BRNo, item.TranNo, item.OrganisationId, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, BANKRECONCILIATION, item.OrganisationId);
            }
            return result;
        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_BankReconcileHeader.FirstOrDefault(o => o.BRNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    int? orgid = Convert.ToInt32(item.OrgId);
                    var data = ERPMASTERDatabase().Account_RemoveBankReconciliation(item.BRNo, orgid, item.CreateUser).FirstOrDefault();
                    if (data.Result == item.BRNo)
                        result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, BANKRECONCILIATION, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
