﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class ChartOfAccountDA:CommonDA
    {
        // Get All
        public List<GE::Chartofaccount> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Chartofaccount> _list = new List<GE.Chartofaccount>();
            try
            {
                string CurrencyName = string.Empty;
                var _data = ERPMASTERDatabase().Account_CoaMaster.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderBy(o => o.SortOrder).ThenBy(o => o.GroupLevel).ThenBy(o => o.ParentAccountNo).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        //if (!string.IsNullOrEmpty(item.CurrencyCode))
                        //    CurrencyName = ERPMASTERDatabase().Currrencies.FirstOrDefault(o => o.Code == item.CurrencyCode).Name;
                        _list.Add(new GE.Chartofaccount
                        {
                            OrgId = item.OrgId,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            ParentAccountNo = item.ParentAccountNo,
                            DebitCredit = item.AccountType,
                            SortOrder = item.SortOrder,
                            GroupLevel = item.GroupLevel,
                            IsHavePayments = item.HavePayment,
                            IsActive = item.IsActive,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyName = CurrencyName,
                            CurrencyRate = item.CurrencyRate,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            AccountType = item.AccountType
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CHARTOFACCOUNT, inputdata.OrganisationId);
            }
            return _list;
        }
        public List<GE::GetChildAccount> GetAllAccount(GE::ERPInputmodel inputdata)
        {
            List<GE::GetChildAccount> _list = new List<GE.GetChildAccount>();
            try
            {
                string CurrencyName = string.Empty;

                var _data = ERPMASTERDatabase().SP_Account_GetChildAccount(inputdata.OrganisationId).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.GetChildAccount
                        {
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            IsHavePayments = item.HavePayment
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CHARTOFACCOUNT, inputdata.OrganisationId);
            }
            return _list;
        }

        // Get by Code
        public GE::Chartofaccount GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Chartofaccount _data = new GE.Chartofaccount();
            try
            {
                var item = ERPMASTERDatabase().Account_CoaMaster.FirstOrDefault(o => o.AccountNo == inputdata.TransactionNo);
                if (item != null)
                {
                    _data = (new GE.Chartofaccount
                    {
                        OrgId = item.OrgId,
                        AccountNo = item.AccountNo,
                        AccountName = item.AccountName,
                        ParentAccountNo = item.ParentAccountNo,
                        DebitCredit = item.AccountType,
                        AccountType = item.AccountType,
                        SortOrder = item.SortOrder,
                        GroupLevel = item.GroupLevel,
                        IsNonTrading = item.IsNonTrading,
                        IsHavePayments = item.HavePayment,
                        IsActive = item.IsActive,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                    }); ;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CHARTOFACCOUNT, inputdata.OrganisationId);
            }
            return _data;
        }
        // Create or Update
        public string Save(GE::Chartofaccount item, string user, int OrganizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Account_CoaMaster.FirstOrDefault(o => o.AccountNo == item.AccountNo && o.OrgId == OrganizationId);
                    if (_data != null)
                    {
                        _data.AccountName = item.AccountName;
                        _data.ParentAccountNo = item.ParentAccountNo;
                        _data.HavePayment = item.IsHavePayments;
                        _data.AccountType = item.AccountType;
                        _data.SortOrder = item.SortOrder;
                        _data.GroupLevel = item.GroupLevel;
                        _data.IsNonTrading = item.IsNonTrading;

                        _data.IsActive = item.IsActive;
                        _data.CurrencyCode = item.CurrencyCode;
                        _data.CurrencyRate = item.CurrencyRate;
                        _data.ChangedOn = DateTime.Now;
                        _data.ChangedBy = user;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {

                        string groupno = ""; string groupnumber = string.Empty; string AccountCode = string.Empty;
                        if (item.AccountNo == "")
                        {
                            groupno = GetAccountCode(item.ParentAccountNo, OrganizationId);
                            string[] strArrtranno = groupno.Split('0');
                            groupnumber = strArrtranno[0];

                            string SQuery = " select Replicate( 0 ,  4 - Len(Max(SubString(AccountNo ,CharIndex('-' , AccountNo) + 1 , 50)) + 1))  + ";
                            SQuery += " Cast(Max(SubString(AccountNo ,CharIndex('-' , AccountNo) + 1 , 50)) + 1  as Varchar(10)) as AutoAccountCode from Account_CoaMaster ";
                            SQuery += " where AccountNo like '" + groupnumber + "%' And OrgId='" + OrganizationId + "'";


                            AccountCode = ERPMASTERDatabase().Database.SqlQuery<string>(SQuery).FirstOrDefault<string>();

                            if (string.IsNullOrEmpty(AccountCode)) {
                                AccountCode = "0001";
                            }
                            item.AccountNo = groupnumber + AccountCode;


                            int? grouplevel = GetGroupLevel(item.ParentAccountNo, OrganizationId);
                            grouplevel = grouplevel + 1;
                            item.GroupLevel = grouplevel;

                        }

                        Account_CoaMaster chartofaccount = new Account_CoaMaster()
                        {

                            OrgId = OrganizationId,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            ParentAccountNo = item.ParentAccountNo,
                            AccountType = item.AccountType,
                            SortOrder = item.SortOrder,
                            GroupLevel = item.GroupLevel,
                            IsNonTrading = item.IsNonTrading,

                            HavePayment = item.IsHavePayments,

                            IsActive = item.IsActive,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CreatedOn = DateTime.Now,
                            CreatedBy = user,
                            ChangedOn = DateTime.Now,
                            ChangedBy = user,
                        };
                        ERPMASTERDatabase().Account_CoaMaster.Add(chartofaccount);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, CHARTOFACCOUNT, OrganizationId);
            }
            return result;
        }
        public int? GetGroupLevel(string groupno, int Code)
        {
            int? _groupno = 0;
            var SubSource = (from _data in ERPMASTERDatabase().Account_CoaMaster

                             where _data.OrgId == Code && _data.AccountNo == groupno
                             select _data).FirstOrDefault();
            if (SubSource != null)
            {
                _groupno = SubSource.GroupLevel != null ? SubSource.GroupLevel : 0;
            }
            return _groupno;
        }
        public string GetAccountCode(string groupno, int Code)
        {
            string _groupprefix = string.Empty;
            var SubSource = (from _data in ERPMASTERDatabase().Account_CoaMaster

                             where _data.OrgId == Code && _data.AccountNo == groupno
                             select _data).FirstOrDefault();
            if (SubSource != null)
            {
                _groupprefix = SubSource.AccountNo != null ? SubSource.AccountNo : "";
            }
            return _groupprefix;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_CoaMaster.FirstOrDefault(o => o.AccountNo == inputdata.TransactionNo);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CHARTOFACCOUNT, inputdata.OrganisationId);
            }
            return result;
        }
        //Make Active
        public string MakeActive(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_CoaMaster.FirstOrDefault(o => o.AccountNo == inputdata.TransactionNo);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, CHARTOFACCOUNT, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
