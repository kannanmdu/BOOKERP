﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class ExpenseVoucherManagerDA : CommonDA
    {
        // Get All
        public List<GE::AccountVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.ExpenseVoucherHeaderDA().GetAll(inputdata);
        }
        public string Save(GE::AccountVoucherHeader header, List<GE::AccountVoucherDetail> _accountdetails, string user)
        {
            string Result = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (string.IsNullOrEmpty(header.TranNo))
                        {
                            header.TranNo = AutoTranNo(header.OrgId, header.LocationCode, "Expense");
                        }

                        string TranNo = new DA.ExpenseVoucherHeaderDA().Save(header, user, context);
                        if (!string.IsNullOrEmpty(TranNo))
                        {
                            context.SaveChanges();
                            _accountdetails.ForEach(_details =>
                            {
                                _details.TranNo = header.TranNo;
                                _details.OrgId = header.OrgId;
                                string res = new ExpenseVoucherDetailDA().Save(_details, user, context);
                                if (res == TranNo)
                                    listcount = listcount + 1;
                            });

                            if (listcount == _accountdetails.Count)
                            {

                                Result = TranNo;
                                context.SaveChanges();
                                dbContextTransaction.Commit();

                            }

                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, header.OrgId);
            }
            return Result;
        }
        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.ExpenseVoucherHeaderDA().Remove(inputdata);
        }
        public GE::AccountVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.ExpenseVoucherHeaderDA().GetTransactionbyCode(inputdata);
        }
        public List<GE::AccountVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return new DA.ExpenseVoucherHeaderDA().GetSearchData(inputdata);
        }
    }
}
