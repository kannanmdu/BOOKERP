﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;
using DA = BOOKERP.Model;

namespace BOOKERP.Model
{
    public class JournalVoucherManagerDA : CommonDA
    {
        // Get All
        public List<GE::JournalVoucherHeader> GetAll(GE::ERPInputmodel inputdata)
        {
            return new DA.JournalVoucherHeaderDA().GetAll(inputdata);
        }
        public string Save(GE::JournalVoucherHeader header, List<GE::JournalVoucherDetail> jvdetails, string user)
        {
            string Result = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (string.IsNullOrEmpty(header.JVNo))
                        {
                            header.JVNo = AutoTranNo(header.OrgId, header.LocationCode, "JournalVoucher");
                        }

                        string TranNo = new DA.JournalVoucherHeaderDA().Save(header, user, context);
                        if (!string.IsNullOrEmpty(TranNo))
                        {
                            context.SaveChanges();
                            jvdetails.ForEach(_details =>
                            {
                                _details.JVNo = header.JVNo;
                                _details.OrgId = header.OrgId;
                                string res = new JournalVoucherDetailDA().Save(_details, user, context);
                                if (res == TranNo)
                                    listcount = listcount + 1;
                            });

                            if (listcount == jvdetails.Count)
                            {
                                Result = TranNo;
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                            }
                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, header.OrgId);
            }
            return Result;

        }

        public string Remove(GE::ERPInputmodel inputdata)
        {
            return new DA.JournalVoucherHeaderDA().Remove(inputdata);
        }
        public GE::JournalVoucherHeader GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            return new DA.JournalVoucherHeaderDA().GetTransactionbyCode(inputdata);
        }
        public List<GE::JournalVoucherHeader> GetSearchData(GE::ERPInputmodel inputdata)
        {
            return new DA.JournalVoucherHeaderDA().GetSearchData(inputdata);
        }
    }
}
