﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class PaymentReceiptVoucherDA: CommonDA
    {
        // Get All
        public List<GE::PaymentReceiptVoucherDetails> GetAllByCode(GE::ERPInputmodel inputdata)
        {
            List<GE::PaymentReceiptVoucherDetails> _list = new List<GE.PaymentReceiptVoucherDetails>();
            try
            {
                var _data = ERPMASTERDatabase().Account_PaymentReceiptVoucherDetail.Where(o => o.OrgId == inputdata.OrganisationId && o.TranNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.PaymentReceiptVoucherDetails
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranType = item.TranType,
                            SlNo = item.SlNo,
                            GLCode = item.GLCode,
                            GLDescription = item.GLDescription,
                            Qty = item.Qty,
                            Price = item.Price,
                            Total = item.Total,
                            SubTotal = item.SubTotal,
                            DiscountAmount = item.DiscountAmount,
                            DiscountPerc = item.DiscountPerc,
                            Tax = item.Tax,
                            NetTotal = item.NetTotal,
                            TaxCode = item.TaxCode,
                            TaxType = item.TaxType,
                            TaxPerc = item.TaxPerc,
                            FPrice = item.FPrice,
                            FTotal = item.FTotal,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            ItemRemarks = item.ItemRemarks,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn

                        });
                    });

                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }
        public List<GE::PaymentReceiptVoucherHeaders> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::PaymentReceiptVoucherHeaders> _list = new List<GE.PaymentReceiptVoucherHeaders>();
            try
            {
                var _data = ERPMASTERDatabase().Account_PaymentReceiptVoucherHeader.Where(o => o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.PaymentReceiptVoucherHeaders
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                            TranType = item.TranType,
                            CustomerSupplierCode = item.CustomerSupplierCode,
                            CustomerSupplierName = item.CustomerSupplierName,
                            BranchCode = item.BranchCode,
                            PaymentAccountNo = item.PaymentAccountNo,
                            SubTotal = item.SubTotal == null ? 0 : item.SubTotal,
                            Tax = item.Tax == null ? 0 : item.Tax,
                            NetTotal = item.NetTotal == null ? 0 : item.NetTotal,
                            BankCode = item.BankCode,
                            PaymentMode = item.PaymentMode,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            ChequeNo = item.ChequeNo,
                            Chequedate = item.Chequedate,
                            ChequeDateString = (item.Chequedate.HasValue) ? item.Chequedate.Value.ToERPdate() : string.Empty,
                            ReferenceNo = item.ReferenceNo,
                            ReferenceDate = item.ReferenceDate,
                            ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                            Remarks = item.Remarks,
                            Total = item.Total,
                            DiscountAmount = item.DiscountAmount,
                            PaidAmount = item.PaidAmount,
                            FPaidAmount = item.FPaidAmount,
                            FTotal = item.FTotal,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn,
                            BRNo = item.BRNo
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }
        public string Save(GE::PaymentReceiptVoucherHeaders header, List<GE::PaymentReceiptVoucherDetails> _accountdetails, string user)
        {
            string Result = string.Empty;
            int listcount = 0;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        if (string.IsNullOrEmpty(header.TranNo))
                        {
                            if (header.TranType == "PV")
                                header.TranNo = AutoTranNo(header.OrgId, header.BranchCode, "Payment Voucher");
                            else
                                header.TranNo = AutoTranNo(header.OrgId, header.BranchCode, "Receipt Voucher");
                        }

                        string TranNo = HeaderSave(header, user, context);
                        if (!string.IsNullOrEmpty(TranNo))
                        {
                            context.SaveChanges();
                            _accountdetails.ForEach(_details =>
                            {
                                _details.TranNo = header.TranNo;
                                _details.OrgId = header.OrgId;
                                string res = DetailSave(_details, user, context);
                                if (res == TranNo)
                                    listcount = listcount + 1;
                            });

                            if (listcount == _accountdetails.Count)
                            {

                                Result = TranNo;
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                            }
                        }
                        else
                            dbContextTransaction.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, header.OrgId);
            }
            return Result;

        }
        // Create or Update
        public string DetailSave(GE::PaymentReceiptVoucherDetails item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Account_SavePaymentreceiptVoucherDetail(item.OrgId, item.TranNo, item.TranType, item.SlNo, item.GLCode, item.GLDescription,
                    item.Qty, item.Price, item.Total, item.DiscountAmount, item.DiscountPerc, item.SubTotal, item.Tax, item.NetTotal, item.TaxCode, item.TaxType,
                    item.TaxPerc, item.FPrice, item.FTotal, item.FSubTotal, item.FTax, item.FNetTotal, item.ItemRemarks, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, item.OrgId);
            }
            return result;
        }
        public string HeaderSave(GE::PaymentReceiptVoucherHeaders item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Account_SavePaymentReceiptVoucherHeader(item.OrgId, item.BranchCode, item.TranNo, item.TranDate, item.TranType, item.CustomerSupplierCode, item.CustomerSupplierName, item.PaymentAccountNo, item.PaymentMode, item.BankCode, item.ChequeNo,
                    item.Chequedate, item.BankInDate, item.ReferenceNo, item.ReferenceDate, item.Remarks, item.Total, item.DiscountAmount, item.SubTotal, item.Tax, item.NetTotal, item.PaidAmount, item.CurrencyCode, item.CurrencyRate, item.CurrencyValue, item.FTotal, item.FSubTotal, item.FTax,
                    item.FNetTotal, item.FPaidAmount, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }

            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, VOUCHER, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_PaymentReceiptVoucherHeader.FirstOrDefault(o => o.TranType == inputdata.TranType && o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                var ditem = ERPMASTERDatabase().Account_PaymentReceiptVoucherDetail.Where(o => o.TranType == inputdata.TranType && o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    ERPMASTERDatabase().Account_PaymentReceiptVoucherHeader.Remove(item);
                    ERPMASTERDatabase().Account_PaymentReceiptVoucherDetail.RemoveRange(ditem);
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return result;
        }
        public GE::PaymentReceiptVoucherHeaders GetTransactionbyCode(GE::ERPInputmodel inputdata)
        {
            GE::PaymentReceiptVoucherHeaders _data = new GE.PaymentReceiptVoucherHeaders();
            List<GE::PaymentReceiptVoucherDetails> _acclist = new List<GE.PaymentReceiptVoucherDetails>();
            try
            {

                var item = ERPMASTERDatabase().Account_PaymentReceiptVoucherHeader.FirstOrDefault(o => o.TranNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType);
                var accountitem = ERPMASTERDatabase().Account_PaymentReceiptVoucherDetail.Where(o => o.OrgId == inputdata.OrganisationId && o.TranNo == inputdata.TranNo && o.TranType == inputdata.TranType).ToList();

                if (item != null)
                {
                    _data = (new GE.PaymentReceiptVoucherHeaders
                    {
                        OrgId = item.OrgId,
                        TranNo = item.TranNo,
                        TranDate = item.TranDate,
                        TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                        TranType = item.TranType,
                        CustomerSupplierCode = item.CustomerSupplierCode,
                        CustomerSupplierName = item.CustomerSupplierName,
                        BranchCode = item.BranchCode,
                        PaymentAccountNo = item.PaymentAccountNo,
                        SubTotal = item.SubTotal,
                        Tax = item.Tax,
                        NetTotal = item.NetTotal,
                        BankCode = item.BankCode,
                        PaymentMode = item.PaymentMode,
                        CurrencyCode = item.CurrencyCode,
                        CurrencyRate = item.CurrencyRate,
                        CurrencyValue = item.CurrencyValue,
                        FSubTotal = item.FSubTotal,
                        FTax = item.FTax,
                        FNetTotal = item.FNetTotal,
                        ChequeNo = item.ChequeNo,
                        Chequedate = item.Chequedate,
                        ChequeDateString = (item.Chequedate.HasValue) ? item.Chequedate.Value.ToERPdate() : string.Empty,
                        ReferenceNo = item.ReferenceNo,
                        ReferenceDate = item.ReferenceDate,
                        ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                        BankInDate = item.BankInDate,
                        BankInDateString = (item.BankInDate.HasValue) ? item.BankInDate.Value.ToERPdate() : string.Empty,
                        Remarks = item.Remarks,
                        Total = item.Total,
                        DiscountAmount = item.DiscountAmount,
                        PaidAmount = item.PaidAmount,
                        FPaidAmount = item.FPaidAmount,
                        FTotal = item.FTotal,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn
                    });
                }

                if (accountitem != null && accountitem.Count > 0)
                {
                    accountitem.ForEach(ditem =>
                    {
                        _acclist.Add(new GE.PaymentReceiptVoucherDetails
                        {
                            OrgId = ditem.OrgId,
                            TranNo = ditem.TranNo,
                            TranType = ditem.TranType,
                            SlNo = ditem.SlNo,
                            GLCode = ditem.GLCode,
                            GLDescription = ditem.GLDescription,
                            Qty = ditem.Qty,
                            Price = ditem.Price,
                            Total = ditem.Total,
                            SubTotal = ditem.SubTotal,
                            DiscountAmount = ditem.DiscountAmount,
                            DiscountPerc = ditem.DiscountPerc,
                            Tax = ditem.Tax,
                            NetTotal = ditem.NetTotal,
                            TaxCode = ditem.TaxCode,
                            TaxType = ditem.TaxType,
                            TaxPerc = ditem.TaxPerc,
                            FPrice = ditem.FPrice,
                            FTotal = ditem.FTotal,
                            FSubTotal = ditem.FSubTotal,
                            FTax = ditem.FTax,
                            FNetTotal = ditem.FNetTotal,
                            ItemRemarks = ditem.ItemRemarks,
                            CreatedBy = ditem.CreatedBy,
                            CreatedOn = ditem.CreatedOn,
                            ChangedBy = ditem.ChangedBy,
                            ChangedOn = ditem.ChangedOn
                        });
                    });
                }

                _data.PaymentReceiptVoucherDetail = _acclist;
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _data;
        }
        public List<GE::PaymentReceiptVoucherHeaders> GetSearchData(GE::ERPInputmodel inputdata)
        {
            List<GE::PaymentReceiptVoucherHeaders> _list = new List<GE.PaymentReceiptVoucherHeaders>();
            try
            {
                var _data = ERPMASTERDatabase().Account_PaymentReceiptVoucherHeader.Where(o => o.OrgId == inputdata.OrganisationId && o.TranType == inputdata.TranType).OrderByDescending(o => o.CreatedOn).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.PaymentReceiptVoucherHeaders
                        {
                            OrgId = item.OrgId,
                            TranNo = item.TranNo,
                            TranDate = item.TranDate,
                            TranDateString = (item.TranDate.HasValue) ? item.TranDate.Value.ToERPdate() : string.Empty,
                            TranType = item.TranType,
                            CustomerSupplierCode = item.CustomerSupplierCode,
                            CustomerSupplierName = item.CustomerSupplierName,
                            BranchCode = item.BranchCode,
                            PaymentAccountNo = item.PaymentAccountNo,
                            SubTotal = item.SubTotal == null ? 0 : item.SubTotal,
                            Tax = item.Tax == null ? 0 : item.Tax,
                            NetTotal = item.NetTotal == null ? 0 : item.NetTotal,
                            BankCode = item.BankCode,
                            PaymentMode = item.PaymentMode,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            FSubTotal = item.FSubTotal,
                            FTax = item.FTax,
                            FNetTotal = item.FNetTotal,
                            ChequeNo = item.ChequeNo,
                            Chequedate = item.Chequedate,
                            ChequeDateString = (item.Chequedate.HasValue) ? item.Chequedate.Value.ToERPdate() : string.Empty,
                            ReferenceNo = item.ReferenceNo,
                            ReferenceDate = item.ReferenceDate,
                            ReferenceDateString = (item.ReferenceDate.HasValue) ? item.ReferenceDate.Value.ToERPdate() : string.Empty,
                            BankInDate = item.BankInDate,
                            BankInDateString = (item.BankInDate.HasValue) ? item.BankInDate.Value.ToERPdate() : string.Empty,
                            Remarks = item.Remarks,
                            Total = item.Total,
                            DiscountAmount = item.DiscountAmount,
                            PaidAmount = item.PaidAmount,
                            FPaidAmount = item.FPaidAmount,
                            FTotal = item.FTotal,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, VOUCHER, inputdata.OrganisationId);
            }
            return _list;
        }
    }
}
