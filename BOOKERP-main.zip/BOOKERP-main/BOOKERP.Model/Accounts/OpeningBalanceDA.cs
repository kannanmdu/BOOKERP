﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class OpeningBalanceDA : CommonDA
    {
        public List<GE::OpeningBalance> GetOpeningBalanceDetails(GE::ERPInputmodel inputdata)
        {
            List<GE::OpeningBalance> _list = new List<GE.OpeningBalance>();
            try
            {
                string CurrencyName = string.Empty;
                var _data = ERPMASTERDatabase().Account_GetOpeningBalance(inputdata.OrganisationId, inputdata.FYear, inputdata.FinancialYearFromDate, inputdata.FinancialYearToDate).ToList();
                var _accountData = ERPMASTERDatabase().Account_COAList.Where(x => x.OrgId == inputdata.OrganisationId && x.G1GroupName != "EXPENSES" && x.G1GroupName != "INCOME").ToList();

                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        int Sortorder = 0;
                        string _accountType = string.Empty;
                        var accountType = _accountData.Where(x => x.G3GroupNo == item.AccountNo).Select(x => x.G1GroupName).FirstOrDefault();
                        var groupLevel = _accountData.Where(x => x.G3GroupNo == item.AccountNo).Select(x => x.G2GroupName).FirstOrDefault();

                        _list.Add(new GE.OpeningBalance
                        {
                            OrgId = item.OrgId,
                            AccountNo = item.AccountNo,
                            AccountName = item.AccountName,
                            FYear = item.FYear,
                            FinancialYearFromDate = item.FinancialYearFromDate,
                            FinancialYearFromDateString = (item.FinancialYearFromDate != null) ? item.FinancialYearFromDate.ToERPdate() : string.Empty,
                            FinancialYearToDate = item.FinancialYearToDate,
                            FinancialYearToDateString = (item.FinancialYearToDate != null) ? item.FinancialYearToDate.ToERPdate() : string.Empty,
                            CurrencyCode = item.CurrencyCode,
                            CurrencyRate = item.CurrencyRate,
                            CurrencyValue = item.CurrencyValue,
                            Credit = item.Credit,
                            FDebit = item.FDebit,
                            Debit = item.Debit,
                            FCredit = item.FCredit,
                            AccountType = accountType,
                            SortOrder = Sortorder,
                            GroupLevel = groupLevel,
                            CreatedBy = item.CreatedBy,
                            CreatedOn = item.CreatedOn,
                            ChangedBy = item.ChangedBy,
                            ChangedOn = item.ChangedOn
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, OPENINGBALANCE, inputdata.OrganisationId);
            }
            return _list;
        }
        public string Save(List<GE::OpeningBalance> _accountdetails, string user, int orgId)
        {
            List<GE::OpeningBalance> listOpeningBalance = new List<GE.OpeningBalance>();
            string Result = string.Empty;
            try
            {
                using (var context = new BOOKMERCHANT_DEVEntities())
                {
                    _accountdetails.ForEach(_details =>
                    {
                        _details.OrgId = orgId;
                        _details.FinancialYearFromDate = !string.IsNullOrEmpty(_details.FinancialYearFromDateString) ? _details.FinancialYearFromDateString.GetERPDateFormat() : DateTime.Now;
                        _details.FinancialYearToDate = !string.IsNullOrEmpty(_details.FinancialYearToDateString) ? _details.FinancialYearToDateString.GetERPDateFormat() : DateTime.Now;
                        string res = OpeningBalanceSave(_details, user, context);
                        Result = res;
                        context.SaveChanges();
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, OPENINGBALANCE, orgId);
            }
            return Result;
        }
        public string OpeningBalanceSave(GE.OpeningBalance item, string user, BOOKMERCHANT_DEVEntities dBEntities)
        {
            string result = string.Empty;
            try
            {
                var data = dBEntities.Account_SaveOpeningBalance(item.OrgId, item.AccountNo, item.FYear, item.FinancialYearFromDate, item.FinancialYearToDate,
                    item.CurrencyCode, item.CurrencyRate, item.CurrencyValue, item.Debit, item.Credit, item.FDebit, item.FCredit, user).FirstOrDefault();
                if (data != null)
                {
                    result = data.Result;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, OPENINGBALANCE, item.OrgId);
            }
            return result;
        }
        // Delete
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Account_CoaOpeningBalance.FirstOrDefault(o => o.AccountNo == inputdata.TranNo);
                if (item != null)
                {
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, OPENINGBALANCE, inputdata.OrganisationId);
            }
            return result;
        }
    }
}
