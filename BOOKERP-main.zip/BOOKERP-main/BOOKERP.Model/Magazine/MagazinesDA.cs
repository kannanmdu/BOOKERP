﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;


namespace BOOKERP.Model
{
    public class MagazinesDA : CommonDA
    {
        // Get All
        public List<GE::Magazines> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Magazines> _list = new List<GE.Magazines>();
            try
            {
                //var _data = ERPMASTERDatabase().Magazines.Where(o => o.IsActive == inputdata.IsActive && o.OrgId == inputdata.OrganisationId).OrderByDescending(o => o.CreatedOn).ToList();
                var _data = (from a in ERPMASTERDatabase().Magazines.Where(o => o.IsActive == inputdata.IsActive)
                             join b in ERPMASTERDatabase().Master_Category
                             on a.Category equals b.Code into co
                             from b in co.DefaultIfEmpty()
                             where a.OrgId == inputdata.OrganisationId
                             orderby a.CreatedOn descending
                             select new { a, b }).ToList();
                if (_data != null && _data.Count() > 0)
                {
                    _data.ForEach(item =>
                    {
                        _list.Add(new GE.Magazines
                        {
                            OrgId = item.a.OrgId,
                            BranchCode = item.a.BranchCode,
                            MagazineId = item.a.MagazineId,
                            MagazineCode = item.a.MagazineCode,
                            MagazineName = item.a.MagazineName,
                            ShortDescription = item.a.ShortDescription,
                            LongDescription = item.a.LongDescription,
                            BarCode = item.a.BarCode,
                            Title = item.a.Title,
                            Category = item.a.Category,
                            SubCategoryCode = item.a.SubCategoryCode,
                            Publishcurrency = item.a.Publishcurrency,
                            CurrencyValue = item.a.CurrencyValue,
                            CurrencyRate = item.a.CurrencyRate,
                            PublishPrice = item.a.PublishPrice != null ? item.a.PublishPrice : 0,
                            Price = item.a.Price != null ? item.a.Price : 0,
                            ISSN = item.a.ISSN,
                            FrequencyCode = item.a.FrequencyCode,
                            FrequencyValue = item.a.FrequencyValue,
                            CountryCode = item.a.CountryCode,
                            PriceWGST = item.a.PriceWGST != null ? item.a.PriceWGST : 0,
                            PriceWOGST = item.a.PriceWOGST != null ? item.a.PriceWOGST : 0,
                            UnitPrice = item.a.UnitPrice != null ? item.a.UnitPrice : 0,
                            Postal = item.a.Postal != null ? item.a.Postal : 0,
                            IsActive = item.a.IsActive,
                            CategoryName = item.b != null ? item.b.Name : string.Empty,
                            CreatedBy = item.a.CreatedBy,
                            CreatedOn = item.a.CreatedOn,
                            ChangedBy = item.a.ChangedBy,
                            ChangedOn = item.a.ChangedOn,
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, MAGAZINES, inputdata.OrganisationId);
            }

            return _list;
        }

        // save and update the magazines details
        public string Save(GE::Magazines item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().Magazines.FirstOrDefault(o => o.MagazineId == item.MagazineId && o.OrgId == organizationId);
                    if (_data != null)
                    {
                        _data.BranchCode = item.BranchCode;
                        _data.MagazineId = item.MagazineId;
                        _data.MagazineCode = item.MagazineCode;
                        _data.MagazineName = item.MagazineName;
                        _data.ShortDescription = item.ShortDescription;
                        _data.LongDescription = item.LongDescription;
                        _data.BarCode = item.BarCode;
                        _data.Title = item.Title;
                        _data.Category = item.Category;
                        _data.SubCategoryCode = item.SubCategoryCode;
                        _data.Publishcurrency = item.Publishcurrency;
                        _data.CurrencyValue = item.CurrencyValue;
                        _data.CurrencyRate = item.CurrencyRate;
                        _data.PublishPrice = item.PublishPrice;
                        _data.Price = item.Price;
                        _data.IsActive = item.IsActive;
                        _data.ISSN = item.ISSN;
                        _data.FrequencyCode = item.FrequencyCode;
                        _data.FrequencyValue = item.FrequencyValue;
                        _data.CountryCode = item.CountryCode;
                        _data.PriceWGST = item.PriceWGST;
                        _data.PriceWOGST = item.PriceWOGST;
                        _data.UnitPrice = item.UnitPrice;
                        _data.Postal = item.Postal;
                        _data.ChangedBy = user;
                        _data.ChangedOn = DateTime.Now;
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(item.MagazineId))
                        {
                            var autoCode = GetMasterNextNo(organizationId, MAGAZINES);
                            item.MagazineId = "MA-"+autoCode;
                        }
                        Magazine magazine = new Magazine()
                        {
                            OrgId = organizationId,
                            BranchCode = item.BranchCode,
                            MagazineId = item.MagazineId,
                            MagazineName = item.MagazineName,
                            MagazineCode = item.MagazineCode,
                            ShortDescription = item.ShortDescription,
                            LongDescription = item.LongDescription,
                            BarCode = item.BarCode,
                            Title = item.Title,
                            Category = item.Category,
                            SubCategoryCode = item.SubCategoryCode,
                            Publishcurrency = item.Publishcurrency,
                            CurrencyValue = item.CurrencyValue,
                            CurrencyRate = item.CurrencyRate,
                            PublishPrice = item.PublishPrice != null ? item.PublishPrice : 0,
                            Price = item.Price != null ? item.Price : 0,
                            IsActive = item.IsActive,
                            ISSN = item.ISSN,
                            FrequencyCode = item.FrequencyCode,
                            FrequencyValue = item.FrequencyValue,
                            CountryCode = item.CountryCode,
                            PriceWGST = item.PriceWGST,
                            PriceWOGST = item.PriceWOGST,
                            UnitPrice = item.UnitPrice,
                            Postal = item.Postal,
                            CreatedBy = user,
                            CreatedOn = DateTime.Now,
                            ChangedBy = user,
                            ChangedOn = DateTime.Now
                        };
                        ERPMASTERDatabase().Magazines.Add(magazine);
                        ERPMASTERDatabase().SaveChanges();
                        result = PASS;
                    }
                }
            }

            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, MAGAZINES, organizationId);
            }

            return result;
        }

        //Edit the magazines details
        public GE::Magazines GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Magazines _data = new GE.Magazines();
            try
            {
                var item = ERPMASTERDatabase().Magazines.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.MagazineId == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Magazines
                    {
                        OrgId = item.OrgId,
                        BranchCode = item.BranchCode,
                        MagazineId = item.MagazineId,
                        MagazineCode = item.MagazineCode,
                        MagazineName = item.MagazineName,
                        ShortDescription = item.ShortDescription,
                        LongDescription = item.LongDescription,
                        BarCode = item.BarCode,
                        Title = item.Title,
                        Category = item.Category,
                        SubCategoryCode = item.SubCategoryCode,
                        Publishcurrency = item.Publishcurrency,
                        CurrencyValue = item.CurrencyValue,
                        CurrencyRate = item.CurrencyRate,
                        PublishPrice = item.PublishPrice != null ? item.PublishPrice : 0,
                        Price = item.Price != null ? item.Price : 0,
                        ISSN = item.ISSN,
                        FrequencyCode = item.FrequencyCode,
                        FrequencyValue = item.FrequencyValue,
                        CountryCode = item.CountryCode,
                        PriceWGST = item.PriceWGST != null ? item.PriceWGST : 0,
                        PriceWOGST = item.PriceWOGST != null ? item.PriceWOGST : 0,
                        UnitPrice = item.UnitPrice != null ? item.UnitPrice : 0,
                        Postal = item.Postal != null ? item.Postal : 0,
                        IsActive = item.IsActive,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, MAGAZINES, inputdata.OrganisationId);
            }
            return _data;
        }

        //Delete the magazines details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Magazines.FirstOrDefault(o => o.MagazineId == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, MAGAZINES, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the magazines details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Magazines.FirstOrDefault(o => o.MagazineId == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, MAGAZINES, inputData.OrganisationId);
            }
            return result;
        }
    }
}
