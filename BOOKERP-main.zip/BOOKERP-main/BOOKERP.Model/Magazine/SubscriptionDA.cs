﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GE = BOOKERP.Entities;

namespace BOOKERP.Model
{
    public class SubscriptionDA : CommonDA
    {
        // Get All
        public List<GE::Subscription> GetAll(GE::ERPInputmodel inputdata)
        {
            List<GE::Subscription> _list = new List<GE.Subscription>();
            try
            {
                var query = "Sp_GetSubscriptionList";
                var param = new DynamicParameters();
                param.Add("@OrgId", inputdata.OrganisationId); 
                param.Add("@User", inputdata.LoginUser);
                param.Add("@IsActive", inputdata.IsActive);
                var list = SqlMapper.Query<GE.Subscription>(GetConnection, query, param, commandType: CommandType.StoredProcedure);
                GetConnection.Close();
                return list.ToList();
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBSCRIPTION, inputdata.OrganisationId);
            }

            return _list;
        }

        // save and update the subscription details
        public string Save(GE::Subscription item, string user, int organizationId)
        {
            string result = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(item.DocNo))
                {
                    var autoCode = GetMasterNextNo(organizationId, SUBSCRIPTION);
                    item.DocNo = autoCode;
                }
                if (item != null)
                {
                    var _data = ERPMASTERDatabase().SP_SubscriptionSave(item.OrgId, item.DocNo, item.DocName, item.DocDate, item.FinMon, item.FinYear,
                        item.CustomerCode, item.CustomerName, item.Status, item.IsActive, item.IsInterCO,item.SubCode, item.SubName, item.Total,
                        item.Sent, item.InvPrice, item.InvPost, item.Remarks, item.SManCode, item.SManName, item.Contact, item.ContactName,
                        item.Telephone, item.UpdatedBy, item.DateUpdated, item.ApprovedBy, item.DateApproved, item.DeliveryAddress1, item.DeliveryAddress2, item.DeliveryAddress3,
                        item.DeliveryCity,item.DeliveryCountry, item.DeliveryPostalCode, item.PostalAddress1, item.PostalAddress2, item.PostalAddress3, item.PostalCity,
                        item.PostalCountry, item.PostalPostalCode, item.IssPerYear, item.FrequencyCode, item.FrequencyValue, item.Price, item.UnitPrice, item.Post,
                        item.Postage, item.Cost, item.UnitCost, item.LastDate, item.NextDate, item.DueDays, user).FirstOrDefault();
                    if (_data != null)
                    {
                        result = _data.Result;
                    }
                }      
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, user, SUBSCRIPTION, organizationId);
            }

            return result;
        }

        //Edit the subscription details
        public GE::Subscription GetbyCode(GE::ERPInputmodel inputdata)
        {
            GE::Subscription _data = new GE.Subscription();
            try
            {
                var item = ERPMASTERDatabase().Master_Subscription.FirstOrDefault(o => o.OrgId == inputdata.OrganisationId && o.DocNo == inputdata.TranNo);
                if (item != null)
                {
                    _data = (new GE.Subscription
                    {
                        OrgId = item.OrgId,
                        DocNo = item.DocNo,
                        DocName = item.DocName,
                        DocDate = item.DocDate,
                        DocDateString = (item.DocDate != null) ? item.DocDate.Value.ToERPdate() : string.Empty,
                        FinMon = item.FinMon,
                        FinYear = item.FinYear,
                        CustomerCode = item.CustomerCode,
                        CustomerName = item.CustomerName,
                        Status = item.Status,
                        IsActive = item.IsActive,
                        IsInterCO = item.IsInterCO,
                        SubCode = item.SubCode,
                        SubName = item.SubName,
                        Total = item.Total != null ? item.Total : 0,
                        Sent = item.Sent != null ? item.Sent : 0,
                        Price = item.Price != null ? item.Price : 0,
                        InvPrice = item.InvPrice != null ? item.InvPrice : 0,
                        InvPost = item.InvPost != null ? item.InvPost : 0,
                        Remarks = item.Remarks,
                        SManCode = item.SManCode,
                        SManName = item.SManName,
                        Contact = item.Contact,
                        FrequencyCode = item.FrequencyCode,
                        FrequencyValue = item.FrequencyValue,
                        ContactName = item.ContactName,
                        Telephone = item.Telephone,
                        UpdatedBy = item.UpdatedBy,
                        DateUpdated = item.DateUpdated,
                        DateUpdatedString = (item.DateUpdated != null) ? item.DateUpdated.Value.ToERPdate() : string.Empty,
                        ApprovedBy = item.ApprovedBy,
                        DateApproved = item.DateApproved,
                        DateApprovedString = (item.DateApproved != null) ? item.DateApproved.Value.ToERPdate() : string.Empty,
                        DeliveryAddress1 = item.DeliveryAddress1,
                        DeliveryAddress2 = item.DeliveryAddress2,
                        DeliveryAddress3 = item.DeliveryAddress3,
                        DeliveryCity = item.DeliveryCity,
                        DeliveryCountry = item.DeliveryCountry,
                        DeliveryPostalCode = item.DeliveryPostalCode,
                        PostalAddress1 = item.PostalAddress1,
                        PostalAddress2 = item.PostalAddress2,
                        PostalAddress3 = item.PostalAddress3,
                        PostalCity = item.PostalCity,
                        PostalCountry = item.PostalCountry,
                        PostalPostalCode = item.PostalPostalCode,
                        IssPerYear = item.IssPerYear != null ? item.IssPerYear : 0,
                        UnitPrice = item.UnitPrice != null ? item.UnitPrice : 0,
                        Post = item.Post != null ? item.Post : 0,
                        Postage = item.Postage != null ? item.Postage : 0,
                        Cost = item.Cost != null ? item.Cost : 0,
                        UnitCost = item.UnitCost != null ? item.UnitCost : 0,
                        LastDate = item.LastDate,
                        NextDate = item.NextDate,
                        DueDays = item.DueDays,
                        LastDateString = (item.LastDate != null) ? item.LastDate.Value.ToERPdate() : string.Empty,
                        NextDateString = (item.NextDate != null) ? item.NextDate.Value.ToERPdate() : string.Empty,
                        ChangedBy = item.ChangedBy,
                        ChangedOn = item.ChangedOn,
                        CreatedBy = item.CreatedBy,
                        CreatedOn = item.CreatedOn
                    });
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBSCRIPTION, inputdata.OrganisationId);
            }
            return _data;
        }

        //Delete the Subscription details
        public string Remove(GE::ERPInputmodel inputdata)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Subscription.FirstOrDefault(o => o.DocNo == inputdata.TranNo && o.OrgId == inputdata.OrganisationId);
                if (item != null)
                {
                    item.IsActive = false;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, inputdata.LoginUser, SUBSCRIPTION, inputdata.OrganisationId);
            }
            return result;
        }

        //To active the Subscription details
        public string MakeActive(GE::ERPInputmodel inputData)
        {
            string result = string.Empty;
            try
            {
                var item = ERPMASTERDatabase().Master_Subscription.FirstOrDefault(o => o.DocNo == inputData.TranNo && o.OrgId == inputData.OrganisationId);
                if (item != null)
                {
                    item.IsActive = true;
                    ERPMASTERDatabase().SaveChanges();
                    result = PASS;
                }
            }
            catch (Exception ex)
            {
                new ExceptionDA().Save(ex.Message, string.Empty, SUBSCRIPTION, inputData.OrganisationId);
            }
            return result;
        }
    }
}
