﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Category")]
    public class CategoryController : ApiController
    {
        GE::ERPInputmodel eRPInputmodels = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAllHeader(int OrganizationId)
        {
            Response<GE::Category> response = new Response<GE.Category>();
            eRPInputmodels.IsActive = true;
            eRPInputmodels.OrganisationId = OrganizationId;
            List<GE::Category> _Result = new BC.CategoryBC().GetAll(eRPInputmodels);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string CategoryCode)
        {
            Response<GE::Category> response = new Response<GE.Category>();
            eRPInputmodels.IsActive = true;
            eRPInputmodels.OrganisationId = OrganizationId;
            eRPInputmodels.TransactionNo = CategoryCode;
            GE::Category _obj = new BC.CategoryBC().GetbyCode(eRPInputmodels);
            List<GE::Category> _Result = new List<GE.Category>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }

        [Route("CreateCategory")]
        public IHttpActionResult Create([FromBody] GE::Category data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.CategoryBC().Save(data, data.CategoryTags, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed";
            }
            return Json(response);
        }
        [Route("RemoveCategory")]
        [HttpGet]
        public IHttpActionResult RemoveCategory(int OrganizationId, string CategoryCode, string UserName)
        {
            Response<GE::Category> response = new Response<GE.Category>();
            eRPInputmodels.IsActive = true;
            eRPInputmodels.OrganisationId = OrganizationId;
            eRPInputmodels.LoginUser = UserName;
            eRPInputmodels.TransactionNo = CategoryCode;
            string Result = new BC.CategoryBC().Remove(eRPInputmodels);
            return Json(Result);
        }
    }
}
