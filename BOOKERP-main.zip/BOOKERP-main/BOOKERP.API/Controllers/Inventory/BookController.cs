﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Book")]
    public class BookController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::Book> response = new Response<GE.Book>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Book> _Result = new BC.BookBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetByCode")]
        public IHttpActionResult Getbycode(int OrganizationId, string BookId)
        {
            Response<GE::Book> response = new Response<GE.Book>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = BookId;
            GE::Book _Obj = new BC.BookBC().GetbyCode(eRPInputmodel);
            List<GE::Book> _Result = new List<GE.Book>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetAllSearch", Name = "GetAllSearch")]
        public IHttpActionResult GetAllSearch(int OrganizationId, string Code = "", string Name = "", string Author = "", string categories = "", string ISBN10 = "", string ISBN13 = "", int pageNo = 1, int pageSize = 10)
        {
            Response<GE::Book> response = new Response<GE.Book>();
            PagedResults<GE::Book> PagedResult = new PagedResults<GE.Book>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.MachineName = Name;
            eRPInputmodel.TranNo = Code;
            eRPInputmodel.ISBN13 = ISBN13;
            eRPInputmodel.ISBN10 = ISBN10;
            List<GE::Book> _Obj = new BC.BookBC().GetAll(eRPInputmodel);
            if (!string.IsNullOrEmpty(Code))
            {
                _Obj = _Obj.FindAll(o => o.BookId == Code.Trim()).ToList();
            }
            if (!string.IsNullOrEmpty(Name))
            {
                _Obj = _Obj.FindAll(o => o.Title.Contains(Name.Trim())).ToList();
            }
            if (!string.IsNullOrEmpty(Author))
            {
                _Obj = _Obj.FindAll(o => o.AuthorName.Contains(Author)).ToList();
            }
            if (!string.IsNullOrEmpty(categories))
            {
                _Obj = _Obj.FindAll(o => o.CategoryId == categories.Trim()).ToList();
            }
            if (!string.IsNullOrEmpty(ISBN10))
            {
                _Obj = _Obj.FindAll(o => o.ISBN10 == ISBN10).ToList();
            }
            if (!string.IsNullOrEmpty(ISBN13))
            {
                _Obj = _Obj.FindAll(o => o.ISBN13 == ISBN13).ToList();
            }
            //if (!string.IsNullOrEmpty(Category))
            //{
            //    _Obj = _Obj.FindAll(o => o.CategoryId == Category).ToList();
            //}
            if (_Obj != null && _Obj.Count > 0)
            {
                //response.Data = _Obj;
                //response.Status = true;
                //response.Code = 200;
                //response.Message = "Sucess";

                int skip = pageSize * (pageNo - 1);
                // Get total number of records
                int total = _Obj.Count();
                var mod = total % pageSize;
                var totalPageCount = (total / pageSize) + (mod == 0 ? 0 : 1);
                var queryable = _Obj.ToList();

                string orderBy = "Title";
                bool ascending = true;

                var projection = queryable.AsQueryable()
                    .OrderByPropertyOrField(orderBy, ascending)
                    .Skip(skip)
                    .Take(pageSize).ToList();

                // Get the page links
                var linkBuilder = new PageLinkBuilder(Url, "GetAllSearch", null, OrganizationId, pageNo, pageSize, total);

                // Return the list of customers
                PagedResult = new PagedResults<GE.Book>();
                PagedResult.Result = projection;
                PagedResult.PageNumber = pageNo;
                PagedResult.PageSize = projection.Count;
                PagedResult.TotalNumberOfPages = totalPageCount;
                PagedResult.TotalNumberOfRecords = total;
                PagedResult.FirstPageUrl = linkBuilder.FirstPage;
                PagedResult.PreviousPageUrl = linkBuilder.PreviousPage;
                PagedResult.NextPageUrl = linkBuilder.NextPage;
                PagedResult.LastPageUrl = linkBuilder.LastPage;
                PagedResult.Status = true;
                PagedResult.Code = 200;
                PagedResult.Message = "Sucess";

            }
            else
            {
                PagedResult = new PagedResults<GE.Book>();
                PagedResult.Result = null;
                PagedResult.PageNumber = pageNo;
                PagedResult.PageSize = 0;
                PagedResult.TotalNumberOfPages = 0;
                PagedResult.TotalNumberOfRecords = 0;
                PagedResult.FirstPageUrl = null;
                PagedResult.PreviousPageUrl = null;
                PagedResult.NextPageUrl = null;
                PagedResult.LastPageUrl = null;
                PagedResult.Status = true;
                PagedResult.Code = 200;
                PagedResult.Message = "No data Found";
                //response.Data = null;
                //response.Status = false;
                //response.Code = 200;
                //response.Message = "No data Found!";
            }
            return Json(PagedResult);
        }



        [Route("GetByTagCode")]
        public IHttpActionResult Getbytagcode(int OrganizationId, string TagCode)
        {
            Response<GE::Book> response = new Response<GE.Book>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TagCode;
            List<GE::Book> _Result = new BC.BookBC().GetbyTagCode(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetAllByAuthor")]
        public IHttpActionResult GetAllByAuthor(int OrganizationId)
        {
            Response<GE::BookAuthorSearch> response = new Response<GE.BookAuthorSearch>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            //eRPInputmodel.TranNo = Author;
            List<GE::BookAuthorSearch> _Result = new BC.BookBC().GetAllByAuthor(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetByCategoryTagCode")]
        public IHttpActionResult GetByCategoryTagCode(int OrganizationId,string CategoryCode)
        {
            Response<GE::CategoryTag> response = new Response<GE.CategoryTag>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = CategoryCode;
            List<GE::CategoryTag> _Result = new BC.BookBC().GetByCategoryTagCode(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetBySubCategoryTagCode")]
        public IHttpActionResult GetBySubCategoryTagCode(int OrganizationId, string SubCategoryCode)
        {
            Response<GE::SubCategoryTag> response = new Response<GE.SubCategoryTag>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = SubCategoryCode;
            List<GE::SubCategoryTag> _Result = new BC.BookBC().GetBySubCategoryTagCode(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }
    }
}
