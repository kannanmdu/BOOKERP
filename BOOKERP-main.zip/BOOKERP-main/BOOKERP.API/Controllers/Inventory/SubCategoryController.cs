﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("SubCategory")]
    public class SubCategoryController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAllHeader(int OrganizationId)
        {
            Response<GE::SubCategory> response = new Response<GE.SubCategory>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::SubCategory> _Result = new BC.SubCategoryBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }


        [Route("GetbyCategoryCode")]
        public IHttpActionResult GetbyCategoryCode(int OrganizationId, string CategoryCode)
        {
            Response<GE::SubCategory> response = new Response<GE.SubCategory>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = CategoryCode;
            List<GE::SubCategory> _Result = new BC.SubCategoryBC().GetbyCategoryCode(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string SubCategoryCode)
        {
            Response<GE::SubCategory> response = new Response<GE.SubCategory>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = SubCategoryCode;
            GE::SubCategory _obj = new BC.SubCategoryBC().GetbyCode(eRPInputmodel);
            List<GE::SubCategory> _Result = new List<GE.SubCategory>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }

        [Route("CreateSubCategory")]
        public IHttpActionResult Create([FromBody] GE::SubCategory data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.SubCategoryBC().Save(data, data.SubCategoryTags, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No Data Found";
            }
            return Json(response);
        }
        [Route("RemoveSubCategory")]
        [HttpGet]
        public IHttpActionResult RemoveSubCategory(int OrganizationId, string SubCategoryCode, string UserName)
        {
            Response<GE::SubCategory> response = new Response<GE.SubCategory>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = SubCategoryCode;
            string Result = new BC.SubCategoryBC().Remove(eRPInputmodel);
            return Json(Result);
        }
    }
}
