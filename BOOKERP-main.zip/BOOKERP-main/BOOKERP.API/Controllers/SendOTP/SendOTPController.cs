﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("SendOTP")]
    public class SendOTPController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        BC::CommonBC _BC = new BC.CommonBC();
        [HttpPost]
        [Route("SendOTP")]
        public IHttpActionResult SendOTP(int OrganizationId, string Email)
        {
            ApiResponse response = new ApiResponse();

            string Result = SendOTPToEmail(OrganizationId, Email);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Data = Result;
                response.Message = "Sucess";
            }

            return Json(response);
        }
        public string SendOTPToEmail(int OrgId, string Email)
        {
            string strNewPassword = Generate_otp();
            eRPInputmodel.IsActive = true;
            var org = new BC.OrganizationBC().GetAll(eRPInputmodel).Select(x => x.OrgName).FirstOrDefault();
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress("appxpertmail@gmail.com");
            msg.To.Add(Email);
            msg.Subject = "Activation Code";
            msg.Body = "Company Name : " + org + "<br/>" +
                       "Your OTP is: " + "<b>" + strNewPassword + "</b>";
            msg.IsBodyHtml = true;

            using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
            {
                smtp.Credentials = new NetworkCredential("appxpertmail@gmail.com", "qplldsxjcpqfypjm");
                smtp.EnableSsl = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(msg);
            }
            GE::RegisterOTP OTPList = new GE.RegisterOTP();
            OTPList.OTP = strNewPassword;
            OTPList.OrgId = OrgId;
            OTPList.Name = "";
            OTPList.EmailId = Email;
            OTPList.Created_Date = DateTime.Now;
            OTPList.Expirted_Date = DateTime.Now.AddMinutes(5);
            bool Result = _BC.SaveOTP(OTPList, "Registration");
            return strNewPassword;
        }
        public static string Generate_otp()
        {
            char[] charArr = "0123456789".ToCharArray();
            string strrandom = string.Empty;
            Random objran = new Random();
            for (int i = 0; i < 4; i++)
            {
                //It will not allow Repetation of Characters
                int pos = objran.Next(1, charArr.Length);
                if (!strrandom.Contains(charArr.GetValue(pos).ToString())) strrandom += charArr.GetValue(pos);
                else i--;
            }
            return strrandom;
        }

        [HttpPost]
        [Route("VerifyOTP")]
        public IHttpActionResult VerifyOTP([FromBody] GE::VerifyOTP otpList)
        {
            ApiResponse response = new ApiResponse();
            HttpResponseMessage returnMessage = new HttpResponseMessage();
            try
            {
                if (otpList == null)
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "Requiered request headers not found!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "application/json");
                    return Json(response);
                    //return await Task.FromResult(returnMessage);
                }
                if (otpList.OrgId == 0)
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "OrganizationId Should Not be Zero/Blank!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "application/json");
                    return Json(response);
                }
                if (String.IsNullOrEmpty(otpList.Email))
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "Email Should Not be Blank!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "application/json");
                    return Json(response);
                }
                if (String.IsNullOrEmpty(otpList.OTP))
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "OTP Should Not be Blank!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "application/json");
                    return Json(response);
                }

                GE::RegisterOTP _data = new GE.RegisterOTP();
                _data.OrgId = otpList.OrgId;
                _data.EmailId = otpList.Email;
                _data.OTP = otpList.OTP;
                string EmployerCode = _BC.GetOTP(_data, "Registration");
                if (EmployerCode.Contains("Invalid OTP!"))
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = EmployerCode;

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "BusinessRegister");
                    return Json(response);
                }
                if (!string.IsNullOrEmpty(EmployerCode))
                {
                    response.Data = null;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "OTP has been verified successfully!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "BusinessRegister");
                    return Json(response);
                }
                else
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "OTP not has been verified successfully!";

                    //json Response
                    returnMessage = Request.CreateResponse(HttpStatusCode.OK, response, "BusinessRegister");
                    return Json(response);
                }
            }
            catch (Exception ex)
            {

            }
            return Json(response);

        }

    }
}
