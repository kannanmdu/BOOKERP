﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("SalesOrder")]
    public class SalesOrderController : ApiController
    {
        string ModuleName = "Sales Order";
        BC::SalesOrderBC _BC = new BC.SalesOrderBC();
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllHeader")]
        public IHttpActionResult GetAllHeader(int OrganizationId)
        {
            Response<GE::SalesOrderHeader> response = new Response<GE.SalesOrderHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::SalesOrderHeader> _Result = _BC.GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        //[Route("GetHeaderSearch")]
        //public IHttpActionResult GetHeaderSearch([FromUri] GE::ERPInputmodel searchModel)
        //{

        //    //GE::ERPInputmodel searchModel = new GE::ERPInputmodel();

            

        //    Response<GE::SalesOrderHeader> response = new Response<GE.SalesOrderHeader>();
        //    List<GE::SalesOrderHeader> _Result = _BC.GetHeaderbySearch(searchModel);
        //    //if (_Result != null && _Result.Count > 0)
        //    //{
        //    response.Data = _Result;
        //    response.Status = true;
        //    response.Code = 200;
        //    response.Message = "Sucess";
        //    // }
        //    return Json(response);
        //}

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string TranNo)
        {
            Response<GE::SalesOrderHeader> response = new Response<GE.SalesOrderHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            GE::SalesOrderHeader _obj = _BC.GetTransactionbyCode(eRPInputmodel);
            List<GE::SalesOrderHeader> _Result = new List<GE.SalesOrderHeader>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Create")]
        [HttpPost]
        public IHttpActionResult Create([FromBody] GE::SalesOrderHeader data)
        {
            ApiResponse response = new ApiResponse();
            if (data != null)
            {
                string Result = _BC.Save(data, data.SalesOrderDetail, data.CreatedBy);
                if (!string.IsNullOrEmpty(Result))
                {
                    response.Data = Result;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "Sucess";
                }
            }
            return Json(response);
        }

        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string TranNo)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            string Result = _BC.Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
