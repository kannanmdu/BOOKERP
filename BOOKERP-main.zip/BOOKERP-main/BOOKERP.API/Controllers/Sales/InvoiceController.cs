﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Invoice")]
    public class InvoiceController : ApiController
    {
        string ModuleName = "Invoice";
        BC::InvoiceBC _BC = new BC.InvoiceBC();
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllHeader")]
        public IHttpActionResult GetAllHeader(int OrganizationId)
        {
            Response<GE::InvoiceHeader> response = new Response<GE.InvoiceHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::InvoiceHeader> _Result = _BC.GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetHeaderSearch")]
        public IHttpActionResult GetHeaderSearch([FromUri] GE::ERPInputmodel searchModel)
        {

            Response<GE::InvoiceHeader> response = new Response<GE.InvoiceHeader>();
            List<GE::InvoiceHeader> _Result = _BC.GetHeaderbySearch(searchModel);
            
            response.Data = _Result;
            response.Status = true;
            response.Code = 200;
            response.Message = "Sucess";
           
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string TranNo)
        {
            Response<GE::InvoiceHeader> response = new Response<GE.InvoiceHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            GE::InvoiceHeader _obj = _BC.GetTransactionbyCode(eRPInputmodel);
            List<GE::InvoiceHeader> _Result = new List<GE.InvoiceHeader>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Create")]
        [HttpPost]
        public IHttpActionResult Create([FromBody] GE::InvoiceHeader data)
        {
            ApiResponse response = new ApiResponse();
            if (data != null)
            {
                string Result = _BC.Save(data, data.InvoiceDetail, data.CreatedBy, data.ConsignmentOutDODetail);
                if (!string.IsNullOrEmpty(Result))
                {
                    response.Data = Result;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "Sucess";
                }
            }
            return Json(response);
        }

        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string TranNo)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            string Result = _BC.Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
