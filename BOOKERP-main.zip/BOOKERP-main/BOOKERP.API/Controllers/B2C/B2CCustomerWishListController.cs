﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("B2CCustomerWishList")]
    public class B2CCustomerWishListController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();

        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::CustomerWishList> response = new Response<GE.CustomerWishList>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::CustomerWishList> _Result = new BC.CustomerWishListBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }


        [Route("GetAllActive")]
        public IHttpActionResult GetAllActive(int OrganizationId)
        {
            Response<GE::CustomerWishList> response = new Response<GE.CustomerWishList>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::CustomerWishList> _Result = new BC.CustomerWishListBC().GetAllActive(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetByCustomer")]
        public IHttpActionResult GetByCustomer(int OrganizationId, string CustomerId)
        {
            Response<GE::CustomerWishList> response = new Response<GE.CustomerWishList>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.CustomerCode = CustomerId;
            List<GE::CustomerWishList> _Result = new BC.CustomerWishListBC().GetByCustomer(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }


        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string CustomerId, string ProductCode)
        {
            Response<GE::CustomerWishList> response = new Response<GE.CustomerWishList>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.CustomerCode = CustomerId;
            eRPInputmodel.TransactionNo = ProductCode;
            GE::CustomerWishList _Obj = new BC.CustomerWishListBC().GetbyCode(eRPInputmodel);
            List<GE::CustomerWishList> _Result = new List<GE.CustomerWishList>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("Create")]
        public IHttpActionResult Create([FromBody] GE::CustomerWishList data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.CustomerWishListBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Not saved Successfully !";
            }
            return Json(response);
        }

        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string CustomerId, string ProductCode, string UserName)
        {
            ApiResponse response = new ApiResponse();

            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.CustomerCode = CustomerId;
            eRPInputmodel.TransactionNo = ProductCode;
            string Result = new BC.CustomerWishListBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed!";
            }
            return Json(response);
        }

        [Route("ActiveInActive")]
        [HttpGet]
        public IHttpActionResult ActiveInActive(int OrganizationId, string CustomerId, string ProductCode, string UserName, bool IsActive)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = IsActive;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.CustomerCode = CustomerId;
            eRPInputmodel.TransactionNo = ProductCode;
            string Result = new BC.CustomerWishListBC().ActiveInActive(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed!";
            }
            return Json(response);
        }
    }
}
