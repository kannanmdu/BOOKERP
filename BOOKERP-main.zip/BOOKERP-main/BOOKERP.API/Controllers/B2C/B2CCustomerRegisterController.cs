﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("B2CCustomerRegister")]
    public class B2CCustomerRegisterController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::GetB2CCustomerRegister> response = new Response<GE.GetB2CCustomerRegister>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::GetB2CCustomerRegister> _Result = new BC.B2CCustomerRegisterBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string B2CCustomerId)
        {
            Response<GE::GetB2CCustomerRegister> response = new Response<GE.GetB2CCustomerRegister>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = B2CCustomerId;
            GE::GetB2CCustomerRegister _Obj = new BC.B2CCustomerRegisterBC().GetbyCode(eRPInputmodel);
            List<GE::GetB2CCustomerRegister> _Result = new List<GE.GetB2CCustomerRegister>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetbyEmail")]
        public IHttpActionResult GetbyEmail(int OrganizationId, string EmailId)
        {
            Response<GE::B2CCustomerRegister> response = new Response<GE.B2CCustomerRegister>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = EmailId;
            GE::B2CCustomerRegister _Obj = new BC.B2CCustomerRegisterBC().GetbyEmail(eRPInputmodel);
            List<GE::B2CCustomerRegister> _Result = new List<GE.B2CCustomerRegister>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("CustomerLogin")]
        public Response<GE::B2CCustomerRegister> UserLogin(GE::LoginModel Info)
        {
            Response<GE::B2CCustomerRegister> response = new Response<GE.B2CCustomerRegister>();
            List<GE::B2CCustomerRegister> result = new List<GE.B2CCustomerRegister>();
            if (Info != null)
            {
                // Info.Password = Encrypt.Get(Info.Password);
                GE::B2CCustomerRegister _data = new BC.B2CCustomerRegisterBC().GetbyLogin(Info);
                if (_data != null)
                {
                    if (!string.IsNullOrEmpty(_data.EmailId))
                    {
                        result.Add(_data);
                        response.Data = result;
                        response.Status = true;
                        response.Code = 200;
                        response.Message = "Sucess";
                    }
                    else
                    {
                        response.Data = new List<GE.B2CCustomerRegister>();
                        response.Code = 200;
                        response.Status = false;
                        response.Message = "Invalid Username or Password";
                    }
                }
                else
                {
                    response.Data = new List<GE.B2CCustomerRegister>();
                    response.Code = 200;
                    response.Message = "Invalid Username or Password";
                }
                response.Data = result;
            }
            return response;
        }

        [Route("Create")]
        public IHttpActionResult Create([FromBody] GE::B2CCustomerRegister data)
        {
            ApiResponse response = new ApiResponse();
            //List<GE::CustomerContact> customerContacts = new List<GE.CustomerContact>();
            //List<GE::CustomerDelivery> customerDeliveries = new List<GE.CustomerDelivery>();
            string Result = new BC.B2CCustomerRegisterBC().Save(data, data.CreatedBy, data.OrgId);

            if (!string.IsNullOrEmpty(Result))
            {
                eRPInputmodel.OrganisationId = data.OrgId;
                eRPInputmodel.TranNo = "B2CCustomerRegister";
                eRPInputmodel.IsActive = true;
                GE::EmailTemplate _Obj = new BC.CommonBC().GetbyEmailTemplate(eRPInputmodel);
                var org = new BC.OrganizationBC().GetbyCode(eRPInputmodel);

                if (_Obj.OrgId != 0)
                {
                    string sub = _Obj.EmailSubject.Replace("CompanyName", org.OrgName.ToUpper()).Replace("{", "").Replace("}", "");
                    string Body = _Obj.EmailBody.Replace("Customer Name", data.B2CCustomerName.ToUpper()).Replace("Company Name", org.OrgName.ToUpper()).Replace("Your Name", org.OrgName.ToUpper()).Replace("[", "").Replace("]", "");
                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress(_Obj.FromEmail); //From Email Id  
                    mailMessage.Subject = sub; //Subject of Email  
                    mailMessage.Body = Body; //body or message of Email  
                    mailMessage.BodyEncoding = System.Text.Encoding.UTF8;
                    mailMessage.IsBodyHtml = true;

                    mailMessage.To.Add(new MailAddress(data.EmailId)); //receiver's TO Email Id  

                    if (!string.IsNullOrEmpty(_Obj.CCEmail))
                    {
                        string[] values = _Obj.CCEmail.Split(',');
                        for (int i = 0; i < values.Length; i++)
                        {
                            mailMessage.CC.Add(new MailAddress(values[i].Trim())); //Adding CC email Id
                        }
                    }
                    if (!string.IsNullOrEmpty(_Obj.BCCEmail))
                    {
                        string[] values = _Obj.BCCEmail.Split(',');
                        for (int i = 0; i < values.Length; i++)
                        {
                            mailMessage.Bcc.Add(new MailAddress(values[i].Trim()));  //Adding BCC email Id  
                        }
                    }
                    SmtpClient smtp = new SmtpClient();  // creating object of smptpclient  
                    smtp.Host = _Obj.SMTP_Host;              //host of emailaddress for example smtp.gmail.com etc  

                    //network and security related credentials  

                    smtp.EnableSsl = true;
                    NetworkCredential NetworkCred = new NetworkCredential(_Obj.FromEmail, _Obj.FromEmailPassword);
                    NetworkCred.UserName = mailMessage.From.Address;
                    //NetworkCred.word = ;
                    smtp.UseDefaultCredentials = true;
                    smtp.Credentials = NetworkCred;
                    smtp.Port = _Obj.SMTP_Port.HasValue ? _Obj.SMTP_Port.Value : 587;
                    smtp.Send(mailMessage); //sending Email
                }
            }

            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed!";
            }
            return Json(response);
        }

        [Route("ActiveInActive")]
        [HttpGet]
        public IHttpActionResult ActiveInActive(int OrganizationId, string B2CCustomerId, string UserName, bool IsActive)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = IsActive;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = B2CCustomerId;
            string Result = new BC.B2CCustomerRegisterBC().ActiveInActive(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "failed!";
            }
            return Json(response);
        }

        [HttpPost]
        [Route("EditProfile")]
        public IHttpActionResult EditProfile([FromBody] GE::B2CEditProfile data)
        {
            ApiResponse response = new ApiResponse();

            string Result = new BC.B2CCustomerRegisterBC().EditProfile(data);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed!";
            }
            return Json(response);
        }


        [HttpPost]
        [Route("EditProfilePassword")]
        public IHttpActionResult EditProfilePassword([FromBody] GE::B2CChangePassword data)
        {
            ApiResponse response = new ApiResponse();

            string Result = new BC.B2CCustomerRegisterBC().EditProfilePassword(data);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Failed!";
            }
            return Json(response);
        }

        [Route("ForgetPassword")]
        public IHttpActionResult ForgetPassword(int OrganisationId, string Email, string user)
        {
            ApiResponse response = new ApiResponse();
            if (!string.IsNullOrEmpty(Email))
            {
                string Result = new BC.B2CCustomerRegisterBC().ForgetPassword(OrganisationId, Email, user);
                if (!string.IsNullOrEmpty(Result))
                {
                    response.Data = Result;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "Sucess";
                }
                else
                {
                    response.Data = null;
                    response.Status = false;
                    response.Code = 200;
                    response.Message = "not sucess";
                }
            }
            return Json(response);
        }
    }
}
