﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("B2CContactEnquiry")]
    public class B2CContactEnquiryController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();

        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::B2CContactEnquiry> response = new Response<GE.B2CContactEnquiry>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::B2CContactEnquiry> _Result = new BC.B2CContactEnquiryBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }


        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string CustomerId)
        {
            Response<GE::B2CContactEnquiry> response = new Response<GE.B2CContactEnquiry>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = CustomerId;

            GE::B2CContactEnquiry _Obj = new BC.B2CContactEnquiryBC().GetbyCode(eRPInputmodel);
            List<GE::B2CContactEnquiry> _Result = new List<GE.B2CContactEnquiry>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Create")]
        public IHttpActionResult Create([FromBody] GE::B2CContactEnquiry data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.B2CContactEnquiryBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
