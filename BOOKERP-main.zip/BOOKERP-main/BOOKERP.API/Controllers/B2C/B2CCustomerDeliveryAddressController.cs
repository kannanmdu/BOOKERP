﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("B2CCustomerDeliveryAddress")]
    public class B2CCustomerDeliveryAddressController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId, string CustomerId)
        {
            Response<GE::B2CCustomerDeliveryAddress> response = new Response<GE.B2CCustomerDeliveryAddress>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::B2CCustomerDeliveryAddress> _Result = new BC.B2CCustomerDeliveryAddressBC().GetAll(CustomerId, OrganizationId);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string CustomerId, int DeliveryId, string user)
        {
            Response<GE::B2CCustomerDeliveryAddress> response = new Response<GE.B2CCustomerDeliveryAddress>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransactionNo = CustomerId;
            GE::B2CCustomerDeliveryAddress _Obj = new BC.B2CCustomerDeliveryAddressBC().GetbyCode(user, CustomerId, DeliveryId, OrganizationId);
            List<GE::B2CCustomerDeliveryAddress> _Result = new List<GE.B2CCustomerDeliveryAddress>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("Create")]
        public IHttpActionResult Create([FromBody] GE::B2CCustomerDeliveryAddress data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.B2CCustomerDeliveryAddressBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "Not Saved Successfully !";
            }
            return Json(response);
        }
        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string CustomerId, int DeliveryId, string UserName)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = CustomerId;
            eRPInputmodel.TransNo = DeliveryId;
            string Result = new BC.B2CCustomerDeliveryAddressBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = null;
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("GetAllCustomersSearch")]
        public IHttpActionResult GetAllCustomersSearch(int OrganizationId, string CustomerCode = "", string CustomerName = "")
        {
            Response<GE::Customer> response = new Response<GE.Customer>();
            eRPInputmodel.IsActive = true;
            List<GE::Customer> _ResultCode = new List<GE.Customer>();
            List<GE::Customer> _ResultName = new List<GE.Customer>();
            List<GE::Customer> _ResultFinal = new List<GE.Customer>();
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Customer> _Result = new BC.CustomerBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                if (!string.IsNullOrEmpty(CustomerCode))
                    _ResultCode = _Result.Where(o => o.Code.Contains(CustomerCode)).ToList();
                if (!string.IsNullOrEmpty(CustomerName))
                    _ResultName = _Result.Where(o => o.Name.Contains(CustomerName)).ToList();
            }
            _ResultFinal.AddRange(_ResultCode);
            _ResultFinal.AddRange(_ResultName);
            if (string.IsNullOrEmpty(CustomerCode) && string.IsNullOrEmpty(CustomerName))
                _ResultFinal.AddRange(_Result);

            if (_ResultFinal != null && _ResultFinal.Count > 0)
            {
                response.Data = _ResultFinal;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetAllCustomersSorting")]
        public IHttpActionResult GetAllCustomersSorting(int OrganizationId, string FieldName, string Decision)
        {
            Response<GE::Customer> response = new Response<GE.Customer>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Customer> _Result = new BC.CustomerBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                if (!string.IsNullOrEmpty(FieldName) && string.Compare(FieldName, "C") == 0 && string.Compare(Decision, "1") == 0)
                    _Result = _Result.OrderBy(o => o.Code).ToList();

                if (!string.IsNullOrEmpty(FieldName) && string.Compare(FieldName, "C") == 0 && string.Compare(Decision, "2") == 0)
                    _Result = _Result.OrderByDescending(o => o.Code).ToList();

                if (!string.IsNullOrEmpty(FieldName) && string.Compare(FieldName, "N") == 0 && string.Compare(Decision, "1") == 0)
                    _Result = _Result.OrderBy(o => o.Name).ToList();

                if (!string.IsNullOrEmpty(FieldName) && string.Compare(FieldName, "N") == 0 && string.Compare(Decision, "2") == 0)
                    _Result = _Result.OrderByDescending(o => o.Name).ToList();
            }

            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
