﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("B2CCustomerOrder")]
    public class B2CCustomerOrderController : ApiController
    {
        string ModuleName = "B2CCustomerOrder";
        BC::B2CCustomerOrderBC _BC = new BC.B2CCustomerOrderBC();
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::B2CCustomerOrder> response = new Response<GE.B2CCustomerOrder>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::B2CCustomerOrder> _Result = _BC.GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetHeaderSearch")]
        public IHttpActionResult GetHeaderSearch([FromUri] GE::ERPInputmodel searchModel)
        {
            Response<GE::B2CCustomerOrder> response = new Response<GE.B2CCustomerOrder>();
            List<GE::B2CCustomerOrder> _Result = _BC.GetHeaderbySearch(searchModel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            else
            {
                response.Data = new List<GE::B2CCustomerOrder>();
                response.Status = false;
                response.Code = 200;
                response.Message = "No data Found!";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string OrderNo)
        {
            Response<GE::B2CCustomerOrder> response = new Response<GE.B2CCustomerOrder>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = OrderNo;
            GE::B2CCustomerOrder _obj = _BC.GetTransactionbyCode(eRPInputmodel);
            List<GE::B2CCustomerOrder> _Result = new List<GE.B2CCustomerOrder>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Create")]
        [HttpPost]
        public IHttpActionResult Create([FromBody] GE::B2CCustomerOrder data)
        {
            ApiResponse response = new ApiResponse();
            if (data != null)
            {
                string Result = _BC.Save(data, data.OrderDetail, data.CreatedBy);

                if (!string.IsNullOrEmpty(Result))
                {
                    eRPInputmodel.OrganisationId = data.OrgId;
                    eRPInputmodel.TranNo = "B2CCustomerOrder";
                    GE::EmailTemplate _Obj = new BC.CommonBC().GetbyEmailTemplate(eRPInputmodel);

                    if (_Obj.OrgId != 0)
                    {

                        MailMessage mailMessage = new MailMessage();
                        mailMessage.From = new MailAddress(_Obj.FromEmail); //From Email Id  
                        mailMessage.Subject = _Obj.EmailSubject; //Subject of Email  
                        mailMessage.Body = _Obj.EmailBody; //body or message of Email  
                        mailMessage.IsBodyHtml = true;

                        //mailMessage.To.Add(new MailAddress(data.EmailId)); //receiver's TO Email Id  
                        if (!string.IsNullOrEmpty(data.EmailId))
                        {
                            string[] values = data.EmailId.Split(',');
                            for (int i = 0; i < values.Length; i++)
                            {
                                mailMessage.To.Add(new MailAddress(values[i].Trim())); //receiver's TO Email Id
                            }
                        }

                        if (!string.IsNullOrEmpty(_Obj.CCEmail))
                        {
                            string[] values = _Obj.CCEmail.Split(',');
                            for (int i = 0; i < values.Length; i++)
                            {
                                mailMessage.CC.Add(new MailAddress(values[i].Trim())); //Adding CC email Id
                            }
                        }
                        if (!string.IsNullOrEmpty(_Obj.BCCEmail))
                        {
                            string[] values = _Obj.BCCEmail.Split(',');
                            for (int i = 0; i < values.Length; i++)
                            {
                                mailMessage.Bcc.Add(new MailAddress(values[i].Trim()));  //Adding BCC email Id  
                            }
                        }
                        SmtpClient smtp = new SmtpClient();  // creating object of smptpclient  
                        smtp.Host = _Obj.SMTP_Host;              //host of emailaddress for example smtp.gmail.com etc  

                        //network and security related credentials  

                        smtp.EnableSsl = true;
                        NetworkCredential NetworkCred = new NetworkCredential(_Obj.FromEmail, _Obj.FromEmailPassword);
                        NetworkCred.UserName = mailMessage.From.Address;
                        //NetworkCred.word = ;
                        smtp.UseDefaultCredentials = true;
                        smtp.Credentials = NetworkCred;
                        smtp.Port = _Obj.SMTP_Port.HasValue ? _Obj.SMTP_Port.Value : 587;
                        smtp.Send(mailMessage); //sending Email
                    }
                }

                if (!string.IsNullOrEmpty(Result))
                {
                    response.Data = Result;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "Sucess";
                }
            }
            return Json(response);
        }

        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string OrderNo)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = OrderNo;
            string Result = _BC.Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
