﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Web.Http;
using BOOKERP.Utility;

namespace BOOKERP.API.Controllers
{
    public class LoginController : ApiController
    {
        public Response<GE::User> ERPLogin(GE::LoginModel Info)
        {
            Response<GE::User> response = new Response<GE.User>();
            List<GE::User> result = new List<GE.User>();
            if (Info != null)
            {
                Info.Password = Encrypt.Get(Info.Password);
                GE::User _data = new BC.UserBC().GetbyLogin(Info);
                if (_data != null)
                {
                    if (!string.IsNullOrEmpty(_data.UserName))
                    {
                        result.Add(_data);
                        response.Data = result;
                        response.Status = true;
                        response.Code = 200;
                        response.Message = "Sucess";
                    }
                    else
                    {
                        response.Data = new List<GE.User>();
                        response.Code = 200;
                        response.Status = false;
                        response.Message = "Invalid Username or Password";
                    }
                }
                else
                {
                    response.Data = new List<GE.User>();
                    response.Code = 200;
                    response.Message = "Invalid Username or Password";
                }
                response.Data = result;
            }
            return response;
        }
    }
}
