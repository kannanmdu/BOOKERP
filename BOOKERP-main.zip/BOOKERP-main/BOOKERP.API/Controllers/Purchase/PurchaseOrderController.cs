﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("PurchaseOrder")]
    public class PurchaseOrderController : ApiController
    {
        string ModuleName = "Purchase Order";
        BC::PurchaseOrderBC _BC = new BC.PurchaseOrderBC();
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllHeader")]
        public IHttpActionResult GetAllHeader(int OrganizationId)
        {
            Response<GE::PurchaseOrderHeader> response = new Response<GE.PurchaseOrderHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::PurchaseOrderHeader> _Result = _BC.GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        //[Route("GetHeaderSearch")]
        //public IHttpActionResult GetHeaderSearch([FromUri] GE::ERPInputmodel searchModel)
        //{
        //    Response<GE::PurchaseOrderHeader> response = new Response<GE.PurchaseOrderHeader>();
        //    List<GE::PurchaseOrderHeader> _Result = _BC.GetHeaderbySearch(searchModel);
        //    if (_Result != null && _Result.Count > 0)
        //    {
        //        response.Data = _Result;
        //        response.Status = true;
        //        response.Code = 200;
        //        response.Message = "Sucess";
        //    }
        //    return Json(response);
        //}

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string TranNo)
        {
            Response<GE::PurchaseOrderHeader> response = new Response<GE.PurchaseOrderHeader>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            GE::PurchaseOrderHeader _obj = _BC.GetTransactionbyCode(eRPInputmodel);
            List<GE::PurchaseOrderHeader> _Result = new List<GE.PurchaseOrderHeader>();
            if (_obj != null)
            {
                _Result.Add(_obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Create")]
        [HttpPost]
        public IHttpActionResult Create([FromBody] GE::PurchaseOrderHeader data)
        {
            ApiResponse response = new ApiResponse();
            if (data != null)
            {
                data.TranDate = !string.IsNullOrEmpty(data.TranDateString) ? data.TranDateString.GetERPDateFormat() : DateTime.Now;
                data.RequiredDate = DateTime.Now;
                //data.IsUpdate = false;
                //if (string.IsNullOrEmpty(data.TranNo))
                //    data.TranNo = new BC.CommonBC().AutoTranNo(data.OrgId, data.LocationCode, ModuleName);
                //else
                //    data.IsUpdate = true;
                string Result = _BC.Save(data, data.PurchaseOrderDetails, data.CreatedBy);
                if (!string.IsNullOrEmpty(Result))
                {
                    response.Data = Result;
                    response.Status = true;
                    response.Code = 200;
                    response.Message = "Sucess";
                }
            }
            return Json(response);
        }

        [Route("Remove")]
        [HttpGet]
        public IHttpActionResult Remove(int OrganizationId, string TranNo)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = TranNo;
            string Result = _BC.Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
