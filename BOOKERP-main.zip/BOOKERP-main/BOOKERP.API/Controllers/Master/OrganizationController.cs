﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Organization")]
    public class OrganizationController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllOrganization")]
        public IHttpActionResult GetAllOrganization()
        {
            Response<GE::Organization> response = new Response<GE.Organization>();
            eRPInputmodel.IsActive = true;
            //  eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Organization> _Result = new BC.OrganizationBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetOrganizationbycode")]
        public IHttpActionResult GetOrganizationbycode(int OrganizationId)
        {
            Response<GE::Organization> response = new Response<GE.Organization>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TransNo = OrganizationId;
            GE::Organization _Obj = new BC.OrganizationBC().GetbyCode(eRPInputmodel);
            List<GE::Organization> _Result = new List<GE.Organization>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("CreateOrganization")]
        public IHttpActionResult Create([FromBody] GE::Organization data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.OrganizationBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
        [Route("RemoveOrganization")]
        [HttpGet]
        public IHttpActionResult RemoveOrganization(int OrganizationId, string UserName)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransNo = OrganizationId;
            string Result = new BC.OrganizationBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
