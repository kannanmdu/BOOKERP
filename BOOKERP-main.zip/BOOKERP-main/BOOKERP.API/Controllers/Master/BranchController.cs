﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Branch")]
    public class BranchController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllBranches")]
        public IHttpActionResult GetAllBranches(int OrganizationId)
        {
            Response<GE::Branch> response = new Response<GE.Branch>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Branch> _Result = new BC.BranchBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetBranchbycode")]
        public IHttpActionResult GetBranchbycode(int OrganizationId, string BranchCode)
        {
            Response<GE::Branch> response = new Response<GE.Branch>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.BranchCode = BranchCode;
            GE::Branch _Obj = new BC.BranchBC().GetbyCode(eRPInputmodel);
            List<GE::Branch> _Result = new List<GE.Branch>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("CreateBranch")]
        public IHttpActionResult Create([FromBody] GE::Branch data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.BranchBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
        [Route("RemoveBranch")]
        [HttpGet]
        public IHttpActionResult RemoveBranch(int OrganizationId, string BranchCode, string UserName)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = BranchCode;
            string Result = new BC.BranchBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
