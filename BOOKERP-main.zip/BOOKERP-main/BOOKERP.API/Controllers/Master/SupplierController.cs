﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Supplier")]
    public class SupplierController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAllSupplier")]
        public IHttpActionResult GetAllSupplier(int OrganizationId)
        {
            Response<GE::Supplier> response = new Response<GE.Supplier>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Supplier> _Result = new BC.SupplierBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("GetSupplierbycode")]
        public IHttpActionResult GetSupplierbycode(int OrganizationId, string Code)
        {
            Response<GE::Supplier> response = new Response<GE.Supplier>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = Code;
            GE::Supplier _Obj = new BC.SupplierBC().GetbyCode(eRPInputmodel);
            List<GE::Supplier> _Result = new List<GE.Supplier>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("CreateSupplier")]
        public IHttpActionResult Create([FromBody] GE::Supplier data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.SupplierBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
        [Route("RemoveSupplier")]
        [HttpGet]
        public IHttpActionResult RemoveSupplier(int OrganizationId, string Code, string UserName)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = Code;
            string Result = new BC.SupplierBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
