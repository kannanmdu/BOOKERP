﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GE = BOOKERP.Entities;
using BC = BOOKERP.Business;
using BOOKERPAPI.Models;
using System.Net.Mail;

namespace BOOKERP.API.Controllers
{
    [RoutePrefix("Currency")]
    public class CurrencyController : ApiController
    {
        GE::ERPInputmodel eRPInputmodel = new GE.ERPInputmodel();
        [Route("GetAll")]
        public IHttpActionResult GetAll(int OrganizationId)
        {
            Response<GE::Currency> response = new Response<GE.Currency>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            List<GE::Currency> _Result = new BC.CurrencyBC().GetAll(eRPInputmodel);
            if (_Result != null && _Result.Count > 0)
            {
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("Getbycode")]
        public IHttpActionResult Getbycode(int OrganizationId, string CurrencyCode)
        {
            Response<GE::Currency> response = new Response<GE.Currency>();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.TranNo = CurrencyCode;
            GE::Currency _Obj = new BC.CurrencyBC().GetbyCode(eRPInputmodel);
            List<GE::Currency> _Result = new List<GE.Currency>();
            if (_Obj != null)
            {
                _Result.Add(_Obj);
                response.Data = _Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }

        [Route("CreateCurrency")]
        public IHttpActionResult Create([FromBody] GE::Currency data)
        {
            ApiResponse response = new ApiResponse();
            string Result = new BC.CurrencyBC().Save(data, data.CreatedBy, data.OrgId);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
        [Route("RemoveCurrency")]
        [HttpGet]
        public IHttpActionResult RemoveCurrency(int OrganizationId, string Code, string UserName)
        {
            ApiResponse response = new ApiResponse();
            eRPInputmodel.IsActive = true;
            eRPInputmodel.OrganisationId = OrganizationId;
            eRPInputmodel.LoginUser = UserName;
            eRPInputmodel.TransactionNo = Code;
            string Result = new BC.CurrencyBC().Remove(eRPInputmodel);
            if (!string.IsNullOrEmpty(Result))
            {
                response.Data = Result;
                response.Status = true;
                response.Code = 200;
                response.Message = "Sucess";
            }
            return Json(response);
        }
    }
}
