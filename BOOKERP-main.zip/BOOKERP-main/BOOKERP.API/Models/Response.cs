﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace BOOKERPAPI.Models
{
    public class Response<T>
    {
        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Code")]
        public int Code { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Status")]
        public bool Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Message")]
        public string Message { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Result")]
        public List<T> Data { get; set; }
    }
}