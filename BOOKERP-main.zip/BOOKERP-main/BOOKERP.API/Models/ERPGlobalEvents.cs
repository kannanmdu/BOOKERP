﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace BOOKERPAPI.Models
{
    public static class ERPGlobalEvents
    {
        public static DateTime? GetERPDateFormat(this string Datestring)
        {
            DateTime? CalculatedDate = null;
            try
            {
                if (!string.IsNullOrEmpty(Datestring))
                {
                    if (Datestring.Contains("/"))
                    {
                        string CalculatedDATE = string.Format("{0}/{1}/{2} {3}", Datestring.Split('/')[2], Datestring.Split('/')[1], Datestring.Split('/')[0], "00:00:00");
                        CalculatedDate = !string.IsNullOrEmpty(CalculatedDATE) ? Convert.ToDateTime(CalculatedDATE) : DateTime.Now;
                    }
                    if (Datestring.Contains("-"))
                    {
                        string CalculatedDATE = string.Format("{0}/{1}/{2} {3}", Datestring.Split('-')[2], Datestring.Split('-')[1], Datestring.Split('-')[0], "00:00:00");
                        CalculatedDate = !string.IsNullOrEmpty(CalculatedDATE) ? Convert.ToDateTime(CalculatedDATE) : DateTime.Now;
                    }
                }
                else
                    CalculatedDate = DateTime.Now.Date;

            }
            catch (Exception) { CalculatedDate = DateTime.Now.Date; }
            return CalculatedDate;
        }
        public static DateTime? GetERPDateTimeFormat(this string Datetimestring)
        {
            DateTime? CalculatedDate = null;
            try
            {
                if (!string.IsNullOrEmpty(Datetimestring))
                {
                    DateTime currentdate = DateTime.Now;
                    string CalculatedDATE = string.Format("{0}/{1}/{2} {3}", currentdate.Year, currentdate.Month, currentdate.Day, Datetimestring);
                    CalculatedDate = !string.IsNullOrEmpty(CalculatedDATE) ? Convert.ToDateTime(CalculatedDATE) : DateTime.Now;

                }
                else
                    CalculatedDate = DateTime.Now.Date;

            }
            catch (Exception) { CalculatedDate = DateTime.Now.Date; }
            return CalculatedDate;
        }
    }
}