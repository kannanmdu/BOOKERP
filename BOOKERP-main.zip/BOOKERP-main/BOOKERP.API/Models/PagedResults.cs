﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace BOOKERPAPI.Models
{
    public class PagedResults<T>
    {
        [DataMember(Name = "Code")]
        public int Code { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Status")]
        public bool Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "Message")]
        public string Message { get; set; }

        /// <summary>
        /// The page number this page represents.
        /// </summary>
        public int PageNumber { get; set; }

        /// <summary>
        /// The size of this page.
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// The total number of pages available.
        /// </summary>
        public int TotalNumberOfPages { get; set; }

        /// <summary>
        /// The total number of records available.
        /// </summary>
        public int TotalNumberOfRecords { get; set; }

        /// <summary>
        /// The records this page represents.
        /// </summary>
        [DataMember(Name = "Result")]
        public List<T> Result { get; set; }

        public Uri FirstPageUrl { get; set; }

        public Uri NextPageUrl { get; set; }

        public Uri PreviousPageUrl { get; set; }
        /// <summary>
        /// The URL to the next page - if null, there are no more pages.
        /// </summary>
        public Uri LastPageUrl { get; set; }


    }
}