﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class InvoiceHeader
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public string BranchCode { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string OrderNo { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string LocationCode { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public string PaymentType { get; set; }

        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> DiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public Nullable<decimal> FTotal { get; set; }
        public Nullable<decimal> FDiscount { get; set; }
        public Nullable<decimal> FSubTotal { get; set; }
        public Nullable<decimal> FTax { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public Nullable<decimal> FBalanceAmount { get; set; }
        public string Remarks { get; set; }
        public string ReferenceNo { get; set; }
        public string CreatedFrom { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string AssignTo { get; set; }
        public string TranDateString { get; set; }
        public string OrderDateString { get; set; }
        public List<InvoiceDetail> InvoiceDetail { get; set; }
        public bool IsUpdate { get; set; }
        public Nullable<int> CustomerShipToId { get; set; }
        public string CustomerShipToAddress { get; set; }
        public string PriceSettingCode { get; set; }
        public string TermCode { get; set; }
        public Nullable<bool> InvoiceType { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<decimal> CreditLimit { get; set; }
        public Nullable<decimal> OutStanding { get; set; }
        public Nullable<decimal> Latitude { get; set; }
        public Nullable<decimal> Longitude { get; set; }
        public string Signatureimage { get; set; }
        public string SONo { get; set; }
        public string DONo { get; set; }
        public string Cameraimage { get; set; }
        public string SummaryRemarks { get; set; }
        public string PLNo { get; set; }
        public string CustomerEmail { get; set; }
        public string Salesman { get; set; }
        public Nullable<decimal> FDiscountPerc { get; set; }

        public Nullable<decimal> FBillDiscount { get; set; }

        public Nullable<decimal> CurrencyValue { get; set; }
        public string AddressLine1 { get; set; }
        public Nullable<bool> IsConsignmentInvoice { get; set; }
        public Nullable<decimal> ShippingCharges { get; set; }
        public List<ConsignmentOutDODetail> ConsignmentOutDODetail { get; set; }
        public string CashRegisterCode { get; set; }
        public string SettlementNo { get; set; }
    }
}
