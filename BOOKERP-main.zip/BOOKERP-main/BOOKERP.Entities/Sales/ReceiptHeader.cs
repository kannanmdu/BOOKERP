﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ReceiptHeader
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string BranchCode { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string PayMode { get; set; }
        public string Bank { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> ChequeDate { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
        public string Remarks { get; set; }
        public string AccountNo { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<int> DeliveryId { get; set; }
        public Nullable<System.DateTime> BankInDate { get; set; }
        public Nullable<decimal> CreditAmount { get; set; }
        public Nullable<decimal> DebitAmount { get; set; }
        public Nullable<decimal> AdvancePayment { get; set; }
        public Nullable<int> ChequeStatus { get; set; }
        public Nullable<decimal> DifferenceAmount { get; set; }
        public Nullable<decimal> WriteOffAmount { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public Nullable<decimal> FCreditAmount { get; set; }
        public Nullable<decimal> FDebitAmount { get; set; }
        public Nullable<decimal> FAdvancePayment { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string TranDatestring { get; set; }
        public string ChequeDatestring { get; set; }
        public string ModuleName { get; set; }
        public string PaymodeName { get; set; }
        public List<ReceiptDetail> ReceiptDetails { get; set; }

    }
}
