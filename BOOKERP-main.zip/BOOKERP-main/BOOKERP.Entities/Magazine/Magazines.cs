﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Magazines
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string MagazineId { get; set; }
        public string MagazineCode { get; set; }
        public string MagazineName { get; set; }
        public string BarCode { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public string Publishcurrency { get; set; }
        public Nullable<decimal> PublishPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CategoryName { get; set; }
        public string LongDescription { get; set; }
        public string ShortDescription { get; set; }
        public string SubCategoryCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
        public string ISSN { get; set; }
        public string FrequencyCode { get; set; }
        public Nullable<int> FrequencyValue { get; set; }
        public Nullable<decimal> PriceWGST { get; set; }
        public Nullable<decimal> PriceWOGST { get; set; }
        public Nullable<decimal> UnitPrice { get; set; }
        public Nullable<decimal> Postal { get; set; }
        public string CountryCode { get; set; }
    }
}
