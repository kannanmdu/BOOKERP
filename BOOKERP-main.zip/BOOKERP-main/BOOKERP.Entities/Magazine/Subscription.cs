﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Subscription
    {
        public int OrgId { get; set; }
        public string DocNo { get; set; }
        public string DocName { get; set; }
        public Nullable<System.DateTime> DocDate { get; set; }
        public string DocDateString { get; set; }
        public Nullable<int> FinMon { get; set; }
        public Nullable<int> FinYear { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public Nullable<int> Status { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsInterCO { get; set; }
        public string SubCode { get; set; }
        public string SubName { get; set; }
        public Nullable<int> Total { get; set; }
        public Nullable<int> Sent { get; set; }
        public Nullable<decimal> InvPrice { get; set; }
        public Nullable<decimal> InvPost { get; set; }
        public string Remarks { get; set; }
        public string SManCode { get; set; }
        public string SManName { get; set; }
        public string Contact { get; set; }
        public string ContactName { get; set; }
        public string Telephone { get; set; }
        public string UpdatedBy { get; set; }
        public Nullable<System.DateTime> DateUpdated { get; set; }
        public string DateUpdatedString { get; set; }
        public string ApprovedBy { get; set; }
        public Nullable<System.DateTime> DateApproved { get; set; }
        public string DateApprovedString { get; set; }
        public string DeliveryAddress1 { get; set; }
        public string DeliveryAddress2 { get; set; }
        public string DeliveryAddress3 { get; set; }
        public string DeliveryCity { get; set; }
        public string DeliveryCountry { get; set; }
        public string DeliveryPostalCode { get; set; }
        public string PostalAddress1 { get; set; }
        public string PostalAddress2 { get; set; }
        public string PostalAddress3 { get; set; }
        public string PostalCity { get; set; }
        public string PostalCountry { get; set; }
        public string PostalPostalCode { get; set; }
        public Nullable<int> IssPerYear { get; set; }
        public string FrequencyCode { get; set; }
        public string FrequencyValue { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> UnitPrice { get; set; }
        public Nullable<decimal> Post { get; set; }
        public Nullable<decimal> Postage { get; set; }
        public Nullable<decimal> Cost { get; set; }
        public Nullable<decimal> UnitCost { get; set; }
        public Nullable<System.DateTime> LastDate { get; set; }
        public Nullable<System.DateTime> NextDate { get; set; }
        public string NextDateString { get; set; }
        public string LastDateString { get; set; }
        public string DueDays { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
