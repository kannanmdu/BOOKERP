﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class ReportSearch
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string SupplierCode { get; set; }
        public string CustomerCode { get; set; }
        public string SupplierName { get; set; }
        public string CustomerName { get; set; }
        public string CustomerSupplierCode { get; set; }
        public string TranType { get; set; }
        public string CatCodee { get; set; }
        public string FromDateString { get; set; }
        public string ToDateString { get; set; }
        public int OrgId { get; set; }
        public string OrgName { get; set; }
        public string OrgRefNo { get; set; }
        public string ModuleName { get; set; }
        public string ProductCode { get; set; }

        public string CategoryCode { get; set; }

        public string SubCategoryCode { get; set; }
        public string CashRegisterCode { get; set; }
        public DateTime Currentdatetime { get; set; }
        public string Type { get; set; }
        public string Paymode { get; set; }
        public string[] CategoryList { get; set; }
        public string LogInUser { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public bool IsBaseCurrency { get; set; }
        public bool IsCredit { get; set; }
        public string StockFilter { get; set; }
        public string User { get; set; }
        public bool IsStockQty { get; set; }
        public string Barcode { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public string AssignedTo { get; set; }
    }
}
