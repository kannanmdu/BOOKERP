﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class MasterReport
    {
        public string ModuleName { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Field1 { get; set; }
        public string Field2 { get; set; }
        public string Field1column { get; set; }
        public string Field2column { get; set; }
    }
    public class CustomerReport
    {
        public int OrgId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string UniqueNo { get; set; }
        public string EMail { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public int Country { get; set; }
        public string PostalCode { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string ContactPerson { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public string ChangedOn { get; set; }
    }
    public class ProfitOrLossReport
    {
        public string TranType { get; set; }
        public string TranNo { get; set; }
        public System.DateTime TranDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> BoxPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> TotalSales { get; set; }
        public Nullable<decimal> CostPrice { get; set; }
        public Nullable<decimal> CostPriceBox { get; set; }
        public Nullable<decimal> TotalCost { get; set; }
        public Nullable<decimal> Profit { get; set; }
    }

    public class ProfitOrLossWithIncomeExpenses
    {
        public string AccountType { get; set; }
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string TranType { get; set; }
        public Nullable<decimal> Debit { get; set; }
        public Nullable<decimal> Credit { get; set; }
        public string GLType { get; set; }
        public Nullable<decimal> GrossProfit { get; set; }
        public Nullable<decimal> NetProfit { get; set; }
        public Nullable<decimal> TotalSales { get; set; }
        public Nullable<decimal> TotalPurchase { get; set; }
        public Nullable<decimal> TotalIncome { get; set; }
        public Nullable<decimal> TotalExpense { get; set; }
    }

    public class InventoryReport
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string Uom { get; set; }
        public string BookId { get; set; }
        public string ISBN13 { get; set; }
        public string ISBN10 { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string AuthorName { get; set; }
        public string DetailDescription { get; set; }
        public string CategoryId { get; set; }
        public string Publisher { get; set; }
        public string Language { get; set; }
        public string BindingType { get; set; }
        public Nullable<decimal> CostPrice { get; set; }
        public Nullable<decimal> Margin { get; set; }
        public Nullable<decimal> SalesPrice { get; set; }
        public Nullable<decimal> Length { get; set; }
        public Nullable<decimal> Breadth { get; set; }
        public Nullable<decimal> Width { get; set; }
        public Nullable<decimal> Height { get; set; }
        public Nullable<System.DateTime> PublishDate { get; set; }
        public Nullable<int> Edition { get; set; }
        public Nullable<int> TotalPages { get; set; }
        public string SupplierId { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<decimal> UnitCost { get; set; }
        public Nullable<decimal> SellingPrice { get; set; }
        public Nullable<decimal> SellingPriceMargin { get; set; }
        public Nullable<decimal> RetailPrice { get; set; }
        public Nullable<decimal> RetailPriceMargin { get; set; }
        public Nullable<decimal> B2CPrice { get; set; }
        public Nullable<decimal> B2CPriceMargin { get; set; }
        public Nullable<decimal> Weight { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsB2C { get; set; }
        public Nullable<bool> IsPos { get; set; }
        public Nullable<decimal> Thickness { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string SupplierName { get; set; }
    }

    public class MagazineReport
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string MagazineId { get; set; }
        public string MagazineCode { get; set; }
        public string MagazineName { get; set; }
        public string BarCode { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public string Publishcurrency { get; set; }
        public Nullable<decimal> PublishPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CategoryName { get; set; }
        public string LongDescription { get; set; }
        public string ShortDescription { get; set; }
        public string SubCategoryCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
        public string SubCategoryName { get; set; }
    }
}
