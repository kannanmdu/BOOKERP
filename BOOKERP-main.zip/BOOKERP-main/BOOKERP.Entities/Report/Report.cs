﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Report
    {
        public int OrganisationId { get; set; }
        public int UserRolePermissionId { get; set; }
        public string UserRolecode { get; set; }
        public string SubMenuId { get; set; }
        public string SubMenuName { get; set; }
        public string MenuName { get; set; }
        public Nullable<int> MenuId { get; set; }       
        public Nullable<int> DisplayOrder { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsFullAccess { get; set; }
        public Nullable<bool> IsView { get; set; }
        public Nullable<bool> IsAdd { get; set; }
        public Nullable<bool> IsEdit { get; set; }
        public Nullable<bool> IsConvert { get; set; }
        public Nullable<bool> IsDelete { get; set; }
       public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
       public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
