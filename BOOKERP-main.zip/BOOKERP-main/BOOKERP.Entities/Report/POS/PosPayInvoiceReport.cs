﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PosPayInvoiceReport
    {
        public int OrgId { get; set; }
        public string BrachCode { get; set; }
        public string LocationCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string OrderNo { get; set; }
        public System.DateTime OrderDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<decimal> BillDiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> PcsPrice { get; set; }
        public Nullable<int> Foc { get; set; }
        public Nullable<decimal> DetailTotal { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> ItemDiscountPerc { get; set; }
        public Nullable<decimal> DetailSubTotal { get; set; }
        public Nullable<decimal> DetailTax { get; set; }
        public Nullable<decimal> DetailNetTotal { get; set; }
        public Nullable<int> DetailTaxCode { get; set; }
        public string DetailTaxType { get; set; }
        public Nullable<decimal> DetailTaxPerc { get; set; }
        public string DetailRemarks { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Mail { get; set; }
        public string PostalCode { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string ContactPerson { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public Nullable<decimal> Weight { get; set; }
        public Nullable<decimal> TotalCashSales { get; set; }
        public string UOMName { get; set; }
        public string OrderDateString { get; set; }
        public string CreatedFrom { get; set; }
        public bool IsWeight { get; set; }
        public string TermName { get; set; }
        public string AmountInWords { get; set; }
    }
}
