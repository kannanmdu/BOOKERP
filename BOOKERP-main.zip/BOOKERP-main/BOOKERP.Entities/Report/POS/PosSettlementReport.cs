﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PosSettlementReport
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string TerminalName { get; set; }
        public string SettlementNo { get; set; }
        public string Type { get; set; }
        public Nullable<System.DateTime> SettlementDate { get; set; }
        public Nullable<decimal> TotalCashAmount { get; set; }
        public Nullable<decimal> CashInAmount { get; set; }
        public Nullable<decimal> CashOutAmount { get; set; }
        public Nullable<decimal> ShortageAmount { get; set; }
        public Nullable<decimal> ExcessAmount { get; set; }
        public Nullable<decimal> TotalCashSales { get; set; }        
        public string SettlementBy { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<int> SlNo { get; set; }
        public decimal Denomination { get; set; }
        public Nullable<decimal> DenominationCount { get; set; }
        public Nullable<decimal> Total { get; set; }       
        public string SettlementDateString { get; set; }
    }

    public class PosSettlementSummaryReport
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string SettlementNo { get; set; }
        public Nullable<System.DateTime> SettlementDate { get; set; }
        public Nullable<decimal> TotalCashAmount { get; set; }
        public Nullable<decimal> CashInAmount { get; set; }
        public Nullable<decimal> CashOutAmount { get; set; }
        public string SettlementBy { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<decimal> ShortageAmount { get; set; }
        public Nullable<decimal> ExcessAmount { get; set; }
        public string DayEndSummaryNo { get; set; }
        public string TerminalName { get; set; }
        public Nullable<decimal> DepositAmount { get; set; }
        public string CashierName { get; set; }
        public Nullable<bool> OBstatus { get; set; }
        public decimal Denomination { get; set; }
        public Nullable<decimal> DenominationCount { get; set; }
        public Nullable<decimal> Total { get; set; }
        public string PaymodeCode { get; set; }
        public string PaymodeName { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
    }    
    public class PosSettlementPaymodeReport
    {
        public string PaymentType { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string SettlementBy { get; set; }
        public string Type { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
    }

    public class PosHourlySalesReport
    {
        public Nullable<int> TranNoCount { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TerminalName { get; set; }
        public string CashRegisterCode { get; set; }
        public Nullable<int> Hours { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string PaymodeCode { get; set; }
        public string PaymodeName { get; set; }
    }

    public class PaymodeDetailsReport
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string OrderNo { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
        public Nullable<System.TimeSpan> OrderTime { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<decimal> BillDiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string SettlementNo { get; set; }
        public Nullable<decimal> RoundOff { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public string Mail { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public string PostalCode { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public string PaymodeCode { get; set; }
        public string PaymodeName { get; set; }
        public Nullable<decimal> PaymodeAmount { get; set; }
        public string CashierName { get; set; }
        public Nullable<decimal> TotalPaidAmount { get; set; }
        public Nullable<decimal> POSPaidAmount { get; set; }
        public Nullable<decimal> InvoicePaidAmount { get; set; }
        public Nullable<bool> HavePosIsCredit { get; set; }
    }
    public class PaymodeWiseSummaryReport
    {
        public string CreditType { get; set; }
        public string PaymodeCode { get; set; }
        public string PaymodeName { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<int> NoOfReceipts { get; set; }
        public string CashierName { get; set; }
        public string TerminalName { get; set; }
        public string CashRegisterCode { get; set; }
        public Nullable<decimal> POSPaidAmount { get; set; }
        public Nullable<decimal> CreditPaidAmount { get; set; }
        public Nullable<decimal> TotalPOSPaidAmount { get; set; }
        public Nullable<decimal> TotalCreditPaidAmount { get; set; }
        public Nullable<bool> HavePosIsCredit { get; set; }
    }
}
