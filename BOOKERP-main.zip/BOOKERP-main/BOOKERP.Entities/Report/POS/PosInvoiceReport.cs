﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PosInvoiceReport
    {
        public int ORGANIZATION_ID { get; set; }
        public string POS_OUTNO { get; set; }
        public Nullable<System.DateTime> POS_OUTDATE { get; set; }
        public string POS_OUTDATEString { get; set; }
        public string POS_AREA { get; set; }
        public string POS_STATION { get; set; }
        public string POS_CASHIERCODE { get; set; }
        public string POS_CASHIERNAME { get; set; }
        public string POS_MEMBERCODE { get; set; }
        public string POS_MEMBERNAME { get; set; }
        public Nullable<decimal> POS_SUBTOTAL { get; set; }
        public Nullable<decimal> POS_ITEMDISCOUNT { get; set; }
        public Nullable<decimal> POS_DISCOUNT { get; set; }
        public Nullable<decimal> POS_TAX { get; set; }
        public Nullable<decimal> POS_NETTOTAL { get; set; }
        public Nullable<decimal> POS_ITEMSCOUNT { get; set; }
        public Nullable<decimal> POS_MEMBERDISCOUNT { get; set; }
        public Nullable<decimal> POS_MEMBERPOINTREDEM { get; set; }
        public Nullable<decimal> POS_ROUNDEDVALUE { get; set; }
        public string POS_REMARKS { get; set; }
        public string POS_STATUS { get; set; }
        public string POS_CREATED_BY { get; set; }
        public Nullable<System.DateTime> POS_CREATED_ON { get; set; }
        public Nullable<System.DateTime> POS_MODIFIED_ON { get; set; }
        public string POS_MODIFIED_BY { get; set; }
        public Nullable<decimal> POS_PAIDAMOUNT { get; set; }
        public Nullable<decimal> POS_RETURNAMOUNT { get; set; }
        public Nullable<decimal> POS_DISCOUNTPERCENTAGE { get; set; }
        public string POS_SHIFTNO { get; set; }
        public string POS_INVENTORYCODE { get; set; }
        public string POS_INVENTORYNAME { get; set; }
        public Nullable<decimal> POS_QTYSOLD { get; set; }
        public Nullable<decimal> POS_ITEMPRICE { get; set; }
        public Nullable<decimal> POS_ACTUALPRICE { get; set; }
        public Nullable<decimal> POS_ACTUALCOST { get; set; }
        public Nullable<decimal> Detail_POS_SUBTOTAL { get; set; }
        public Nullable<decimal> Detail_POS_DISCOUNT { get; set; }
        public Nullable<decimal> Detail_POS_DISCOUNTPERCENTAGE { get; set; }
        public Nullable<decimal> Detail_POS_TAXAMOUNT { get; set; }
        public Nullable<decimal> POS_ITEMTAXPERCENTAGE { get; set; }
        public string POS_TAXTYPE { get; set; }
        public Nullable<decimal> Detail_POS_NETTOTAL { get; set; }
        public string Detail_POS_STATUS { get; set; }
        public string POS_ENTERED_BARCODE { get; set; }
        public string POS_ITEMCAT { get; set; }
        public string POS_ITEMBRAND { get; set; }
        public string POS_ITEMDEP { get; set; }
        public string POS_UOM_CODE { get; set; }
        public Nullable<int> Detail_POS_TAX { get; set; }
        
    }
}
