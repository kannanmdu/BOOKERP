﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ReceiptHeaderReport
    {       
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string BranchCode { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string PayMode { get; set; }
        public string Bank { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> ChequeDate { get; set; }
        public string Remarks { get; set; }
        public string AccountNo { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
       
        public Nullable<int> DeliveryId { get; set; }
        public Nullable<System.DateTime> BankInDate { get; set; }    
        public Nullable<decimal> CreditAmount { get; set; }
        public Nullable<decimal> DebitAmount { get; set; }
        public Nullable<decimal> AdvancePayment { get; set; }
        public Nullable<int> ChequeStatus { get; set; }
        public Nullable<decimal> DifferenceAmount { get; set; }
        public Nullable<decimal> WriteOffAmount { get; set; }    
        public string PayModeCode { get; set; }
        public string PayModeName { get; set; }
        public string TermCode { get; set; }
        public string TermName { get; set; }
        public string TranDatestring { get; set; }
        public string ChequeDatestring { get; set; }
        public string BankInDatestring { get; set; }
        public string AmountInWords { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }        
        public string Mobile { get; set; }
        public string Phone { get; set; }     

    }
    public class ReceiptReport
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public Nullable<System.DateTime> invoiceDate { get; set; }
        public Nullable<System.DateTime> BankInDate { get; set; }
        public Nullable<int> DeliveryId { get; set; }
        public string TranDateString { get; set; }
        public string BranchCode { get; set; }
        public string AmountInWords { get; set; }
        public string CustomerCode { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string PayMode { get; set; }
        public string Bank { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> ChequeDate { get; set; }
        public string Remarks { get; set; }
        public string AccountNo { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string TranDatestring { get; set; }
        public string ChequeDatestring { get; set; }
        public string ModuleName { get; set; }
        public string PaymodeName { get; set; }
        public bool IsUpdate { get; set; }
        public string InvoiceNo { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> DelPaidAmount { get; set; }
        public Nullable<decimal> BalaceAmount { get; set; }
        public Nullable<decimal> CreditAmount { get; set; }
        public Nullable<decimal> DebitAmount { get; set; }
        public Nullable<decimal> AdvancePayment { get; set; }
        public Nullable<int> CarryDays { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string TermCode { get; set; }
        public string TermName { get; set; }
        public string BankName { get; set; }

    }
}
