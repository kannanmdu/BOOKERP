﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class SrReport
    {
        public int OrganisationId { get; set; }
        public int OrgId { get; set; }
        public System.Guid SalesReturnId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranDateString { get; set; }
        public Nullable<System.DateTime> RequiredDate { get; set; }
        public string RequiredDateString { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContactPerson { get; set; }
        public string CustomerContactNo { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerAddress { get; set; }
        public string LocationCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> DiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string Remarks { get; set; }
        public string ReferenceNo { get; set; }
        public Nullable<int> Status { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsConfirmed { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CreatedFrom { get; set; }

        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> Kg { get; set; }
        public Nullable<decimal> BoxPrice { get; set; }
        public Nullable<decimal> PcsPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> KgPrice { get; set; }
        public Nullable<decimal> DetailTotal { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> ItemDiscountPerc { get; set; }
        public Nullable<decimal> DetailSubTotal { get; set; }
        public Nullable<decimal> DetailTax { get; set; }
        public Nullable<decimal> DetailNetTotal { get; set; }
        public Nullable<int> DetailStatus { get; set; }

        public Nullable<int> CustomerShipToId { get; set; }
        public string CustomerShipToAddress { get; set; }
        public string PriceSettingCode { get; set; }
        public string TermCode { get; set; }
        public Nullable<bool> InvoiceType { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public string AssignTo { get; set; }
    }
}
