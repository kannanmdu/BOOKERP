﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class InvoiceReport
    {
        public int OrganisationId { get; set; }
        public int OrgId { get; set; }        
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranDateString { get; set; }                
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerContactPerson { get; set; }
        public string CustomerContactNo { get; set; }
        public string CustomerEmail { get; set; }
        public string CustomerAddress { get; set; }
        public string LocationCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public Nullable<decimal> Price { get; set; } 
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> DiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string Remarks { get; set; }
        public string ReferenceNo { get; set; }
        public Nullable<int> Status { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsConfirmed { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string PostalCode { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CreatedFrom { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<decimal> CreditAmount { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public string AssignTo { get; set; }
        public List<InvoiceDetail> InvoiceDetail { get; set; }
        public bool IsUpdate { get; set; }
        public Nullable<int> CustomerShipToId { get; set; }
        public string CustomerShipToAddress { get; set; }
        public string PriceSettingCode { get; set; }
        public string TermCode { get; set; }
        public Nullable<bool> InvoiceType { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public Nullable<decimal> FTotal { get; set; }
        public Nullable<decimal> FDiscount { get; set; }
        public Nullable<decimal> FSubTotal { get; set; }
        public Nullable<decimal> FTax { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public Nullable<decimal> FBalanceAmount { get; set; }      
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> WQty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> Kg { get; set; }
        public Nullable<decimal> BoxPrice { get; set; }
        public Nullable<decimal> PcsPrice { get; set; }
        public Nullable<decimal> KgPrice { get; set; }
        public Nullable<decimal> DetailTotal { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> ItemDiscountPerc { get; set; }
        public Nullable<decimal> DetailSubTotal { get; set; }
        public Nullable<decimal> DetailTax { get; set; }
        public Nullable<decimal> DetailNetTotal { get; set; }
        public Nullable<int> DetailStatus { get; set; }
        public string AmountInWords { get; set; }
        public Nullable<int> Foc { get; set; }
        public Nullable<int> Exchange { get; set; }
        public Nullable<decimal> CreditLimit { get; set; }
        public Nullable<decimal> OutStanding { get; set; }
        public Nullable<Int64> IdNo { get; set; }
        public string RefType { get; set; }
        public Nullable<int> SortOrder { get; set; }
        public string RefNo { get; set; }
        public Nullable<System.DateTime> RefDate { get; set; }
        public Nullable<decimal> Debit { get; set; }
        public Nullable<decimal> Credit { get; set; }
        public Nullable<decimal> OpeningSOA { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public string Fax { get; set; }
        public string TransType { get; set; }
        public string PaymentTerms { get; set; }
        public Nullable<decimal> RunningBalance { get; set; }
        public Nullable<decimal> CurrentPeriod { get; set; }
        public Nullable<decimal> One { get; set; }
        public Nullable<decimal> Two { get; set; }
        public Nullable<decimal> Three { get; set; }
        public Nullable<decimal> Four { get; set; }
        public Nullable<decimal> MCurrentPeriod { get; set; }
        public Nullable<decimal> MonthOne { get; set; }
        public Nullable<decimal> MonthTwo { get; set; }
        public Nullable<decimal> MonthThree { get; set; }
        public Nullable<decimal> MonthFour { get; set; }
        public string DisplayCurrency { get; set; }
        public string CashRegisterCode { get; set; }
        public string SettlementNo { get; set; }
    }
}
