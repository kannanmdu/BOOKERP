﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class InvoicePrint
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public System.DateTime TranDate { get; set; }
        public string TranDateString { get; set; }
        public Nullable<System.DateTime> RequiredDate { get; set; }
        public string RequiredDateString { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string LocationCode { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> Discount { get; set; }
        public Nullable<decimal> DiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public Nullable<decimal> FTotal { get; set; }
        public Nullable<decimal> FDiscount { get; set; }
        public Nullable<decimal> FSubTotal { get; set; }
        public Nullable<decimal> FTax { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public Nullable<decimal> FBalanceAmount { get; set; }
        public string Remarks { get; set; }
        public string ReferenceNo { get; set; }
        public string CreatedFrom { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string AssignTo { get; set; }
        public string TermCode { get; set; }
        public Nullable<bool> InvoiceType { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> BoxPrice { get; set; }
        public Nullable<decimal> PcsPrice { get; set; }
        public Nullable<int> Foc { get; set; }
        public Nullable<int> Exchange { get; set; }
        public Nullable<decimal> DetailTotal { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> ItemDiscountPerc { get; set; }
        public Nullable<decimal> DetailSubTotal { get; set; }
        public Nullable<decimal> DetailTax { get; set; }
        public Nullable<decimal> DetailNetTotal { get; set; }
        public Nullable<decimal> FBoxPrice { get; set; }
        public Nullable<decimal> FPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> DetailFTotal { get; set; }
        public Nullable<decimal> FItemDiscount { get; set; }
        public Nullable<decimal> DetailFSubTotal { get; set; }
        public Nullable<decimal> DetailFTax { get; set; }
        public Nullable<decimal> DetailFNetTotal { get; set; }
        public string DetailRemarks { get; set; }
        public string TermName { get; set; }
        public string Uom { get; set; }
        public string UomName { get; set; }
        public string AmountInWords { get; set; }
        public int NoOfDays { get; set; }
        public int NeedAlertBefore { get; set; }
        public string OrderNo { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string TranType { get; set; }
        public string CustomQty { get; set; }
        public string AdditionalInput1 { get; set; }
        public string AdditionalInput2 { get; set; }
        public string AdditionalInput3 { get; set; }
        public string AdditionalInput4 { get; set; }
        public string AdditionalInput5 { get; set; }
        //public List<InvoiceOutstanding> _Invoiceoutstanding { get; set; }
        public System.DateTime BankInDate { get; set; }
        public string Paymode { get; set; }
        public int OverDueDays1 { get; set; }
        public int OverDueDays2 { get; set; }
        public Nullable<int> DisplayOrder { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public string PostalCode { get; set; }

        public Nullable<decimal> OutstandingAmount { get; set; }
        public Nullable<decimal> WQty { get; set; }
        public string PrintCopy { get; set; }
        public string Salesman { get; set; }
        public decimal BillDiscount { get; set; }
        public decimal FBillDiscount { get; set; }
    }
}
