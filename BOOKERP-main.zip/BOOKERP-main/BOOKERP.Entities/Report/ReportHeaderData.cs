﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ReportHeaderData
    {
        public int OrganisationId { get; set; }             
        public int OrgId { get; set; }       
        public string Name { get; set; }
        public string CountryName { get; set; }           
        public string FloorNo { get; set; }
        public string BlockNo { get; set; }
        public string UnitNo { get; set; }
        public string BuildingName { get; set; }
        public string StreetName { get; set; }
        public Nullable<System.Guid> CountryId { get; set; }
        public string PostalCode { get; set; }
        public string LandMark { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string Mail { get; set; }
        public string Website { get; set; }       
        public bool IsActive { get; set; }       
    }
}
