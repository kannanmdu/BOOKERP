﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PaymentReport
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranDateString { get; set; }
        public string BranchCode { get; set; }
        public string SupplierCode { get; set; }
        public string SupplierName { get; set; }
        public string Address { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string PayMode { get; set; }
        public string Bank { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> ChequeDate { get; set; }
        public string Remarks { get; set; }
        public string AccountNo { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string TranDatestring { get; set; }
        public string ChequeDatestring { get; set; }
        public string ModuleName { get; set; }
        public string PaymodeName { get; set; }
        public bool IsUpdate { get; set; }
        public string InvoiceNo { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> DelPaidAmount { get; set; }
        public Nullable<decimal> BalaceAmount { get; set; }
    }
}
