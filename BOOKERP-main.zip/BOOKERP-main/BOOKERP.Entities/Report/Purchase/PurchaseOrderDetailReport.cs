﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class GetPurchaseOrderDetailReport
    {
        public string TranNo { get; set; }
        public System.DateTime TranDate { get; set; }
        public string SupplierName { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> BoxPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<int> BoxCount { get; set; }

    }
}
