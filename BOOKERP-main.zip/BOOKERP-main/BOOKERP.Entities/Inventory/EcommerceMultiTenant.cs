﻿using System;

namespace BOOKERP.Entities
{
    public partial class EcommerceMultiTenant
    {
        public int OrgId { get; set; }
        public string BookId { get; set; }
        public string ShopCode { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public string AuthToken { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public bool IsActive { get; set; }
        public string LazadaItemId { get; set; }
        public string LazadaSkuId { get; set; }
        public bool IsLazadaSkuActive { get; set; }
    }
}
