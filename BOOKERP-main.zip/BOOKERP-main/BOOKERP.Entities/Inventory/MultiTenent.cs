﻿using System;

namespace BOOKERP.Entities
{
    public partial class MultiTenant
    {
        public Nullable<long> RowNo { get; set; }
        public string Category { get; set; }
        public string ShopName { get; set; }
        public string Code { get; set; }
        public Nullable<decimal> Price { get; set; }
    }
}
