﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class BookTranscation
    {       
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public System.DateTime TranDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string ISIBN13 { get; set; }
        public string ISIBN10 { get; set; }
        public int Qty { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string TranscationType { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string CreatedBy { get; set; }
    }
}

