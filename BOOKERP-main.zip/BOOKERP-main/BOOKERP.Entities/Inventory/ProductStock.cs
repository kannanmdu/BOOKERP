﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ProductStock
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<decimal> StockQty { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<decimal> StockBoxQty { get; set; }
        public Nullable<decimal> StockPcsQty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> StockWQty { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public string SupplierCode { get; set; }
        public string ISBN13 { get; set; }
        public string ISBN10 { get; set; }
        public string AuthorName { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public string Type { get; set; }
        public string TranDateString { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public Nullable<decimal> BoxQty { get; set; }
        public Nullable<decimal> PcsQty { get; set; }
        public Nullable<decimal> Qty { get; set; }
        public Nullable<decimal> WQty { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
    }
}
