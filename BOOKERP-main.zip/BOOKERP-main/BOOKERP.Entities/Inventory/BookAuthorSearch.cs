﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class BookAuthorSearch
    {
        public string AuthorName { get; set; }
    }
}
