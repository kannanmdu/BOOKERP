﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Book
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string Uom { get; set; }
        public string BookId { get; set; }
        public string ISBN13 { get; set; }
        public string ISBN10 { get; set; }
        public string Title { get; set; }
        public string SubTitle { get; set; }
        public string AuthorName { get; set; }
        public string DetailDescription { get; set; }
        public string CategoryId { get; set; }
        public string Publisher { get; set; }
        public string Language { get; set; }
        public string BindingType { get; set; }
        public Nullable<decimal> CostPrice { get; set; }
        public Nullable<decimal> Margin { get; set; }
        public Nullable<decimal> SalesPrice { get; set; }
        public Nullable<decimal> Length { get; set; }
        public Nullable<decimal> Breadth { get; set; }
        public Nullable<decimal> Width { get; set; }
        public Nullable<decimal> Height { get; set; }
        public Nullable<System.DateTime> PublishDate { get; set; }
        public Nullable<int> Edition { get; set; }
        public Nullable<int> TotalPages { get; set; }
        public string SupplierId { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<decimal> UnitCost { get; set; }
        public Nullable<decimal> SellingPrice { get; set; }
        public Nullable<decimal> SellingPriceMargin { get; set; }
        public Nullable<decimal> RetailPrice { get; set; }
        public Nullable<decimal> RetailPriceMargin { get; set; }
        public Nullable<decimal> B2CPrice { get; set; }
        public Nullable<decimal> B2CPriceMargin { get; set; }
        public Nullable<decimal> Weight { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsB2C { get; set; }
        public Nullable<bool> IsPos { get; set; }
        public Nullable<decimal> Thickness { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CreatedOnString { get; set; }
        public string ChangedOnString { get; set; }
        public string PublishDateString { get; set; }
        public string BookImage { get; set; }
        public string SlNo { get; set; }
        public string ProductImage { get; set; }
        public string ProductImageURL { get; set; }
        public string BookImageFilePath { get; set; }
        public string BookImg_Base64String { get; set; }
        public byte[] BookImg { get; set; }
        public string BookImageFileName { get; set; }
        public Nullable<bool> IsNetPrice { get; set; }
        public List<ProductTags> ProductTags { get; set; }
        public List<BookTranscation> BookTrans { get; set; }
        public List<SupplierPrices> SupplierPrices { get; set; }
        
        public GiftVoucher GiftVoucherInfo { get; set; }
        public Nullable<decimal> AvailableStockQty { get; set; }
        public byte[] BarcodeImg { get; set; }
        public string Type { get; set; }


        public string MagazineId { get; set; }
        public string MagazineCode { get; set; }
        public string MagazineName { get; set; }
        public string BarCode { get; set; }
        public string Category { get; set; }
        public string Publishcurrency { get; set; }
        public Nullable<decimal> PublishPrice { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string CategoryName { get; set; }
        public string LongDescription { get; set; }
        public string ShortDescription { get; set; }
        public string SubCategoryCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
        public string ISSN { get; set; }
        public string FrequencyCode { get; set; }
        public Nullable<int> FrequencyValue { get; set; }
        public Nullable<decimal> PriceWGST { get; set; }
        public Nullable<decimal> PriceWOGST { get; set; }
        public Nullable<decimal> UnitPrice { get; set; }
        public Nullable<decimal> Postal { get; set; }
        public string CountryCode { get; set; }
    }
    public class BookStock
    {
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public int PcsPerCarton { get; set; }
        public int WeightProduct { get; set; }
        public decimal AvailableBoxQty { get; set; }
        public decimal AvailablePcsQty { get; set; }
        public decimal AvailableQty { get; set; }
        public decimal AvailableWQty { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
    }
    public class ProductpriceforTransaction
    {
        public decimal Price { get; set; }
        public decimal CartonPrice { get; set; }
    }
}
