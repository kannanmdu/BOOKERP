﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class SupplierPrices
    {
        public int? slno {  get; set; }
        public int Orgid { get; set; }
        public string BookId { get; set; }
        public string SupplierId { get; set; }
        public string Suppliername { get; set;}
        public decimal? Supplierprice {  get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ChangedOn { get; set; }
        public string ChangedBy { get; set; }

    }
}
