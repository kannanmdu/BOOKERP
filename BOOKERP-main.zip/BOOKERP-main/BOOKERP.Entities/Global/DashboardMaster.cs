﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class DashboardMaster
    {
        public string ModuleName { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Column3 { get; set; }
        public string Column4 { get; set; }
        public int SoCount { get; set; }
        public int InvoiceCount { get; set; }
    }
}
