﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
    }

    public class MenuModel
    {
        public int MenuId { get; set; }

        public int MDisplay { get; set; }
        public int SDisplay { get; set; }

        public int OrgId { get; set; }
        public string MenuName { get; set; }
        public string SubMenuId { get; set; }
        public string SubMenuName { get; set; }
    }
}
