﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class EmailTemplate
    {
        public int OrgId { get; set; }
        public int EmailTemplateNo { get; set; }
        public string EmailTemplateName { get; set; }
        public string FromEmail { get; set; }
        public string FromEmailPassword { get; set; }
        public string CCEmail { get; set; }
        public string BCCEmail { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
        public string TranType { get; set; }
        public Nullable<bool> IsDefaultEmail { get; set; }
        public string SMTP_Host { get; set; }
        public Nullable<int> SMTP_Port { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
