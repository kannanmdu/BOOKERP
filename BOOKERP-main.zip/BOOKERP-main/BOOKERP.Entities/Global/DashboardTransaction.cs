﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class DashboardTransaction
    {
        public string ModuleName { get; set; }
        public string TranNo { get; set; }
        public string TranDate { get; set; }
        public string CustomerName { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<bool> IsView { get; set; }
    }
}
