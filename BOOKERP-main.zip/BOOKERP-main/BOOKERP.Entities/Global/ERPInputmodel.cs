﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class ERPInputmodel
    {
        public int OrganisationId { get; set; }
        public string OrganizationName { get; set; }
        public string UserName { get; set; }        
        public string LoginUser { get; set; }
        public string Email { get; set; }
        public string MachineName { get; set; }
        public string TransactionNo { get; set; }
        public string TranNo { get; set; }
        public string TranNo1 { get; set; }

        public string SupplierCode { get; set; }
        public string SupplierId { get; set; }
        public string BranchCode { get; set; }
        public int TransNo { get; set; }
        public int TransNo1 { get; set; }
        public bool IsActive { get; set; }
        public string SubMenu { get; set; }

        public string ModuleName { get; set; }
        public Nullable<System.DateTime> FromDate { get; set; }
        public Nullable<System.DateTime> ToDate { get; set; }
        public string Category { get; set; }
        public string SubCategory { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public string AccountNo { get; set; }
        public int LogID { get; set; }
        public string Decision { get; set; }
        public string User { get; set; }
        public int? FinacialYear { get; set; }
        public int FYear { get; set; }
        public string FinancialYearFromDateString { get; set; }
        public Nullable<System.DateTime> FinancialYearFromDate { get; set; }
        public string FinancialYearToDateString { get; set; }
        public Nullable<System.DateTime> FinancialYearToDate { get; set; }

        public string FromDateString { get; set; }
        public string ToDateString { get; set; }
        public string TranType { get; set; }

        public string CustomerCode { get; set; }
        public string CustomerId { get; set; }
        public string OrgRefNo { get; set; }

        public string CategoryCode { get; set; }
        public string Paymode { get; set; }
        public string ISBN10 { get; set; }
        public string ISBN13 { get; set; }
        public string Status { get; set; }
        public string ProductCode { get; set; }
        public string CashRegisterCode { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranDateString { get; set; }
        public string ShopeeCode { get; set; }
        public string LazadaCode { get; set; }
        public string DepartmentCode { get; set; }
        public int PageSize { get; set; }
        public string BookId { get; set; }
        public int PageNumber { get; set; }
        public string title { get; set; }
        public string EmployeeCode { get; set; }
    }
}
