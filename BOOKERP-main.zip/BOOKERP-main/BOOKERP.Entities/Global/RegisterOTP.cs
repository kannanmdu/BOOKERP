﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class RegisterOTP
    {
        public int OrgId { get; set; }
        public string UserType { get; set; }
        public string Name { get; set; }
        public string EmailId { get; set; }
        public string OTP { get; set; }
        public DateTime Expirted_Date { get; set; }
        public DateTime Created_Date { get; set; }
    }
}
