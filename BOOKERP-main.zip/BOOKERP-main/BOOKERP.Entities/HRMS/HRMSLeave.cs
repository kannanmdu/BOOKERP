﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class HRMSLeave
    {
        public int OrgId { get; set; }
        public string LeaveCode { get; set; }
        public string LeaveName { get; set; }
        public bool IsActive { get; set; }
    }
}
