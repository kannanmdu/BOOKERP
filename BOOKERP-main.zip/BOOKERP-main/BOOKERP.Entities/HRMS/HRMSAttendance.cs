﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class HRMSAttendance
    {
        public int OrgId { get; set; }
        public string EmployeeCode { get; set; }
        public string DepartmentCode { get; set; }
        public DateTime Date { get; set; }
        public string DateString { get; set; }
        public Nullable<System.TimeSpan> InTime { get; set; }
        public Nullable<System.TimeSpan> OutTime { get; set; }
        public Nullable<decimal> TotalHrs { get; set; }
        public Nullable<decimal> OverTimeHrs { get; set; }
        public string WorkingFrom { get; set; }
        public bool Leave { get; set; }
        public string Status { get; set; }
        public string LeaveType { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string AttendanceCode { get; set; }

        public string EmployeeName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public string PhoneNo { get; set; }
        public string MobileNo { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public Nullable<System.DateTime> DOB { get; set; }
        public string Gender { get; set; }
        public Nullable<System.DateTime> HireDate { get; set; }
        public Nullable<decimal> Salary { get; set; }
        public Nullable<decimal> OTRate { get; set; }
        public string EmployeeImage { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Roles { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string Base64String { get; set; }
        public string FileName { get; set; }
        public string DOBString { get; set; }
        public string HireDateString { get; set; }
        public byte[] EmpImage { get; set; }
        public List<HRMSEmployee> Employeelistval { get; set; }
        public List<HRMSAttendance> Attendanceval { get; set; }
    }
}
