﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PaymentDetail
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public DateTime? TranDate { get; set; }
        public string TranDateString { get; set; }
        public string InvoiceNo { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public Nullable<decimal> BalaceAmount { get; set; }
        public Nullable<decimal> CreditAmount { get; set; }
        public Nullable<decimal> DebitAmount { get; set; }
        public Nullable<int> CarryDays { get; set; }
        public Nullable<decimal> AdvancePayment { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public Nullable<decimal> FBalanceAmount { get; set; }
        public Nullable<decimal> FCreditAmount { get; set; }
        public Nullable<decimal> FDebitAmount { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string TranType { get; set; }
    }
}
