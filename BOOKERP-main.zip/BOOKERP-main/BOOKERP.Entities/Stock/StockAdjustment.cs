﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class StockAdjustmentHeaders
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string AdjustTypeCode { get; set; }
        public string Remarks { get; set; }
        public Nullable<bool> Status { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string TranDateString { get; set; }
        public List<StockAdjustmentDetails> StockAdjustmentDetail { get; set; }
    }

    public class StockAdjustmentDetails
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string TranNo { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> PcsPerBox { get; set; }
        public Nullable<decimal> SCQty { get; set; }
        public Nullable<decimal> SLQty { get; set; }
        public Nullable<decimal> SQty { get; set; }
        public Nullable<decimal> ACQty { get; set; }
        public Nullable<decimal> ALQty { get; set; }
        public Nullable<decimal> AQty { get; set; }
        public Nullable<decimal> NewCQty { get; set; }
        public Nullable<decimal> NewLQty { get; set; }
        public Nullable<decimal> NewQty { get; set; }
        public Nullable<decimal> SWQty { get; set; }
        public Nullable<decimal> AWQty { get; set; }
        public Nullable<decimal> NewWQty { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> Status { get; set; }
        public Nullable<bool> IsWeight { get; set; }
        public string ISBN13 { get; set; }
        public string Type { get; set; }
    }
}

