﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class StockRequestHeaders
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public string Remarks { get; set; }
        public Nullable<int> Status { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string TranDateString { get; set; }
        public List<StockRequestDetails> StockRequestDetail { get; set; }
        public bool IsUpdate { get; set; }
        public bool Mode { get; set; }
        public string BranchCode { get; set; }
    }
    public class StockRequestDetails
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<decimal> ReqCQty { get; set; }
        public Nullable<decimal> ReqLQty { get; set; }
        public Nullable<decimal> ReqQty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> TransferQty { get; set; }
        public Nullable<decimal> AverageCost { get; set; }
        public Nullable<decimal> ReqWQty { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string ISBN13 { get; set; }
        public Nullable<bool> IsWeight { get; set; }
    }
}
