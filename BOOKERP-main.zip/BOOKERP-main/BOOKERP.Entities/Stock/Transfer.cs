﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class TransferHeaders
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public Nullable<int> Status { get; set; }
        public string StockRequestNo { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public List<TransferDetails> TransferDetail { get; set; }
        public bool IsUpdate { get; set; }
        public bool Mode { get; set; }
        public string TranDateString { get; set; }
        public string BranchCode { get; set; }
    }
    public class TransferDetails
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> BoxQty { get; set; }
        public Nullable<int> PcsQty { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> WQty { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public string ISBN13 { get; set; }
    }
}
