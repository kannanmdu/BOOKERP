﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class StockTakeHeaders
    {
        public int OrgId { get; set; }
        public int Code { get; set; }
        public Nullable<System.DateTime> Date { get; set; }
        public Nullable<int> Status { get; set; }
        public Nullable<System.DateTime> StockDate { get; set; }
        public string User { get; set; }
        public string LocationCode { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string DateString { get; set; }
        public string StockDateString { get; set; }
        public List<StockTakeDetails> StockTakeDetail { get; set; }
        public bool IsUpdate { get; set; }
    }
    public class StockTakeDetails
    {
        public int OrgId { get; set; }
        public int Code { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<decimal> OldBoxQty { get; set; }
        public Nullable<decimal> OldPcsQty { get; set; }
        public Nullable<decimal> OldQty { get; set; }
        public Nullable<int> BoxCount { get; set; }
        public Nullable<decimal> BoxQty { get; set; }
        public Nullable<decimal> PcsQty { get; set; }
        public Nullable<decimal> Qty { get; set; }
        public Nullable<decimal> OldWQty { get; set; }
        public Nullable<decimal> WQty { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
