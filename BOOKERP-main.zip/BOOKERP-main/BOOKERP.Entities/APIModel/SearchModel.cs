﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class SearchModel
    {
        public int OrganisationId { get; set; }
        public string CustomerCode { get; set; }
        public string SupplierCode { get; set; }
        public string Fromdate { get; set; }
        public string Todate { get; set; }
        public int Status { get; set; }
        public string LoginUser { get; set; }
        public string TranNo { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
    }
}
