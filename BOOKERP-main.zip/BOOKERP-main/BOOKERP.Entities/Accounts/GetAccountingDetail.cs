﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class GetAccountingDetail
    {
        public int OrgId { get; set; }
        public string AccountNo { get; set; }
        public string ParentAccountNo { get; set; }
        public string DebitCredit { get; set; }
        public string AccountName { get; set; }
        public string AccountType { get; set; }
        public Nullable<bool> IsAsset { get; set; }
        public Nullable<bool> IsLiabilities { get; set; }
        public Nullable<bool> IsEquity { get; set; }
        public Nullable<bool> IsExpenses { get; set; }
        public Nullable<bool> IsIncome { get; set; }
        public Nullable<bool> IsBalanceSheet { get; set; }
        public Nullable<bool> IsProfitLoss { get; set; }
        public string TranType { get; set; }
        public decimal PrevDebit { get; set; }
        public decimal PrevCredit { get; set; }
        public decimal PrevFDebit { get; set; }
        public decimal PrevFCredit { get; set; }
        public Nullable<decimal> Debit { get; set; }
        public Nullable<decimal> Credit { get; set; }
        public Nullable<decimal> FDebit { get; set; }
        public Nullable<decimal> FCredit { get; set; }
        public string Transactiontype { get; set; }
        public string RefNo { get; set; }
        public string RefName { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public int Slno { get; set; }
        public int SortOrder { get; set; }
        public string CurrencyCode { get; set; }
        public string GroupLevelName { get; set; }
        public Nullable<decimal> Balance { get; set; }
        public Nullable<decimal> FBalance { get; set; }
        public decimal PrevBalance { get; set; }
        public decimal PrevFBalance { get; set; }
        public string OtherRefNo { get; set; }
        public string Remarks { get; set; }
        public Nullable<decimal> OpeningBalance { get; set; }
        public string TransactionType { get; set; }
        public string TranDateString { get; set; }
        public string A1AccountNo { get; set; }
        public string A1AccountName { get; set; }
        public string A2AccountNo { get; set; }
        public string A2AccountName { get; set; }
        public string A3AccountNo { get; set; }
        public string A3AccountName { get; set; }
        public string A4AccountNo { get; set; }
        public string A4AccountName { get; set; }
        public string A5AccountNo { get; set; }
        public string A5AccountName { get; set; }
        public string A6AccountNo { get; set; }
        public string A6AccountName { get; set; }
        public Nullable<decimal> SumOfIncome { get; set; }
        public Nullable<decimal> SumOfExpense { get; set; }
        public Nullable<decimal> SumOfOtherincome { get; set; }
        public Nullable<decimal> SumOfOtherExpense { get; set; }
        public Nullable<decimal> SumOfAsset { get; set; }
        public Nullable<decimal> SumOfLiabilities { get; set; }
        public Nullable<decimal> SumOfEquity { get; set; }
        public Nullable<decimal> SumOfProfitLoss { get; set; }
        public int? RowId { get; set; }
        public string TranNo { get; set; }
        public string ReportType { get; set; }
        public string GLType { get; set; }
        public string CreatedBy { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int? GroupLevel { get; set; }
        public string Type { get; set; }
        public decimal? PaidAmount { get; set; }
        public string Paymode { get; set; }
        public string ChequeNo { get; set; }
        public DateTime? ChequeDate { get; set; }
        public string ChequeDateString { get; set; }
        public string Bank { get; set; }
    }
}
