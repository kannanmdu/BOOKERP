﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class GetChildAccount
    {
        public int OrgId { get; set; }
        public string GLCode { get; set; }
        public string G1GroupNo { get; set; }
        public string G1GroupName { get; set; }
        public string G2GroupNo { get; set; }
        public string G2GroupName { get; set; }
        public string G3GroupNo { get; set; }
        public string G3GroupName { get; set; }
        public string G4GroupNo { get; set; }
        public string G4GroupName { get; set; }
        public string G5GroupNo { get; set; }
        public string G5GroupName { get; set; }
        public string G6GroupNo { get; set; }
        public string G6GroupName { get; set; }
        public int SortORder { get; set; }
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsHavePayments { get; set; }
        public Nullable<bool> IsNonTrading { get; set; }
    }
}
