﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class PaymentReceiptVoucherHeaders
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranType { get; set; }
        public string CustomerSupplierCode { get; set; }
        public string CustomerSupplierName { get; set; }
        public string PaymentAccountNo { get; set; }
        public string PaymentMode { get; set; }
        public string BankCode { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> Chequedate { get; set; }
        public Nullable<System.DateTime> BankInDate { get; set; }
        public string ReferenceNo { get; set; }
        public Nullable<System.DateTime> ReferenceDate { get; set; }
        public string Remarks { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> DiscountAmount { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
        public Nullable<decimal> FTotal { get; set; }
        public Nullable<decimal> FSubTotal { get; set; }
        public Nullable<decimal> FTax { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }
        public Nullable<decimal> FPaidAmount { get; set; }
        public string BRNo { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string TranDateString { get; set; }
        public string ChequeDateString { get; set; }
        public string BankInDateString { get; set; }
        public string ReferenceDateString { get; set; }
        public List<PaymentReceiptVoucherDetails> PaymentReceiptVoucherDetail { get; set; }
    }
}
