﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class AccountVoucherDetail
    {
        public int OrgId { get; set; }
        public string TranNo { get; set; }
        public string TranType { get; set; }
        public int SlNo { get; set; }
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string TaxType { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> FPrice { get; set; }
        public Nullable<decimal> FSubTotal { get; set; }
        public Nullable<decimal> FTax { get; set; }
        public Nullable<decimal> FNetTotal { get; set; }

        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> FTotal { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
