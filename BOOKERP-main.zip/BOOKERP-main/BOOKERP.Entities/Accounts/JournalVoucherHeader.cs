﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class JournalVoucherHeader
    {
        public int OrgId { get; set; }
        public string JVNo { get; set; }
        public string LocationCode { get; set; }
        public Nullable<System.DateTime> JVDate { get; set; }
        public string JVDateString { get; set; }
        public Nullable<decimal> TotalDebit { get; set; }
        public Nullable<decimal> TotalCredit { get; set; }
        public Nullable<decimal> FTotalDebit { get; set; }
        public Nullable<decimal> FTotalCredit { get; set; }
        public string Remarks { get; set; }
        public string Paymode { get; set; }
        public string BankCode { get; set; }
        public string ChequeNo { get; set; }
        public Nullable<System.DateTime> ChequeDate { get; set; }
        public string ChequeDateString { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public string TranType { get; set; }
        public string ReferenceNo { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public List<JournalVoucherDetail> JournalVoucherDetail { get; set; }
        public Nullable<System.DateTime> BankInDate { get; set; }
        public string BankInDateString { get; set; }
        public Nullable<System.DateTime> ReferenceDate { get; set; }
        public string ReferenceDateString { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
    }
}
