﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Coamaster
    {
        public int OrgId { get; set; }
        public string AccountNo { get; set; }
        public string AccountName { get; set; }
        public string AccountType { get; set; }
        public string ParentAccountNo { get; set; }
        public Nullable<bool> IsHavePayments { get; set; }
        public string DebitCredit { get; set; }
        public Nullable<int> SortOrder { get; set; }
        public string CurrencyName { get; set; }
        public Nullable<int> GroupLevel { get; set; }
        public Nullable<bool> HavePayment { get; set; }
        public Nullable<bool> IsNonTrading { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
