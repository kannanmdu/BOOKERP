﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class BankReconciliation
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string BRNo { get; set; }
        public Nullable<System.DateTime> BRDate { get; set; }
        public string AccountNo { get; set; }
        public Nullable<decimal> OpeningBalance { get; set; }
        public Nullable<decimal> ClosingBalance { get; set; }
        public Nullable<decimal> DiferenceAmount { get; set; }
        public Nullable<System.DateTime> StatementEndDate { get; set; }
        public Nullable<decimal> OpeningAsperBook { get; set; }
        public Nullable<decimal> ClosingAsperBook { get; set; }
        public Nullable<decimal> DiferenceAsPerBook { get; set; }
        public string CreateUser { get; set; }
        public string ModifyUser { get; set; }
        public Nullable<System.DateTime> CreateDate { get; set; }
        public Nullable<System.DateTime> ModifyDate { get; set; }
        public Nullable<int> Status { get; set; }
        public Nullable<decimal> TotalPayments { get; set; }
        public Nullable<decimal> TotalReceipts { get; set; }
        public string BRDateString { get; set; }
        public string StatementEndDateString { get; set; }
    }
}
