﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class FinancialSettings
    {
        public int OrgId { get; set; }
        public Nullable<System.DateTime> FinancialPeriodFrom { get; set; }
        public Nullable<System.DateTime> FinancialPeriodTo { get; set; }
        public Nullable<int> CurrentFinancialYear { get; set; }
        public string CustomerAccountNo { get; set; }
        public string SupplierAccountNo { get; set; }
        public string PurchaseAccountNo { get; set; }
        public string SalesAccountNo { get; set; }
        public string InventoryAccountNo { get; set; }
        public string TaxInAccountNo { get; set; }
        public string TaxOutAccountNo { get; set; }
        public string CostOfGoodsAccountNo { get; set; }
        public string ClosingStockAccountNo { get; set; }
        public Nullable<bool> HaveCostofGoodsSold { get; set; }
        public string CurrentYearEarning { get; set; }
        public string FinancialPeriodFromString { get; set; }
        public string FinancialPeriodToString { get; set; }
    }
}
