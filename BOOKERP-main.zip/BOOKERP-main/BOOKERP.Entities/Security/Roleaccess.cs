﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class Roleaccess
    {
        public int OrganisationId { get; set; }
        public int UserRolePermissionId { get; set; }
        public string UserRolecode { get; set; }
        public string SubMenuId { get; set; }
        public string SubMenuName { get; set; }
        public string MenuName { get; set; }
        public Nullable<int> MenuId { get; set; }
        public Nullable<int> DisplayOrder { get; set; }
        public bool IsActive { get; set; }
        public int IsFullAccess { get; set; }
        public int IsView { get; set; }
        public int IsAdd { get; set; }
        public int IsEdit { get; set; }
        public int IsConvert { get; set; }
        public int IsDelete { get; set; }
    }
}
