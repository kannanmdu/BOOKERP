﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class UserPermission
    {
        public int OrgId { get; set; }
        public int UserRolePermissionId { get; set; }
        public string UserRoleCode { get; set; }
        public Nullable<int> MenuId { get; set; }
        public string SubMenuId { get; set; }
        public Nullable<bool> IsAdd { get; set; }
        public Nullable<bool> IsEdit { get; set; }
        public Nullable<bool> IsDelete { get; set; }
        public Nullable<bool> IsConvert { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsView { get; set; }
        public Nullable<bool> IsFullAccess { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string SubMenuName { get; set; }
        public string MenuName { get; set; }
    }
}
