﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class CustomerWishList
    {
        public int OrgId { get; set; }
        public string CustomerId { get; set; }
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ProductImage { get; set; }
        public Nullable<decimal> SellingPrice { get; set; }
    }
}
