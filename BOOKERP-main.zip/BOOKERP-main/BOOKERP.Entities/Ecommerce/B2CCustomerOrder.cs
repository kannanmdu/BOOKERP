﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class B2CCustomerOrder
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string OrderNo { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public System.DateTime OrderDate { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string PostalCode { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<decimal> BillDiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string PaymentType { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<int> Status { get; set; }
        public Nullable<int> CustomerShipToId { get; set; }
        public string CustomerShipToAddress { get; set; }
        public Nullable<decimal> Latitude { get; set; }
        public Nullable<decimal> Longitude { get; set; }
        public string Signatureimage { get; set; }
        public string Cameraimage { get; set; }
        public string OrderDateString { get; set; }
        public string CreatedFrom { get; set; }
        public string CustomerEmail { get; set; }
        public List<B2CCustomerOrderDetail> OrderDetail { get; set; }

        public Nullable<decimal> DeliveryAmount { get; set; }

    }
    public class B2CEditProfile
    {
        public int OrgId { get; set; }
        public string B2CCustomerId { get; set; }
        public string B2CCustomerName { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string CountryId { get; set; }
        public string PostalCode { get; set; }
        public string MobileNo { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
    public class B2CChangePassword
    {
        public int OrgId { get; set; }
        public string B2CCustomerId { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
