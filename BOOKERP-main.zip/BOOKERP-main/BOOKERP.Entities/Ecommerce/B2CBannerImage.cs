﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class B2CBannerImage
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string BannerId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string AdditionalDesc { get; set; }
        public string BannerImageFileName { get; set; }
        public string BannerImageFilePath { get; set; }
        public string BannerImg_Base64String { get; set; }
        public byte[] BanneImage { get; set; }
        public Nullable<int> DisplayOrder { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string CreatedOnString { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string ChangedOnString { get; set; }
    }
}
