﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class B2CCustomerRegister
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string B2CCustomerId { get; set; }
        public string B2CCustomerName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string MobileNo { get; set; }
        public string CountryId { get; set; }
        public string PostalCode { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsApproved { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string FloorNo { get; set; }
        public string UnitNo { get; set; }

    }

    public class GetB2CCustomerRegister
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string B2CCustomerId { get; set; }
        public string B2CCustomerName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string MobileNo { get; set; }
        public string CountryId { get; set; }
        public string PostalCode { get; set; }
        public bool IsActive { get; set; }
        public Nullable<bool> IsApproved { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public List<B2CCustomerOrder> Orders { get; set; }
        public List<B2CCustomerDeliveryAddress> Address { get; set; }
        public int? B2CDeliveryId { get; set; }
        public string FloorNo { get; set; }
        public string UnitNo { get; set; }
    }
}
