﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class B2CContactEnquiry
    {
        public int OrgId { get; set; }
        public string ContactEntryId { get; set; }
        public string ContactPersonName { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Subject { get; set; }
        public string RequestMessage { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
    }
}
