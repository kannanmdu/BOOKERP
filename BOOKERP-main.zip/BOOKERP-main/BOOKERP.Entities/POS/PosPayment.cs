﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class PosPayment
    {
        public string OrderNo { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public int OrgId { get; set; }
        public int SlNo { get; set; }
        public string PaymodeCode { get; set; }
        public string PaymodeName { get; set; }
        public decimal? Amount { get; set; }
        public string SettlementNo { get; set; }
        public bool IsCredit { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
    }
}
