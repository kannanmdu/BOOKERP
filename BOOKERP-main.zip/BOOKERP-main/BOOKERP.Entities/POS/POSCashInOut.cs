﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public class POSCashInOut
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string TerminalName { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public Nullable<decimal> Amount { get; set; }
        public string ReferenceNo { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string SettlementNo { get; set; }
        public string TranDateString { get; set; }
        public string ModuleName { get; set; }
        public string TranType { get; set; }
        public string CustomerSupplierId { get; set; }
        public string CustomerSupplierName { get; set; }
        public string ContactType { get; set; }
    }
}
