﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class POSDayEndSummary
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string TranNo { get; set; }
        public Nullable<System.DateTime> TranDate { get; set; }
        public string TranDateString { get; set; }
        public string DayEndSummaryBy { get; set; }
        public Nullable<decimal> TotalCashSales { get; set; }
        public Nullable<decimal> TotalCashInHand { get; set; }
        public Nullable<decimal> Shortage { get; set; }
        public Nullable<decimal> Excess { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string SettlementNo { get; set; }
    }

    public class POSDayEndSummaryDetails
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string SettlementNo { get; set; }
        public Nullable<System.DateTime> SettlementDate { get; set; }
        public string SettlementDateString { get; set; }
        public string CashRegisterCode { get; set; }
        public string TerminalName { get; set; }
        public Nullable<decimal> OpeningAmount { get; set; }
        public Nullable<decimal> TotalCashAmount { get; set; }
        public Nullable<decimal> POSSales { get; set; }
        public Nullable<decimal> CreditSales { get; set; }
        public Nullable<decimal> CashInAmount { get; set; }
        public Nullable<decimal> CashOutAmount { get; set; }
        public string SettlementBy { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<decimal> ShortageAmount { get; set; }
        public Nullable<decimal> ExcessAmount { get; set; }
        public string DayEndSummaryNo { get; set; }
    }
}
