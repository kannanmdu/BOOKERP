﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class POSSettlementDetails
    {
        public int OrgId { get; set; }
        public string SettlementNo { get; set; }
        public Nullable<int> SlNo { get; set; }
        public decimal Denomination { get; set; }
        public Nullable<decimal> DenominationCount { get; set; }
        public Nullable<decimal> Total { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<decimal> CashInAmount { get; set; }
        public Nullable<decimal> CashOutAmount { get; set; }
        public List<POSPaymode> PosPaymode { get; set; }
        public List<POSCurrencyDenominationValue> PosCurrencyDenomination { get; set; }
    }
    public class POSPaymode
    {
        public string PaymentType { get; set; }
        public Nullable<decimal> PaidAmount { get; set; }
    }

    public class POSCurrencyDenominationValue
    {
        public int OrgId { get; set; }
        public decimal DenominationValue { get; set; }
        public bool IsActive { get; set; }
    }
    public class POSSettlementDetail
    {        
        public Nullable<int> SlNo { get; set; }
        public decimal Denomination { get; set; }
        public Nullable<decimal> DenominationCount { get; set; }
        public Nullable<decimal> Total { get; set; }       
        public Nullable<bool> IsActive { get; set; }
    }
}
