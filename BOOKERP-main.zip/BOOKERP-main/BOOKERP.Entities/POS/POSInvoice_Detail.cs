﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class POSInvoice_Detail
    {
        public int OrgId { get; set; }
        public string OrderNo { get; set; }
        public int SlNo { get; set; }
        public string ProductCode { get; set; }
        public string UOMName { get; set; }
        public bool IsCredit { get; set; }
        public string ProductName { get; set; }
        public Nullable<int> Qty { get; set; }
        public Nullable<decimal> Price { get; set; }
        public Nullable<int> Foc { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> ItemDiscount { get; set; }
        public Nullable<decimal> ItemDiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<decimal> Weight { get; set; }
        public Nullable<bool> IsSR { get; set; }
        public Nullable<bool> IsWeight { get; set; }
        public Nullable<bool> IsNetPrice { get; set; }
        public string VoucherCode { get; set; }
    }
}
