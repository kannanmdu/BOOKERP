﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class POSInvoice_Header
    {
        public int OrgId { get; set; }
        public string BrachCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string OrderNo { get; set; }
        public string OrderDateString { get; set; }
        public Nullable<System.DateTime> OrderDate { get; set; }
        public bool IsCredit { get; set; }
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string CurrencyCode { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<decimal> BillDiscount { get; set; }
        public Nullable<decimal> BillDiscountPerc { get; set; }
        public Nullable<decimal> SubTotal { get; set; }
        public Nullable<decimal> Tax { get; set; }
        public Nullable<decimal> NetTotal { get; set; }
        public string Remarks { get; set; }
        public bool IsActive { get; set; }
        public bool IsUpdate { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public List<POSInvoice_Detail> POSInvoiceDetail { get; set; }
        public List<PosPayment> PosPaymentDetail { get; set; }
        public Nullable<decimal> PayableAmount { get; set; }
        public Nullable<decimal> BalanceAmount { get; set; }
        public string OrderNoHold { get; set; }
        public string SettlementNo { get; set; }
        public string CashRegisterName { get; set; }
        public Nullable<decimal> RoundOff { get; set; }
        public string PaymodeName { get; set; }
         
    }

    public class POSSettingsList
    {
        public int POSSettingsID { get; set; }
        public Nullable<int> OrgId { get; set; }
        public string SettingId { get; set; }
        public string SettingValue { get; set; }
        public string SettingDescription { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
    }

    public class SalesByPaymode
    {
     
        public string PaymentModeCode { get; set; }
        public string PaymentModeName { get; set; }
        public Nullable<decimal> Amount { get; set; }

    }
}
