﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class POSSettlementHeaders
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string TerminalName { get; set; }
        public string SettlementNo { get; set; }
        public Nullable<System.DateTime> SettlementDate { get; set; }
        public string SettlementDateString { get; set; }
        public Nullable<decimal> TotalCashAmount { get; set; }
        public Nullable<decimal> CashInAmount { get; set; }
        public Nullable<decimal> CashOutAmount { get; set; }
        public string SettlementBy { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public List<POSSettlementDetails> POSSettlementDetails { get; set; }
        public List<POSPaymode> POSPaymode { get; set; }
        public Nullable<decimal> ShortageAmount { get; set; }
        public Nullable<decimal> ExcessAmount { get; set; }
        public Nullable<decimal> OpeningAmount { get; set; }
    }
    
}
