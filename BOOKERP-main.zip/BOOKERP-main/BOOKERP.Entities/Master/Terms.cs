﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Terms
    {
        public int OrgId { get; set; }
        public string TermCode { get; set; }
        public string TermName { get; set; }
        public bool IsActive { get; set; }
        public Nullable<int> DisplayOrder { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CreatedOnString { get; set; }
        public string ChangedOnString { get; set; }
        public Nullable<int> NoOfDays { get; set; }
        public Nullable<int> NeedAlertBefore { get; set; }
    }
}
