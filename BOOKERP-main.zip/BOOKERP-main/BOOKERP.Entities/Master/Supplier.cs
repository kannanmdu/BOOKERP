﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Supplier
    {
        public int OrgId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string UniqueNo { get; set; }
        public string Mail { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string CountryId { get; set; }
        public string PostalCode { get; set; }
        public string Mobile { get; set; }
        public string Phone { get; set; }
        public string Fax { get; set; }
        public Nullable<int> TaxTypeId { get; set; }
        public string CurrencyId { get; set; }
        public string PaymentTerms { get; set; }
        public string SalesPerson { get; set; }
        public string Source { get; set; }
        public bool IsActive { get; set; }
        public string AccountNo { get; set; }
        public string Activity1 { get; set; }
        public string Activity2 { get; set; }
        public string ContactPerson { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<decimal> CurrencyRate { get; set; }
        public Nullable<decimal> CurrencyValue { get; set; }
    }
}
