﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class GiftVoucherSettings
    {
        public int OrgId { get; set; }
        public string VoucherSettingsCode { get; set; }
        public string VoucherCode { get; set; }
        public string VoucherName { get; set; }
        public Nullable<decimal> Amount { get; set; }
        public Nullable<int> Validity { get; set; }
        public Nullable<int> StartNo { get; set; }
        public Nullable<decimal> Total { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<System.DateTime> GenerateDate { get; set; }
        public string GenerateDateString { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
