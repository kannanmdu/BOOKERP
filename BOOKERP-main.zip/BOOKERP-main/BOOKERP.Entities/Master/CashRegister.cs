﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class CashRegister
    {
        public int OrgId { get; set; }
        public string BranchCode { get; set; }
        public string CashRegisterCode { get; set; }
        public string TerminalName { get; set; }
        public Nullable<decimal> DepositAmount { get; set; }
        public string CashierName { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string CreatedOnString { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string ChangedOnString { get; set; }
        public Nullable<bool> OBstatus { get; set; }
    }
}
