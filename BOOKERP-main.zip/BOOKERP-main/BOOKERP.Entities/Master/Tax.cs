﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Tax
    {
        public int OrgId { get; set; }
        public int TaxCode { get; set; }
        public string TaxType { get; set; }
        public string TaxName { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CreatedOnString { get; set; }
        public string ChangedOnString { get; set; }
    }
}
