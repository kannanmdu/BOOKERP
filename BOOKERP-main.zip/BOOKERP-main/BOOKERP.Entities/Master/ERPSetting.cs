﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ERPSetting
    {
        public int OrgId { get; set; }
        public string SettingId { get; set; }
        public string SettingValue { get; set; }
        public string SettingDescription { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
    }
}
