﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class Country
    {
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string CountryCurrencyCode { get; set; }
        public string CountryCurrencyName { get; set; }
        public string CountryCurrencySymbol { get; set; }
        public string CountryDialCode { get; set; }
        public string CountryCultureInfo { get; set; }
        public Nullable<int> CountryDisplayOrder { get; set; }
    }
}
