﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class GiftVoucher
    {
        public int OrgId { get; set; }
        public string VoucherCode { get; set; }
        public string VoucherName { get; set; }      
        public Nullable<decimal> Amount { get; set; }
        public Nullable<System.DateTime> DueDate { get; set; }
        public Nullable<int> StartNo { get; set; }
        public Nullable<int> SequenceNo { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public string DueDateString { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
