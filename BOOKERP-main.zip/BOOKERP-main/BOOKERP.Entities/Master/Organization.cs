﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
   public  class Organization
    {
        public int OrgId { get; set; }
        public string OrgName { get; set; }
        public string RegNo { get; set; }
        public string TaxRegNo { get; set; }
        public string OrgRefCode { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string AddressLine3 { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public string PostalCode { get; set; }
        public string PhoneNo { get; set; }
        public string MobileNo { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string Website { get; set; }
        public byte[] OrgLogo { get; set; }
        public string OrgLogoString { get; set; }
        public Nullable<int> TaxCode { get; set; }
        public string TaxType { get; set; }
        public Nullable<decimal> TaxPerc { get; set; }
        public string Currency { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNo { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public System.DateTime CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
