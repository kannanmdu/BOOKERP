﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ShopeeResponse
    {
        public int OrgId { get; set; }
        public int SlNo { get; set; }
        public string access_token { get; set; }
        public string refresh_token { get; set; }
        public string request_id { get; set; }
        public int expire_in { get; set; }
        public string error { get; set; }
        public string message { get; set; }
        public long ShopId { get; set; }
        public string Code { get; set; }
        public string Sign { get; set; }
        public string ShopeeCode { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
    }
}
