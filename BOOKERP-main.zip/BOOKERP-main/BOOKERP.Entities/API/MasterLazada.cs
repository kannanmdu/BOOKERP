﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public partial class MasterLazada
    {
        public int OrgId { get; set; }
        public string ShopName { get; set; }
        public string Host { get; set; }
        public string AppKey { get; set; }
        public string AppSecret { get; set; }
        public string CountryCode { get; set; }
        public string LazadaCode { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public string OAuthCode { get; set; }
        public bool IsActive { get; set; }
    }
}
