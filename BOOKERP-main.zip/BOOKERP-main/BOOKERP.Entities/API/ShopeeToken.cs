﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class ShopeeToken
    {
        public int OrgId { get; set; }
        public int SlNo { get; set; }
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string RequestId { get; set; }
        public Nullable<int> ExpireIn { get; set; }
        public string Error { get; set; }
        public string Message { get; set; }
        public bool IsActive { get; set; }
        public string CreatedBy { get; set; }
        public Nullable<System.DateTime> CreatedOn { get; set; }
        public string ChangedBy { get; set; }
        public Nullable<System.DateTime> ChangedOn { get; set; }
        public Nullable<long> ShopId { get; set; }
        public string Code { get; set; }
        public string Sign { get; set; }
        public string ShopeeCode { get; set; }
    }
}
