﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOOKERP.Entities
{
    public class OnixXml
    {
        public int Id { get; set; }

        public string SenderName { get; set; }

        public string EmailAddress { get; set; }

        public string MessageNumber { get; set; }

        public string SentDateTime { get; set; }

        public Product Products { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }

        public int ONIXMessageId { get; set; }

        public OnixXml ONIXMessage { get; set; }

        public string RecordReference { get; set; }

        public string NotificationType { get; set; }

        public string RecordSourceType { get; set; }

        public string RecordSourceName { get; set; }

        public ProductIdentifier ProductIdentifiers { get; set; }

        // Add other properties as needed for DescriptiveDetail, CollateralDetail, PublishingDetail, etc.
    }

    public class ProductIdentifier
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        public Product Product { get; set; }

        public string ProductIDType { get; set; }

        public string IDTypeName { get; set; }

        public string IDValue { get; set; }
    }

}
