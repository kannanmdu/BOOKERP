﻿using System;
using System.Collections.Generic;

namespace BOOKERP.Entities
{
    public class LazadaOrderDetails
    {
        public string code { get; set; }
        public Data data { get; set; }
        public string request_id { get; set; }
    }

    public class Data
    {
        public string count { get; set; }
        public string countTotal { get; set; }
        public List<Order> orders { get; set; }
    }

    public class Order
    {
        public string voucher_platform { get; set; }
        public string voucher { get; set; }
        public string warehouse_code { get; set; }
        public string order_number { get; set; }
        public string voucher_seller { get; set; }
        public DateTime created_at { get; set; }
        public string voucher_code { get; set; }
        public string gift_option { get; set; }
        public string shipping_fee_discount_platform { get; set; }
        public string customer_last_name { get; set; }
        public string promised_shipping_times { get; set; }
        public DateTime updated_at { get; set; }
        public string price { get; set; }
        public string national_registration_number { get; set; }
        public string shipping_fee_original { get; set; }
        public string payment_method { get; set; }
        public string address_updated_at { get; set; }
        public string buyer_note { get; set; }
        public string customer_first_name { get; set; }
        public string shipping_fee_discount_seller { get; set; }
        public string shipping_fee { get; set; }
        public string branch_number { get; set; }
        public string tax_code { get; set; }
        public string items_count { get; set; }
        public string delivery_info { get; set; }
        public List<object> statuses { get; set; }
        public Address address_billing { get; set; }
        public string extra_attributes { get; set; }
        public string order_id { get; set; }
        public string remarks { get; set; }
        public string gift_message { get; set; }
        public Address address_shipping { get; set; }
    }

    public class Address
    {
        public string country { get; set; }
        public string address3 { get; set; }
        public string phone { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string address1 { get; set; }
        public string post_code { get; set; }
        public string phone2 { get; set; }
        public string last_name { get; set; }
        public string address5 { get; set; }
        public string address4 { get; set; }
        public string first_name { get; set; }
    }
}
